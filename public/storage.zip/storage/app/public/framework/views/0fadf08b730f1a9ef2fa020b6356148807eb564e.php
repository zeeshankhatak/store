<div class="col-md-3">
    <section class="">
        <section class="">

            <ul class="sidebar-menu" data-widget="tree">

 <?php if(auth()->user()->role->permission['capabilities']['coach']['wallet']['view']==1): ?>
                <li class=""><a href="<?php echo e(route('coach.tab.wallet', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Wallet')); ?></span></a></li>
   <?php endif; ?>
 <?php if(auth()->user()->role->permission['capabilities']['coach']['order']['view']==1): ?>
                <li class=""><a href="<?php echo e(route('coach.tab.order', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Order')); ?></span></a></li> 
   <?php endif; ?>
                 <?php if(auth()->user()->role->permission['capabilities']['coach']['edit']==1): ?>
                <li class=""><a href="<?php echo e(route('coach.tab.profile', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span>Coach Profile</span></a></li>
                <?php endif; ?>

                

                

            </ul>


        </section>
    </section>

</div>
<?php /**PATH /home/fpsaquaclients/public_html/resources/views/admin/instructor/all_instructor/tabs/index.blade.php ENDPATH**/ ?>