
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Invoice - Preview</title>
</head>

<style>
    .invoice {
       max-width: 1920px;
       width: 100%;
       padding: 90px 115px;
       margin: 0 auto;
       position: relative;
   }
   /*.page-header {*/
   /*    margin: 200px 0 20px 0;*/
   /*    font-size: 22px;*/
   /*}*/
   header {
       position: relative;
       z-index:1;
   }
   .page-header small {
       color: #fff;
       font-size: 20px;
   }
   .page-header {
       margin-bottom: 20px;
   }
   .invoice .heading {
       color: #fff;
       font-weight: 700;
       font-size: 22px;
       margin-bottom: 20px;
   }
   .invoice .title {
       color: #fff;
       margin-top: 20px;
       font-size: 16px;
   }
   .invoice .invoice-info {
       background: #151E27;
       padding: 20px;
       border-radius: 10px;
       height: 100%;
   }
   .select-price {
       font-size: 16px;
       font-weight: 700;
       text-transform: uppercase;
       border: 1px solid #ffffff;
       color: #EE2737;
       background-color: #02010100;
       border-radius: 10px;
       display: inline-block;
       text-align: center;
       width: fit-content;
       margin-bottom: 20px;
   }
   .select-price select {
       background: #10161e;
       border: none;
       color: #ffffff;
       padding: 10px 0;
       width: 230px;
       font-weight: 700;
       border-radius: 10px;
       text-align: center;
   }
   .select-price select:focus {
       outline:0;
   }
   .invoice .invoice-info .invoice-col {
       border-right: 1px solid #ffffff29;

   }
   .invoice .invoice-info .invoice-col:first-child {
       padding-left:15px;
   }
   .invoice .invoice-info .invoice-col:last-child {
       border-right: 0;
   }
   @media (max-width: 991px) {
       .invoice .heading {
           margin-top: 20px;
       }
   }
   @media (max-width: 1500px) {
       .invoice .invoice-info .invoice-col {
           border-right: 1px solid #ffffff29;
           padding: 0 15px 0 15px;
       }
       .invoice .title {
           font-size: 14px;
       }
        .invoice {
           padding: 60px;
       }
   }
   @media (max-width: 600px) {
        .invoice {
           padding: 20px;
       }
   }
   </style>
<body>
    <section class="content content_content">
        <section class="invoice">
            <!-- title row -->
            <div class="row mb-5">
                <div class="col-md-6">
                    <h2 class="page-header">
                             <?php if(\Session::has('error')): ?>
                            <h6 class="alert alert-danger"><?php echo e(\Session::get('error')); ?></h6>
                            <?php echo e(\Session::forget('error')); ?>

                        <?php endif; ?>
                        <?php if(\Session::has('success')): ?>
                            <h6 class="alert alert-success"><?php echo e(\Session::get('success')); ?></h6>
                            <?php echo e(\Session::forget('success')); ?>

                        <?php endif; ?>


                    </h2>
                </div><!-- /.col -->
                <div class="col-md-6 text-right">

                    <span  class=" <?php echo e($order->status ==1 ? 'badge badge-success' : 'badge badge-danger'); ?>">
                        <?php if($order->status ==1): ?>
                          <?php echo e(__('adminstaticword.Paid')); ?>

                        <?php else: ?>
                          <?php echo e(__('adminstaticword.Unpaid')); ?>

                        <?php endif; ?>
                      </span>

                    <button class="btn btn-primary" style="margin-right: 5px;"><i class="fa fa-download"></i><a href="<?php echo e(route('invoice.show')); ?>">Generate PDF</a></button>

                </div>
            </div>
            <!-- info row -->
            <h1 class="text-center mb-4">INVOICE  <span class="redColor">PREVIEW</span></h1>
            <div class="row">
                <div class="col-lg-8">
                    <div class="invoice-info">
                        <div class="row">
                            <div class="col-lg-4 invoice-col">
                                <h2 class="heading mt-0 border-bottom pb-3 border-light">Coach Details</h2>
                                <?php $i=0;?>
                                <?php $__currentLoopData = $coach_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++;?>
                                <div>
                                    <h4 class="heading mt-0">Coach <?php echo $i;?>:</h4>
                                    <h4 class="title"><b>Name:</b> <?php echo e($coach->fname); ?> <?php echo e($coach->lname); ?></h4>
                                    <h4 class="title"><b>Rank:</b>  <?php echo e($coach->coach_rank_id); ?></h4>
                                    <h4 class="title"><b>K\D Ratio:</b> <?php echo e($coach->k_d_ratio); ?></h4>
                                    <h4 class="title"><b>Win Rate:</b> <?php echo e($coach->win_rate); ?></h4>
                                    <h4 class="title"><b>Email:</b> <?php echo e($coach->email); ?></h4><br>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div><!-- /.col -->
                            <div class="col-lg-4 invoice-col">
                                <h2 class="heading mt-0 border-bottom pb-3 border-light">Gamer Details</h2>
                               <div>
                                    <h4 class="title"><b>Name:</b> <?php echo e($gamer->fname); ?> <?php echo e($gamer->lname); ?></h4>
                                    <h4 class="title"><b>Address:</b> <?php echo e($gamer->address); ?></h4>
                                    <h4 class="title"><b>Phone:</b> <?php echo e($gamer->mobile); ?>  </h4>
                                    <h4 class="title"><b>Email:</b> <?php echo e($gamer->email); ?></h4>
                                </div>
                            </div><!-- /.col -->
                            <div class="col-lg-4 invoice-col">
                               <h2 class="heading mt-0 border-bottom pb-3 border-light">Package Details</h2>
                               <div>
                                   <?php if(session('game_id') == 1): ?>

                                    <h4 class="title"><b>Game Name:</b> <?php echo e($game_name->name); ?></h4>
                                    <h4 class="title"><b>Name:</b> <?php echo e(session('experience')); ?></h4>
                                    <h4 class="title"><b>Gaming Hours:</b> <?php echo e(session('duration')); ?></h4>
                                    <h4 class="title"><b>Total Coaches:</b> <?php echo e(session('total_coaches')); ?></h4>
                                    <?php elseif(session('game_id') == 2): ?>

                                    <h4 class="title"><b>Game Name:</b> <?php echo e($game_name->name); ?></h4>
                                    <h4 class="title"><b>Coaching Experience:</b> <?php echo e(session('coachingExp')); ?></h4>
                                    <h4 class="title"><b>Gaming Hours:</b> <?php echo e(session('duration') ? session('duration') : '-'); ?></h4>

                                       <h4 class="title"><b>Gaming Experience:</b> <?php echo e(session('experience') ? session('experience') : (session('packageGaming') ? session('packageGaming') : "-")); ?></h4>
                                           <h4 class="title"><b>Gaming Rank:</b> <?php echo e(session('rank') ? session('rank') : '-'); ?></h4>

                                    <h4 class="title"><b>Total Coaches:</b> <?php echo e(session('total_coaches')); ?></h4>

                                      <?php elseif(session('game_id') == 3): ?>

                                    <h4 class="title"><b>Game Name:</b> <?php echo e($game_name->name); ?></h4>
                                    <h4 class="title"><b>Name:</b> <?php echo e(session('experience')); ?></h4>
                                    <h4 class="title"><b>Gaming Hours:</b> <?php echo e(session('duration')); ?></h4>
                                    <h4 class="title"><b>Total Coaches:</b> <?php echo e(session('total_coaches')); ?></h4>

                                    <?php elseif(session('game_id') == 4): ?>

                                       <h4 class="title"><b>Game Name:</b> <?php echo e($game_name->name); ?></h4>
                                    <h4 class="title"><b>Gaming Package:</b> <?php if(session('package') == 14): ?> 1 Game <?php elseif(session('package') == 40): ?> 3 Games <?php elseif(session('package') == 65): ?> 5 Games <?php elseif(session('package') == 128): ?> 10 Games <?php else: ?> error <?php endif; ?> </h4>
                                       <h4 class="title"><b>Gaming Experience:</b> <?php echo e(session('gexperience')); ?></h4>
                                           <h4 class="title"><b>Gaming Rank:</b> <?php echo e(session('rank') ? session('rank') : '-'); ?></h4>
                                    <h4 class="title"><b>Total Coaches:</b> <?php echo e(session('total_coaches')); ?></h4>


                                  <?php endif; ?>
                                </div>
                            </div><!-- /.col -->
                        </div>
                    </div>
                </div>
                 <div class="col-lg-4 mt-lg-0 mt-4">
                     <div class="invoice-info">
                         <h2 class="heading mb-2 mt-0 border-bottom pb-3 border-light">Order Recap</h2>
                         <div class="row">
                             <div class="col-6">
                                 <h4 class="title">Order #</h4>
                                 <?php if($order->pacakage_id != null): ?>
                                 <h4 class="title">Package</h4>
                                 <?php endif; ?>
                                 <h4 class="title">Sub Total</h4>
                                 <h4 class="title">Discount</h4>
                                 <h4 class="title">Total</h4>
                             </div>
                             <div class="col-6 text-right">
                                 <h4 class="title"><?php echo e($order->id); ?></h4>
                                  <?php if($order->pacakage_id != null): ?>
                                 <h4 class="title"><?php echo e($order->pacakage_id); ?></h4>
                                 <?php endif; ?>
                                 <h4 class="title">$<?php echo e($order->sub_total); ?></h4>
                                 <h4 class="discount title">$0.00</h4>
                                 <h4 class="total title">$<?php echo e($order->total); ?></h4>
                             </div>

                         </div>
                     </div>
                </div><!-- /.col -->
            </div><!-- /.row -->
            <button class="btn btn-success mr-2"><a href="<?php echo e(route('gamer.index')); ?>">Back To Dashboard</a></button>
            <!-- this row will not appear when printing -->

        </section>
    </section>
</body>
</html>
<?php /**PATH /home/fpsaquaclients/public_html/resources/views/front/paid_invoice.blade.php ENDPATH**/ ?>