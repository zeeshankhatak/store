<?php $__env->startSection('title', 'Valorant - Gaming'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- body start gaming portal -->
<body class="gamePg">
    <div class="coachBanner" style="background: url(<?php echo e(asset('gaming-assets/images/Valorant-banner.jpg')); ?>) no-repeat top center;"></div>

<section class="gaming-sec">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <p class="main">Coaches will join your matches and assist you play by play while giving you the best tips and strategies to better your chances of winning. </p>
      <form method="get" class="codForm" id="call-of-duty">
              <?php echo csrf_field(); ?>
            <ul class="game-selection tabs valorant">
                
                <input type="hidden" name="pkg_id" value="4" >
                <input type="hidden" name="game_id" value="4" >
                <input type="hidden" name="currency" value="2" >

             <li class="current" data-tab="tab1"><span>1. CHOOSE YOUR GAMING PACKAGE <i class="icon-keyboard_arrow_down"></i>
                  <span class="packageid selectedValue"></span></span>
                  <div class="drop-down gaming-package tab-content" id="tab1">
                      <div class="item">
                        <input type="radio" id="d1" value="14" name="package"/>
                        <label for="d1">1 GAME - $14</label>
                      </div>
                      <div class="item">
                        <input type="radio" id="d2" value="40" name="package">
                        <label for="d2">3 GAMES - $40</label>
                      </div>
                       <div class="item">
                        <input type="radio" id="d3" value="65" name="package">
                        <label for="d3">5 GAMES- $65</label>
                      </div>
                      <div class="item">
                        <input type="radio" id="d4" value="128" name="package">
                        <label for="d4">10 GAMES - $128</label>
                      </div>
                  </div>
                </li>

              <li class="" data-tab="tab2"><span>2. CHOOSE YOUR GAMING EXPERIENCE<i class="icon-keyboard_arrow_down"></i> <span class="gexperienceid selectedValue"></span></span>
                <div class="drop-down gaming-exp tab-content" id="tab2">
                    <div class="item">
                      <input type="radio" id="ge1" value="RANKED GAMES" name="gexperience"/>
                        <label for="ge1">
                          <h2>RANKED GAMES</h2>
                          <p>- Strategic game play</p>
                          <p>- Focused on placement</p>
                          <p>- Teach you the best loadouts</p>
                        </label>
                    </div>
                    <div class="item">
                      <input type="radio" id="ge2" value="CASUAL GAMES" name="gexperience"/>
                        <label for="ge2">
                          <h2>CASUAL GAMES</h2>
                          <p>- Looking for a good time</p>
                          <p>- Enjoy skilled teammates</p>
                          <p>- Great vibes</p>
                        </label>
                    </div>

                </div>
              </li>

              <li class="gamingrank" data-tab="tab3" style="display: none;">
                  <span>2.1 CHOOSE YOUR RANK<i class="icon-keyboard_arrow_down"></i>
                    <span class="rankid selectedValue"></span></span>
                  <div class="drop-down game-rank tab-content" id="tab3">
                      <div class="item">
                        <input type="radio" id="r1" value="BRONZE" name="rank"/>
                        <label for="r1">BRONZE</label> 
                      </div>
                      <div class="item">
                        <input type="radio" id="r2" value="SILVER" name="rank">
                        <label for="r2">SILVER</label> 
                      </div>
                       <div class="item">
                        <input type="radio" id="r3" value="GOLD" name="rank">
                        <label for="r3">GOLD</label> 
                      </div>
                      <div class="item">
                        <input type="radio" id="r4" value="PLATINUM" name="rank">
                        <label for="r4">PLATINUM</label> 
                      </div>
                      <div class="item">
                        <input type="radio" id="r5" value="DIAMOND" name="rank">
                        <label for="r5">DIAMOND</label> 
                      </div>
                  </div>
                </li>


                <li><span>3. CHOOSE YOUR COACH(ES) </span>
                  <div class="drop-down choose-coach">
                      <div class="radio-buttons">
                        <input type="radio" name="chooseCoach" value="1" id="btn1"/>
                        <label for="btn1"><span class="number">1</span> Coach</label>
                        <input type="radio" name="chooseCoach" value="2" id="btn2" checked />
                        <label for="btn2"><span class="number">2</span> Coaches</label>
                      </div>
                      <div class="buttons-grp">
                        <input type="button" name="coachbtn" class="coachbtn btn1" placeholder="CHOOSE A COACH" value="CHOOSE A COACH" />
                        <input type="button" name="coachbtn" class="coachbtn btn2" placeholder="CHOOSE A COACH" value="CHOOSE A COACH" />
                        <input type="submit" name="submit" value="SUBMIT MY SESSION" />
                      </div>
                  </div>
                </li>

            </ul>

            <div class="coach-list-wrapper">
                
                
                 <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="coach-list">
                <div class="img"><img src="<?php echo e(asset('gaming-assets/images/cropped-69495847_l.jpg')); ?>"></div>

                <div class="text"><h2><?php echo e($instructor->fname); ?> <?php echo e($instructor->lname); ?></h2></div>

                <ul class="profile">
                  <li><div class="left"><h2>Languages</h2></div>
                   <div class="right"> <p><?php echo e($instructor->language); ?></p></div>
                 </li>
                  <li><div class="left"><h2>Play on</h2></div>
                    <div class="right"><p>Controller</p>
                    </li>
                  <li><div class="left"><h2>K/D</h2></div>
                    <div class="right"><p><?php echo e($instructor->k_d_ratio); ?></p></div>
                  </li>
                  <li><div class="left"><h2>Total Wins</h2></div>
                    <div class="right"><p><?php echo e($instructor->win_rate); ?></p></div>
                  </li>
                  <li><div class="left"><h2 class="charges"><sup>$</sup><?php echo e($instructor->rate); ?> /<span>per hour</br> for this Pro</span></h2></div>
                    <div class="right"><div class="chat"><a href="">CHAT WITH THIS PRO</a></div></div>
                    </li>
                </ul>
                <!--<div class="form-check">-->
                    

                <!--  </div>-->
                <div class="btn play-btn"><a href=""><input class="form-check-input" type="checkbox" name="coach_id[]" data-coach-rate="<?php echo e($instructor->rate); ?>" value="<?php echo e($instructor->coach_id); ?>" id="flexCheckDefault">PLAY WITH THIS COACH</a></div>
              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
       
            </div>
          </form>
      </div>
    </div>
  </div>
</section>

<?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>


<!-- body end gaming portal -->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('custom-script'); ?>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>



<script>

var j = $.noConflict(true);

console.log(j().jquery);


j(document).ready(function(){

    // console.log('check');
    
    
    $('input:checkbox').change(function ()
{

      var total = '';
      $('input:checkbox:checked').each(function(){
       total += parseInt($(this).attr('data-coach-rate')) + ",";
      });   
  
      $("#hidden_rate").val(total);

});

//return false;
    
     j(":checkbox").each(function () {
    
        var ischecked = j(this).is(":checked");
        var israte  = j(this).attr('data-coach-rate');
    
        if (ischecked) {
        
        j('#rate').val(j(this).attr('data-coach-rate'));
        
            checkbox_value += j(this).val();
            
          //    console.log(checkbox_value);
             
           //    console.log(israte);
        
            
        }

    });


    j('#call-of-duty').submit(function(e){

        e.preventDefault();


       // console.log('check');

         var checkbox_value = "";
        
   

                let formData = j('#call-of-duty').serialize();
                console.log(formData);
                
                
                //return false;

                j.ajax({
                    type:'GET',
                    url:'<?php echo e(route('callofduty.post')); ?>',
                    data:formData,
                    dataType: 'json',
                    success:function(response){
                        console.log(response);
                        if(response.status == 200){

                            window.open("<?php echo e(route('callofduty.insert')); ?>", "_self");
                            console.log(response.message);
                        }
                        else{
                            console.log(response.message);
                        }

                    },
                    error: function(response){
                            console.log(response.responseJSON['errors']);
                             j.each(response.responseJSON['errors'], function(i, user){
        //do something
        //console.log(i);
        alert(user[0]);
    });
                    }
                });
            });


 });



</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/valorant.blade.php ENDPATH**/ ?>