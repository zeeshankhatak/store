<?php $__env->startSection('title', 'View User - Admin'); ?>
<?php $__env->startSection('body'); ?>

    <section class="content">
        <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e(__('adminstaticword.Roles')); ?></h3>
                    </div>
                    <div class="box-header">
                        <?php if(auth()->user()->role->permission['capabilities']['role']['create']==1): ?>
                        <a class="btn btn-info btn-sm" href="<?php echo e(route('roles.create')); ?>">+
                            <?php echo e(__('adminstaticword.Add')); ?> Roles</a>
                            <?php endif; ?>

                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped table-responsive">
                                <thead>
                                    <th>#</th>
                                    <th>Name</th>
                                    <?php if(auth()->user()->role->permission['capabilities']['role']['edit']==1): ?>
                                    <th><?php echo e(__('adminstaticword.Edit')); ?></th>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role->permission['capabilities']['role']['delete']==1): ?>
                                    <th><?php echo e(__('adminstaticword.Delete')); ?></th>
                                    <?php endif; ?>
                                </thead>

                                <tbody>

                                    <?php $i = 0; ?>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <?php $i++; ?>

                                            <td>
                                                <?php echo $i; ?>
                                            </td>
                                            <td>
                                                <?php echo e($role->name); ?>

                                            </td>
                                            <?php if(auth()->user()->role->permission['capabilities']['role']['edit']==1): ?>
                                            <td>
                                                <a class="btn btn-success btn-sm"
                                                    href="<?php echo e(route('roles.edit', $role->role_id)); ?>">
                                                    <i class="glyphicon glyphicon-pencil"></i></a>
                                            </td>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->role->permission['capabilities']['role']['delete']==1): ?>
                                            <td>
                                                <form method="post" action="<?php echo e(route('roles.destroy', $role->role_id)); ?>

                                                      " data-parsley-validate class="form-horizontal form-label-left">
                                                    <?php echo e(csrf_field()); ?>

                                                    <?php echo e(method_field('DELETE')); ?>


                                                    <button onclick="return confirm('Are you sure you want to delete?')"
                                                        type="submit" class="btn btn-danger btn-sm"><i
                                                            class="fa fa-fw fa-trash-o"></i></button>
                                                </form>
                                            </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/admin/roles/index.blade.php ENDPATH**/ ?>