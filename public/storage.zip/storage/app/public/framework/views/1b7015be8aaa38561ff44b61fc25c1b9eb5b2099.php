<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <?php if(Auth::User()->user_img != null || Auth::User()->user_img != ''): ?>
                    <img src="<?php echo e(asset('images/user_img/' . Auth::User()->user_img)); ?>" class="img-circle"
                        alt="User Image">

                <?php else: ?>
                    <img src="<?php echo e(asset('images/default/user.jpg')); ?>" class="img-circle" alt="User Image">

                <?php endif; ?>
            </div>
            <div class="pull-left info">
                <p><?php echo e(Auth::User()->fname); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e(__('adminstaticword.Online')); ?></a>
            </div>
        </div>

        
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header"><?php echo e(__('adminstaticword.Navigation')); ?></li>

            <li class="<?php echo e(Route::is('admin.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.index')); ?>"><i
                        class="fa fa-tachometer"
                        aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Dashboard')); ?></span></a></li>

            <li
                class="<?php echo e(Route::is('user.index') ? 'active' : ''); ?> <?php echo e(Route::is('user.add') ? 'active' : ''); ?> <?php echo e(Route::is('user.edit') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('user.index')); ?>"><i class="fa fa-user-o"
                        aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Gamer')); ?></span></a>
            </li>



            <li class="<?php echo e(Route::is('all.instructor')); ?> <?php echo e(Route::is('requestinstructor.index')); ?> treeview">
                <a href="#">
                    <i class="fa fa-user-plus" aria-hidden="true"></i>
                    <span><?php echo e(__('adminstaticword.Instructor')); ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(Route::is('all.instructor') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('all.instructor')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.AllInstructor')); ?></a></li>
                    <li class="<?php echo e(Route::is('requestinstructor.index') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('requestinstructor.index')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.InstructorRequest')); ?></a></li>
                </ul>
            </li>

            <?php if(isset($zoom_enable) && $zoom_enable == 1): ?>
                <li
                    class="<?php echo e(Route::is('meeting.create')); ?> <?php echo e(Route::is('zoom.show')); ?> <?php echo e(Route::is('zoom.edit')); ?> <?php echo e(Route::is('zoom.setting')); ?> <?php echo e(Route::is('zoom.index')); ?> <?php echo e(Route::is('meeting.show')); ?> treeview">
                    <a href="#">
                        <i class="fa fa-grav" aria-hidden="true"></i> <span><?php echo e(__('Zoom Live Meetings')); ?></span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li class="<?php echo e(Route::is('zoom.setting')); ?>"><a href="<?php echo e(route('zoom.setting')); ?>"><i
                                    class="fa fa-circle-o"></i><?php echo e(__('Zoom Settings')); ?></a></li>
                        <li
                            class="<?php echo e(Route::is('zoom.index')); ?> <?php echo e(Route::is('zoom.show')); ?> <?php echo e(Route::is('zoom.edit')); ?> <?php echo e(Route::is('meeting.create')); ?>">
                            <a href="<?php echo e(route('zoom.index')); ?>"><i
                                    class="fa fa-circle-o"></i><?php echo e(__('Zoom Dashboard')); ?></a>
                        </li>
                        <li class="<?php echo e(Route::is('meeting.show')); ?>"><a href="<?php echo e(route('meeting.show')); ?>"><i
                                    class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.AllMeetings')); ?></a></li>
                    </ul>
                </li>
            <?php endif; ?>

            <?php if(isset($gsetting) && $gsetting->bbl_enable == 1): ?>
                <li class="<?php echo e(Route::is('bbl.setting')); ?> <?php echo e(Route::is('bbl.all.meeting')); ?> treeview">
                    <a href="#">
                        <i class="fa fa-grav" aria-hidden="true"></i> <span><?php echo e(__('Big Blue Meetings')); ?></span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a>
                    <ul class="treeview-menu">
                        <li class="<?php echo e(Route::is('bbl.setting')); ?>"><a href="<?php echo e(route('bbl.setting')); ?>"><i
                                    class="fa fa-circle-o"></i><?php echo e(__('Big Blue Button Settings')); ?></a></li>
                        <li class="<?php echo e(Route::is('bbl.all.meeting')); ?>"><a href="<?php echo e(route('bbl.all.meeting')); ?>"><i
                                    class="fa fa-circle-o"></i><?php echo e(__('List Meetings')); ?></a></li>
                    </ul>
                </li>
            <?php endif; ?>

            <li
                class="<?php echo e(Route::is('country.index') ? 'active' : ''); ?> <?php echo e(Route::is('state.index') ? 'active' : ''); ?> <?php echo e(Route::is('city.index') ? 'active' : ''); ?> treeview">
                <a href="#">
                    <i class="fa fa-globe" aria-hidden="true"></i>
                    <span><?php echo e(__('adminstaticword.Location')); ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(Route::is('country.index') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('country.index')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.Country')); ?></a></li>
                    <li class="<?php echo e(Route::is('state.index') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('state.index')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.State')); ?></a></li>
                    <li class="<?php echo e(Route::is('city.index') ? 'active' : ''); ?>"><a
                            href="<?php echo e(route('city.index')); ?>"><i
                                class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.City')); ?></a></li>
                </ul>
            </li>

            <li class="<?php echo e(Route::is('currency.index') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('currency.index')); ?>"> <i
                        class="fa fa-money"></i><span><?php echo e(__('adminstaticword.Currency')); ?></span></a>
            </li>

            
            <li class="<?php echo e(Route::is('course.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('course.index')); ?>"><i
                        class="fa fa-book"
                        aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Course')); ?></span></a></li>


            

            
            
            
            
            


            

            

            
            
            
            

            <li class="<?php echo e(Route::is('coupon.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('coupon.index')); ?>"><i
                        class="fa fa-tags"
                        aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Coupon')); ?></span></a></li>


            <li class="<?php echo e(Route::is('order.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('order.index')); ?>"><i
                        class="fa fa-history"
                        aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Order')); ?></span></a></li>

            

            
            
                
                
            

            
            
                
                

                

            

            
            
                
                
            

            
            
                
                
                
                
                
                
                
                
            

            <li class="<?php echo e(Route::is('gen.set')); ?> <?php echo e(Route::is('api.setApiView')); ?> <?php echo e(Route::is('blog.index')); ?> <?php echo e(Route::is('about.page')); ?> <?php echo e(Route::is('careers.page')); ?> <?php echo e(Route::is('comingsoon.page')); ?> <?php echo e(Route::is('termscondition')); ?> <?php echo e(Route::is('policy')); ?> <?php echo e(Route::is('bank.transfer')); ?> <?php echo e(Route::is('show.pwa')); ?> <?php echo e(Route::is('adsense')); ?> treeview">
            <a href="#">
                <i class="fa fa-cogs" aria-hidden="true"></i>
                <span><?php echo e(__('adminstaticword.SiteSetting')); ?></span>
                <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                </span>
            </a>
            <ul class="treeview-menu">
                <li class="<?php echo e(Route::is('gen.set')); ?>"><a href="<?php echo e(route('gen.set')); ?>"><i class="fa fa-circle-o"></i><span><?php echo e(__('adminstaticword.Setting')); ?></span></a></li>
                <li class="<?php echo e(Route::is('api.setApiView')); ?>"><a href="<?php echo e(route('api.setApiView')); ?>"><i class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.APISetting')); ?></a></li>

                <li class="<?php echo e(Route::is('blog')); ?>"><a href="<?php echo e(url('blog')); ?>"><i class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.Blog')); ?></a></li>
                <li class="<?php echo e(Route::is('about.page')); ?>"><a href="<?php echo e(route('about.page')); ?>"><i class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.About')); ?></a></li>
                <li class="<?php echo e(Route::is('careers.page')); ?>"><a href="<?php echo e(route('careers.page')); ?>"><i class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.Career')); ?></a></li>
                <li class="<?php echo e(Route::is('comingsoon.page')); ?>"><a href="<?php echo e(route('comingsoon.page')); ?>"><i class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.ComingSoon')); ?></a></li>
                <li class="<?php echo e(Route::is('termscondition')); ?>"><a href="<?php echo e(route('termscondition')); ?>"><i class="fa fa-circle-o"></i><?php echo e(__('adminstaticword.Terms&Condition')); ?> </a></li>
                <li class="<?php echo e(Route::is('policy')); ?>"><a href="<?php echo e(route('policy')); ?>"><i class="fa fa-circle-o"></i> <?php echo e(__('adminstaticword.PrivacyPolicy')); ?></a></li>

                <li class="<?php echo e(Route::is('bank.transfer')); ?>"><a href="<?php echo e(route('bank.transfer')); ?>"><i class="fa fa-circle-o"></i> <?php echo e(__('adminstaticword.BankDetails')); ?></a></li>

                <li class="<?php echo e(Route::is('show.pwa')); ?>"><a href="<?php echo e(route('show.pwa')); ?>"><i class="fa fa-circle-o" aria-hidden="true"></i><span> <?php echo e(__('adminstaticword.PWASetting')); ?></span></a></li>
                <li class="<?php echo e(Route::is('adsense')); ?>"><a href="<?php echo e(url('/admin/adsensesetting')); ?>" title="Page Setting"><span><i class="fa fa-circle-o"></i> &nbsp;&nbsp;<?php echo e(__('adminstaticword.AdsenseSetting')); ?></span></a></li>
            </ul>
            </li>

            
            

                

                
                <?php $ads = App\Ads::all(); ?>
                <?php if($ads->count() > 0): ?>
                    
                <?php endif; ?>

            

            <li class="<?php echo e(Route::is('show.lang')); ?>"><a href="<?php echo e(route('show.lang')); ?>"><i class="fa fa-language" aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Language')); ?></span></a></li>

            <li class="<?php echo e(Route::is('usermessage')); ?>"><a href="<?php echo e(route('usermessage.index')); ?>"><i class="fa fa-phone" aria-hidden="true"></i><span><?php echo e(__('adminstaticword.ContactUs')); ?></span></a></li>


        </ul>
        


    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH /home/centauruscrm/fps.centauruscrm.com/Osama/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>