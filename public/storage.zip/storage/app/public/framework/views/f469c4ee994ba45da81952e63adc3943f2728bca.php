<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- body start gaming portal -->
<body id="bottomtotop" class="aboutPg">
<section class="aboutBanner">
  <div class="overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="content">
          <h1 class="">
            <span class="built">Built by </span>
            <span class="gamers">Gamers</span>
            <span class="for-underline"> for </span>
          Gamers</h1>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="we-are">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="content">
          <h1 class="">WE ARE <span class="redColor"> FPS Lounge</span></h1>
          <p>Brandon Rosen and Derek Taing founded FPS Lounge based on two corner stones, building a stronger gaming community where players feel comfortable learning from pros as well as creating opportunities for gamers to do what they love for a living.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="co-founder">
  <div class="box" data-aos="fade-right" data-aos-delay="300" data-aos-duration="600">
    <div class="container">
      <div class="wrapper">
          <div class="image">
            <figure><img src="<?php echo e(asset('gaming-assets/images/co-founder1.png')); ?>"></figure>
            <h1 class="heading-stroke"> <span>24</span>  year old</h1>
          </div>
          <div class="text">
            <h3>Co-Founder</h3>
            <h1 class="heading-stroke"> <span>Derek</span>  Taing</h1>
            <h4 class="">Favorite Game of All-time: <span class="redColor"> Apex Legends</span></h4>
            <p>For as long as I’ve been playing games I’ve always had a drive for competing. I started off in 2017 with Tom Clancy’s Rainbow Six Siege, which I would compete in small tournaments here and there and enjoyed the thrill of winning with my team or losing and striving to be better. There were definitely downsides to getting into the competitive scene with no experience or connections which I thought was always a problem for players wanting to get competitive and not knowing where to start. From then, I went on to PlayerUnknown’s Battlegrounds where I competed for a bit until Apex Legends came out, which is where I met Brandon. We shared the same vision and aspirations to help others get started. We decided to create something that could allow players to learn from pros first hand while showing them where to start to get involved in competitive gaming. This would also allow both the coaches and the players to better their quality of life. Our vision is to provide our coaches the ability to gain financial support playing the games they love, while new players who are lost find a sherpa to guide them in the right direction. Seemed like a win win situation to me. Welcome to the FPS Lounge!</p>
          </div>
          </div>
      </div>
    </div>
  </div>
  <div class="box" data-aos="fade-left" data-aos-delay="300" data-aos-duration="600">
    <div class="container">
       <div class="wrapper">
            <div class="text">
              <h3>Co-Founder</h3>
              <h1 class="heading-stroke"> <span>BRANDON </span>  ROSEN</h1>
              <h4 class="">Favorite Game of All-time: <span class="redColor"> HALO-2</span></h4>
              <p>I’ve had a passion for video games my whole life. While playing Apex Legends competitively I met Derek Taing aka TaingySauce and we quickly became good friends. We started competing together and soon came to realized we had similar aspirations. We started FPS as a passion project with two goals in mind, create a place where gamers feel comfortable learning from the best and to monetize the industry for gamers. We hope to provide a means for gamers to do what they love for a living. Welcome to the FPS lounge!</p>
            </div>
            <div class="image">
              <figure><img src="<?php echo e(asset('gaming-assets/images/co-founder2.png')); ?>"></figure>
              <h1 class="heading-stroke"> <span>30</span>  year old</h1>
            </div>
       </div>
    </div>
  </div>
</section>

<?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<!-- body end gaming portal -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\findprosquad\resources\views/about-us.blade.php ENDPATH**/ ?>