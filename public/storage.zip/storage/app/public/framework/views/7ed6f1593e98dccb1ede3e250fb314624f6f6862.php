<!-- Gaming Portal js start -->

<!-- Gaming Portal js start -->






	


    




<?php echo $__env->yieldContent('custom-script'); ?>
<?php /**PATH /home/fpsaquaclients/public_html/resources/views/theme/scripts.blade.php ENDPATH**/ ?>