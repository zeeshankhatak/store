<?php $__env->startSection('title', 'Dashboard - Admin'); ?>
<?php $__env->startSection('body'); ?>


<section class="content-header">
  <h1>
    <?php echo e(__('adminstaticword.Dashboard')); ?>

    <small></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i><?php echo e(__('adminstaticword.Home')); ?></a></li>
    <li class="active"><?php echo e(__('adminstaticword.Dashboard')); ?></li>
  </ol>
</section>
<section class="content">
	<!-- Main row -->
    <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>
              	<?php
              		$user = App\User::where('user_type', 3)->get();
              		if(count($user)>0){

              			echo count($user);
              		}
              		else{

              			echo "0";
              		}
              	?>
              </h3>
              <p><?php echo e(__('adminstaticword.Users')); ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(route('user.index')); ?>" class="small-box-footer"><?php echo e(__('adminstaticword.Moreinfo')); ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      
  
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>
              	<?php
              		$page = App\Order::all();
              		if(count($page)>0){

              			echo count($page);
              		}
              		else{

              			echo "0";
              		}
              	?>
              </h3>
              <p><?php echo e(__('adminstaticword.Orders')); ?></p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="<?php echo e(route('order.index')); ?>" class="small-box-footer"><?php echo e(__('adminstaticword.Moreinfo')); ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
     
   
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3>
                <?php
              		$review = App\Instructor::all();
              		if(count($review)>0){

              			echo count($review);
              		}
              		else{

              			echo "0";
              		}
              	?>
              </h3>
              <p><?php echo e(__('adminstaticword.Coaches')); ?></p>
            </div>
            <div class="icon">
             <i class="fa fa-user"></i>
            </div>
            <a href="<?php echo e(route('all.instructor')); ?>" class="small-box-footer"><?php echo e(__('adminstaticword.Moreinfo')); ?> <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div> 
        <!-- ./col -->
   
    </div>
    <!-- /.row -->

	<!-- Main row -->
	<div class="row">
		<!-- Left col -->
    <div class="col-md-6">
      <!-- USERS LIST -->
      <div class="box box-danger">
          <div class="box-header with-border">
            <h3 class="box-title"><?php echo e(__('adminstaticword.LatestUsers')); ?></h3>

            <div class="box-tools pull-right">
              <span class="label label-danger">
                <?php
                    $user = App\User::all();
                    if(count($user)>0){

                      echo count($user);
                    }
                    else{

                      echo "0";
                    }
                  ?>
                <?php echo e(__('adminstaticword.Users')); ?>

            </span>
              <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
              </button>
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
              </button>
            </div>
          </div>
          <!-- /.box-header -->
          <div class="box-body no-padding">
            <?php
              $users = App\User::limit(8)->orderBy('id', 'DESC')->where('user_type', 3)->get();
            ?>
            <ul class="users-list clearfix">
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <?php if($user['user_img'] != null || $user['user_img'] !=''): ?>
                  <img src="<?php echo e(asset('/images/gamer/'.$user['user_img'])); ?>" class="img-fluid" alt="User Image">
                <?php else: ?>
                  <img src="<?php echo e(asset('images/default/user.jpg')); ?>" class="img-fluid" alt="User Image">
                <?php endif; ?>
                <a class="users-list-name" href="#"><?php echo e($user['fname']); ?> <?php echo e($user['lname']); ?></a>
                <span class="users-list-date"><?php echo e(date('F Y', strtotime($user['created_at']))); ?></span>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
            <!-- /.users-list -->
          </div>
          <!-- /.box-body -->
          <div class="box-footer text-center">
            <a href="<?php echo e(route('user.index')); ?>" class="uppercase"><?php echo e(__('adminstaticword.ViewAll')); ?></a>
          </div>
          <!-- /.box-footer -->
      </div>
      <!--/.box -->

   
      <!-- /.box -->
    </div>
    <!-- /.col -->
		<div class="col-md-6">

      <!-- Instructor box -->
      <?php
        $instructors = App\Instructor::limit(8)->orderBy('id', 'DESC')->get();
      ?>
      <?php if( !$instructors->isEmpty() ): ?>
      <div class="box box-success">
        <div class="box-header">
          <i class="fa fa-user-plus"></i>

          <h3 class="box-title">Latest Coaches</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
          </div>
        </div>
        <div class="box-body chat" id="chat-box">
          <!-- chat item -->

          <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($instructor->status == 0): ?>
            <div class="item">
              <img src="<?php echo e(asset('images/coach/'.$instructor['image'])); ?>" alt="user image" class="online">

              <p class="message">
                <a href="#" class="name">
                  <small class="text-muted pull-right"><i class="fa fa-calendar-check-o"></i>&nbsp;<?php echo e(date('jS F Y', strtotime($instructor['created_at']))); ?></small>
                  <?php echo e($instructor['fname']); ?>&nbsp;<?php echo e($instructor['lname']); ?>

                </a>
                <?php echo e(Str::limit($instructor['detail'], $limit = 160, $end = '...')); ?>

              </p>
          
            </div>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- /.item -->
        </div>
        <!-- /.chat -->
        <div class="box-footer text-center">
          <a href="<?php echo e(route('all.instructor')); ?>" class="btn pull-left"><?php echo e(__('adminstaticword.AllInstructor')); ?></a>
        </div>
      </div>
      <?php endif; ?>
      <!-- /.box (Instructor box) -->
		</div>
		<!-- /.col -->
	</div>
	<!-- /.row -->
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>