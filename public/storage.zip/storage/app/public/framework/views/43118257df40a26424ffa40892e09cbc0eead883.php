<?php $__env->startSection('title', 'Gamer Wallet - Admin'); ?>
<?php $__env->startSection('body'); ?>

<section class="content">
  <?php echo $__env->make('gamer.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




  <div class="row">

    <?php echo $__env->make('admin.user.tabs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-9">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"> <?php echo e(__('adminstaticword.Wallet')); ?></h3>
        </div>

        <!-- /.box-header -->
        <div class="box-body">
            <label for="">Current Balance</label>&nbsp;&nbsp;&nbsp;
            <?php if($current_bal != null): ?>
            <span>$ <?php echo e($current_bal->total); ?></span>
            <?php else: ?>
            <span>$ 0.00</span>
            <?php endif; ?>
          <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">
              <thead>

                <br>
                <br>
                <tr>
                  <th>#</th>
                  <th><?php echo e(__('adminstaticword.Deposite')); ?></th>
                  <th><?php echo e(__('adminstaticword.Withdrawal')); ?></th>
                  <th><?php echo e(__('adminstaticword.Total')); ?></th>
                  <th><?php echo e(__('adminstaticword.Date')); ?></th>

                </tr>
              </thead>
              <tbody>
              <?php $i=0;?>
              <?php $__currentLoopData = $wallet_infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            

                <?php $i++;?>
                <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo e($wallet_info->credit_amount); ?></td>

                  <td>

                    <?php if($wallet_info->debit_amount == NULL): ?>
                      <?php echo e($wallet_info->debit_amount = '-'); ?>

                    <?php else: ?>
                      <?php echo e($wallet_info->debit_amount); ?>

                    <?php endif; ?>
                  </td>

                  
                  <td><?php echo e($wallet_info->total); ?></td>
                  <td><?php echo e($wallet_info->date); ?></td>

                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/admin/user/tabs/wallet/index.blade.php ENDPATH**/ ?>