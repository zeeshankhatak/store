
<?php $__env->startSection('title', 'Pricing'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- body start gaming portal -->

<section class="pricing">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="content">
          <h1 class="" data-aos="fade-in" data-aos-delay="300" data-aos-duration="1000">STANDARD <span class="redColor">PRICING</span></h1>
          <h3>for Warzone, Apex and Fortnite</h3>
          <p>Our coaches can help you improve your game, complete video reviews to point out mistakes or just go out <br>there to have a good time.</p>
        </div>
        <div class="price-bx">
          <div class="top">
            <div class="price"><span class="currency">$</span>14<span class="period">/ Hour for Pro Coaching</span></div>
          </div>
          <div class="bottom">
              <ul class="features-list">
                <li><i class="icon-check_circle_outline"></i>Play with a Pro gamer in the top 1% in the world.</li>
                <li><i class="icon-check_circle_outline"></i>Increase your win rate and improve your K/D.</li>
                <li><i class="icon-check_circle_outline"></i>Enjoy great vibes.</li>
              </ul>
              <a class="btn" href="#">Add Funds</a>
          </div>
        </div>

      </div>
    </div>
  </div>
</section>

<section class="game-packages">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="content">
          <h1 class="" data-aos="fade-in" data-aos-delay="300" data-aos-duration="1000">GAME  <span class="redColor">PACKAGES</span></h1>
          <p>Let our coaches take you to the next level. We guarantee they will help you develop the skills you need to achieve the next rank.</p>
        </div>
      </div>
    </div>
  </div>
  <div class="wrapper">
    <div class="container">
       <div class="pkg-bx">
         <h1 class="" data-aos="fade-in" data-aos-delay="300" data-aos-duration="1000">RANKING SYSTEM</h1>
         <ul>
           <li>
              <img src="<?php echo e(asset('gaming-assets/images/Bronze.png')); ?>">
              <div class="rate">
                  <h2><span>$</span>60</h2>
                  <p>Bronze to Silver</p>
              </div>
              <img src="<?php echo e(asset('gaming-assets/images/Silver.png')); ?>">
           </li>
           <li>
              <img src="<?php echo e(asset('gaming-assets/images/Silver.png')); ?>">
              <div class="rate">
                  <h2><span>$</span>75</h2>
                  <p>Silver to Gold</p>
              </div>
              <img src="<?php echo e(asset('gaming-assets/images/Gold.png')); ?>">
           </li>
           <li>
              <img src="<?php echo e(asset('gaming-assets/images/Gold.png')); ?>">
              <div class="rate">
                  <h2><span>$</span>150</h2>
                  <p>Gold to Platinum</p>
              </div>
              <img src="<?php echo e(asset('gaming-assets/images/Platinum.png')); ?>">
           </li>
           <li>
              <img src="<?php echo e(asset('gaming-assets/images/Platinum.png')); ?>">
              <div class="rate">
                  <h2><span>$</span>275</h2>
                  <p>Platinum to Diamond</p>
              </div>
              <img src="<?php echo e(asset('gaming-assets/images/Diamond.png')); ?>">
           </li>
         </ul>
         <a class="btn" href="#">Add Funds</a>
       </div>
       <div class="img-bx">
         <img src="<?php echo e(asset('gaming-assets/images/apez.png')); ?>">
       </div>
    </div>
   </div>

  <div class="wrapper">
    <div class="container">
      <div class="img-bx">
         <img src="<?php echo e(asset('gaming-assets/images/White-Filling.png')); ?>">
       </div>
      <div class="pkg-bx">
         <ul>
           <li>
              <div class="rate">
                  <h2><span>$</span>14</h2>
                  <p>1 Game</p>
              </div>
           </li>
           <li>
              <div class="rate">
                  <h2><span>$</span>40</h2>
                  <p>3 Game</p>
              </div>
           </li>
           <li>
              <div class="rate">
                  <h2><span>$</span>65</h2>
                  <p>5 Game</p>
              </div>
           </li>
           <li>
              <div class="rate">
                  <h2><span>$</span>128</h2>
                  <p>10 Game</p>
              </div>
           </li>
         </ul>
         <a class="btn" href="#">Add Funds</a>
       </div>
    </div>
  </div>
</section>

<?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- body end gaming portal -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/centauruscrm/fps.centauruscrm.com/Osama/resources/views/pricing.blade.php ENDPATH**/ ?>