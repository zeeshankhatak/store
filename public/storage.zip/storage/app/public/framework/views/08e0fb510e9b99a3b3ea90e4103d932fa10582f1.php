<?php $__env->startSection('title', 'Apex Legends'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- body start gaming portal -->
<body class="gamePg">
    <div class="coachBanner" style="background: url(<?php echo e(asset('gaming-assets/images/apex-banner.png')); ?>) no-repeat top center;"></div>

    <section class="gaming-sec">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
              <p class="main">Coaches work closely with the players to identify their strengths and weaknesses, motivate them, and make sure they are playing at their best. </p>
               <form method="get" class="codForm" id="call-of-duty">
              <?php echo csrf_field(); ?>
                <ul class="game-selection tabs">
                    
                       <input type="hidden" name="pkg_id" value="2" >
                <input type="hidden" name="game_id" value="2" >
                <input type="hidden" name="currency" value="2" >
                    
                    <li class="" data-tab="tab1">
                      <span>1. CHOOSE YOUR COACHING EXPERIENCE<i class="icon-keyboard_arrow_down"></i>
                        <span class="coachingExpid selectedValue"></span></span>
                      <div class="drop-down tab-content" id="tab1">
                          <div class="item">
                            <input type="radio" id="ce1" value="HOURLY" name="coachingExp"/>
                            <label for="ce1">HOURLY GAMING</label>
                          </div>
                          <div class="item">
                            <input type="radio" id="ce2" value="GAMING" name="coachingExp">
                            <label for="ce2">GAMING PACKAGES</label>
                          </div>
                      </div>
                    </li>

                    <li class="hours" style="display: none;" data-tab="duration">
                      <span>1.1. HOW MANY HOURS DO YOU WANT TO PLAY? <i class="icon-keyboard_arrow_down"></i>
                        <span class="durationid selectedValue"></span></span>
                      <div class="drop-down gaming-duration tab-content" id="duration">
                          <div class="item">
                            <input type="radio" id="d1" value="1 HOUR" name="duration"/>
                            <label for="d1">1 HOUR</label>
                          </div>
                          <div class="item">
                            <input type="radio" id="d2" value="2 HOUR" name="duration">
                            <label for="d2">2 HOUR</label>
                          </div>
                           <div class="item">
                            <input type="radio" id="d3" value="3 HOUR" name="duration">
                            <label for="d3">3 HOUR</label>
                          </div>
                      </div>
                    </li>

                  <li class="gamingExp" data-tab="gamingExp">
                    <span>2. CHOOSE YOUR GAMING EXPERIENCE<i class="icon-keyboard_arrow_down"></i>
                     <span class="experienceid selectedValue"></span></span>
                    <div class="drop-down gaming-exp tab-content" id="gamingExp">
                        <div class="item">
                          <input type="radio" id="e1" value="RANKED GAMES" name="experience"/>
                            <label for="e1">
                              <h2>RANKED GAMES</h2>
                              <p>- Improve stats</p>
                              <p>- Learn the best tips and tricks</p>
                              <p>- Teach you the best loadouts and weapon mods</p>
                            </label>
                        </div>
                        <div class="item">
                          <input type="radio" id="e2" value="CASUAL GAMES" name="experience"/>
                            <label for="e2">
                              <h2>CASUAL GAMES</h2>
                              <p>- Looking for a good time</p>
                              <p>- Enjoy skilled teammates</p>
                              <p>- Great vibes</p>
                            </label>
                        </div>
                         <div class="item">
                          <input type="radio" id="e3" value="VIDEO REVIEWS" name="experience"/>
                            <label for="e3">
                              <h2>VIDEO REVIEWS</h2>
                              <p>Allow our coaches to rewatch film of your gameplay and analyze how to make better decisions.</p>
                            </label>
                        </div>
                    </div>
                  </li>

                  <li class="your-rank" style="display: none;" data-tab="rank">
                      <span>2.1 CHOOSE YOUR RANK<i class="icon-keyboard_arrow_down"></i>
                        <span class="rankid selectedValue"></span></span>
                      <div class="drop-down game-rank tab-content" id="rank">
                          <div class="item">
                            <input type="radio" id="r1" value="BRONZE" name="rank"/>
                            <label for="r1">BRONZE</label>
                          </div>
                          <div class="item">
                            <input type="radio" id="r2" value="SILVER" name="rank">
                            <label for="r2">SILVER</label>
                          </div>
                           <div class="item">
                            <input type="radio" id="r3" value="GOLD" name="rank">
                            <label for="r3">GOLD</label>
                          </div>
                          <div class="item">
                            <input type="radio" id="r4" value="PLATINUM" name="rank">
                            <label for="r4">PLATINUM</label>
                          </div>
                          <div class="item">
                            <input type="radio" id="r5" value="DIAMOND" name="rank">
                            <label for="r5">DIAMOND</label>
                          </div>
                      </div>
                    </li>

                   <li class="packageGamingExp" data-tab="packageGamingExp" style="display: none;">
                    <span>2. CHOOSE YOUR GAMING EXPERIENCE<i class="icon-keyboard_arrow_down"></i>
                     <span class="packageGamingid selectedValue"></span></span>
                    <div class="drop-down tab-content" id="packageGamingExp">
                        <div class="item">
                            <input type="radio" id="pg1" value="60" name="packageGaming"/>
                            <label for="pg1">BRONZE TO SILVER -$60</label>
                          </div>
                          <div class="item">
                            <input type="radio" id="pg2" value="70" name="packageGaming">
                            <label for="pg2">SILVER TO GOLD - $70</label>
                          </div>
                           <div class="item">
                            <input type="radio" id="pg3" value="150" name="packageGaming">
                            <label for="pg3">GOLD TO PLAT - $150</label>
                          </div>
                          <div class="item">
                            <input type="radio" id="pg4" value="275" name="packageGaming">
                            <label for="pg4">PLAT TO DIAMOND -$275</label>
                          </div>
                    </div>
                  </li>

                    <li><span>3. CHOOSE YOUR COACH(ES) </span>
                      <div class="drop-down choose-coach">
                          <div class="radio-buttons">
                            <input type="radio" name="chooseCoach" value="Coach" id="btn1"/>
                            <label for="btn1"><span class="number">1</span> Coach</label>
                            <input type="radio" name="chooseCoach" value="Coaches" id="btn2" checked />
                            <label for="btn2"><span class="number">2</span> Coaches</label>
                          </div>
                          <div class="buttons-grp">
                            <input type="button" name="coachbtn" class="coachbtn btn1" placeholder="CHOOSE A COACH" value="CHOOSE A COACH" />
                            <input type="button" name="coachbtn" class="coachbtn btn2" placeholder="CHOOSE B COACH" value="CHOOSE B COACH" />
                            <input type="submit" name="submit" value="SUBMIT MY SESSION" class="btn_submit" />

                          </div>
                      </div>
                    </li>

                </ul>

                <div class="coach-list-wrapper">
                    
                                    <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="coach-list">
                <div class="img"><img src="<?php echo e(asset('gaming-assets/images/cropped-69495847_l.jpg')); ?>"></div>

                <div class="text"><h2><?php echo e($instructor->fname); ?> <?php echo e($instructor->lname); ?></h2></div>

                <ul class="profile">
                  <li><div class="left"><h2>Languages</h2></div>
                   <div class="right"> <p><?php echo e($instructor->language); ?></p></div>
                 </li>
                  <li><div class="left"><h2>Play on</h2></div>
                    <div class="right"><p>Controller</p>
                    </li>
                  <li><div class="left"><h2>K/D</h2></div>
                    <div class="right"><p><?php echo e($instructor->k_d_ratio); ?></p></div>
                  </li>
                  <li><div class="left"><h2>Total Wins</h2></div>
                    <div class="right"><p><?php echo e($instructor->win_rate); ?></p></div>
                  </li>
                  <li><div class="left"><h2 class="charges"><sup>$</sup><?php echo e($instructor->rate); ?> /<span>per hour</br> for this Pro</span></h2></div>
                    <div class="right"><div class="chat"><a href="">CHAT WITH THIS PRO</a></div></div>
                    </li>
                </ul>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="coach_id[]" data-coach-rate="<?php echo e($instructor->rate); ?>" value="<?php echo e($instructor->coach_id); ?>" id="flexCheckDefault">

                  </div>
                <div class="btn play-btn"><a href="">PLAY WITH THIS COACH</a></div>
              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
                                  <input type="hidden" name="coach_rate" id="hidden_rate" value="" />
                                  
                                  
       
                </div>
              </form>
          </div>
        </div>
      </div>
    </section>

    <?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>



<script>

var j = $.noConflict(true);

console.log(j().jquery);


j(document).ready(function(){

    // console.log('check');
    
    
    $('input:checkbox').change(function ()
{

      var total = '';
      $('input:checkbox:checked').each(function(){
       total += parseInt($(this).attr('data-coach-rate')) + ",";
      });   
  
      $("#hidden_rate").val(total);

});

//return false;
    
     j(":checkbox").each(function () {
    
        var ischecked = j(this).is(":checked");
        var israte  = j(this).attr('data-coach-rate');
    
        if (ischecked) {
        
        j('#rate').val(j(this).attr('data-coach-rate'));
        
            checkbox_value += j(this).val();
            
          //    console.log(checkbox_value);
             
           //    console.log(israte);
        
            
        }

    });


    j('#call-of-duty').submit(function(e){

        e.preventDefault();


       // console.log('check');

         var checkbox_value = "";
        
   

                let formData = j('#call-of-duty').serialize();
                console.log(formData);
                
                
                //return false;

                j.ajax({
                    type:'GET',
                    url:'<?php echo e(route('callofduty.post')); ?>',
                    data:formData,
                    dataType: 'json',
                    success:function(response){
                        console.log(response);
                        if(response.status == 200){

                            window.open("<?php echo e(route('callofduty.insert')); ?>", "_self");
                            console.log(response.message);
                        }
                        else{
                            console.log(response.message);
                        }

                    }
                });
            });


 });



</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/apex-legends.blade.php ENDPATH**/ ?>