<!-- Gaming Portal js start -->

<!-- Gaming Portal js start -->



<script src='https://www.google.com/recaptcha/api.js'></script>


	


    




<?php echo $__env->yieldContent('custom-script'); ?>
<?php /**PATH C:\xampp\htdocs\findprosquad\resources\views/theme/scripts.blade.php ENDPATH**/ ?>