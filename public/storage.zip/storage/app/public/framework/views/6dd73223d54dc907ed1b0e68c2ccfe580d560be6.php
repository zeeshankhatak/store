<?php $__env->startSection('title', 'Become a Coach'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- body start gaming portal -->
<body class="beCoachPg" id="bottomtotop">
<section class="coaching-sec">
  <div class="container">
     <div class="wrapper">
        <div class="row">
          <div class="col-md-6">
             <div class="img-bx"><img src="<?php echo e(asset('gaming-assets/images/form.png')); ?>"></div>
          </div>
          <div class="col-md-6 my-auto">
            <div class="text-bx">
              <h1 class="">APPLY TO BECOME<span class="redColor"> A COACH</span></h1>
              <p>Get Approved and become an FPS Coach! We expect all who apply to be in the top 1% of their respective games.</p>
              <a href="#" class="btn" role="button">Apply now</a>
            </div>
          </div>
        </div>
     </div>
     <div class="wrapper">
        <div class="row">
          <div class="col-md-6 my-auto">
            <div class="text-bx">
              <h1 class="">START<span class="redColor"> COACHING</span></h1>
              <p>Accept Orders and start gaming</p>
            </div>
          </div>
          <div class="col-md-6">
             <div class="img-bx"><img src="<?php echo e(asset('gaming-assets/images/Video-1.png')); ?>"></div>
          </div>
        </div>
     </div>
     <div class="wrapper">
        <div class="row">
          <div class="col-md-6">
             <div class="img-bx"><img src="<?php echo e(asset('gaming-assets/images/paid2.png')); ?>"></div>
          </div>
          <div class="col-md-6 my-auto">
            <div class="text-bx">
              <h1 class="">GET <span class="redColor">PAID</span></h1>
              <p>Get paid weekly.</p>
            </div>
          </div>
        </div>
     </div>
   </div>
 </section>

<?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<!-- body end gaming portal -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\findprosquad\resources\views/become-a-coach.blade.php ENDPATH**/ ?>