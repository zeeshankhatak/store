<?php $__env->startSection('title', 'Login'); ?>

<?php echo $__env->make('theme.Gamingportal-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- end head -->
<!-- body start-->
<body>

<body class="login" id="">


    <section class="login-sec">
      <div class="logo ">
        <a class="" href="javascript:;"><img src="<?php echo e(asset('gaming-assets/images/OPMfg.png')); ?>" alt=""></a>
      </div>
        <form class="loginForm" id="" action="<?php echo e(route('login')); ?>" method="post">
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="user">Username or Email Address</label>
            <input type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="user" required/>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($errors->first('email')); ?></strong>
                 </span>
            <?php endif; ?>
          </div>

         <div class="form-group">
            <label for="pass">Password</label>
            <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="pass" required/>
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <input name="remember" type="checkbox" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
            <label for="remember" class="rememberme">Remember Me</label>
          </div>
          <div class="form-group">
            <input type="submit" name="submit" class="button" value="Log In">
          </div>
        </form>
        <p>
          <a href="<?php echo e(route('register')); ?>">Register</a> | <a href="<?php echo e('password/reset'); ?>">Lost your password?</a>
        </p>
        <p><a href="<?php echo e(url('/')); ?>">← Go to Gaming</a></p>
    </section>


    </body>
<!--  Signup end-->
<!-- jquery -->
<?php echo $__env->make('theme.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end jquery -->
</body>
<!-- body end -->
</html>






<?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/auth/login.blade.php ENDPATH**/ ?>