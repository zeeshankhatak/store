<div class="col-md-3">
    <section class="">
        <section class="">

            <ul class="sidebar-menu" data-widget="tree">

                <li class=""><a href="<?php echo e(route('gamer.tab.wallet', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Wallet')); ?></span></a></li>

                <li class=""><a href="<?php echo e(route('gamer.tab.order', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Order')); ?></span></a></li>

                <li class=""><a href="<?php echo e(route('gamer.tab.profile', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span>Gamer Profile</span></a></li>

                <li class=""><a href="<?php echo e(route('gamer.tab.payment', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span>Payments History</span></a></li>

                <li class=""><a href="<?php echo e(route('gamer.tab.booking', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span>Add Booking</span></a></li>

            </ul>


        </section>
    </section>

</div>
<?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/admin/user/tabs/index.blade.php ENDPATH**/ ?>