
<?php $__env->startSection('title', 'All Order - Admin'); ?>
<?php $__env->startSection('body'); ?>

<section class="content">
  <?php echo $__env->make('gamer.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Add Student Modal -->
<div class="modal fade" id="AddStudentModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add Student</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="form group-mb3">
              <label for="">Name</label>
              <input type="text" class="name form-control">
          </div>
          <div class="form group-mb3">
              <label for="">Email</label>
              <input type="text" class="email form-control">
          </div>
          <div class="form group-mb3">
              <label for="">Subject</label>
              <input type="text" class="subject form-control">
          </div>
          <div class="form group-mb3">
              <label for="">Start Time</label>
              <input type="date" class="start_time form-control">
          </div>
          <div class="form group-mb3">
              <label for="">Status</label>
              <select class="status form-select" aria-label="Default select example">
                  <option value="Permanent">Permanent</option>
                  <option value="Visiting">Visiting</option>
              </select>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="add_student btn btn-primary">Save</button>
        </div>
      </div>
    </div>
  </div>
  <!-- End Add Student Modal -->
  <div class="row">
    <div class="col-xs-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"> <?php echo e(__('adminstaticword.Order')); ?></h3>
        </div>

        <!-- /.box-header -->
        <div class="box-body">
          <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">
              <thead>

                <br>
                <br>
                <tr>

                  <th><?php echo e(__('adminstaticword.Order #')); ?></th>
                  
                  
                  <th><?php echo e(__('adminstaticword.Game')); ?></th>
                  <th><?php echo e(__('adminstaticword.No.of Coaches')); ?></th>
                  <th><?php echo e(__('adminstaticword.Coach Names')); ?></th>
                  <th><?php echo e(__('adminstaticword.PackageAmount')); ?></th>
                  <th><?php echo e(__('adminstaticword.Game Date | Time')); ?></th>
                  <th><?php echo e(__('adminstaticword.Payment Status')); ?></th>
                  <th><?php echo e(__('adminstaticword.Order Status')); ?></th>

                </tr>
              </thead>
              <tbody>
              <?php $i=0;?>
              <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            

                
                <tr>
                  
                  <td><?php echo e($order_detail->order_id); ?></td>
                  

                  

                  
                  <td><?php echo e($order_detail->game_name); ?></td>
                  <td><?php echo e($order_detail->coaches); ?></td>

                  <td><?php echo e($order_detail->coaches_name); ?></td>

                  

                  
                  <td>$<?php echo e($order_detail->total_amount); ?></td>


                  

                  <td><?php echo e($order_detail->assign_date); ?></td>

                  <td>


                      <span  class=" <?php echo e($order_detail->order_status ==1 ? 'badge badge-success' : 'badge badge-danger'); ?>">
                        <?php if($order_detail->order_status ==1): ?>
                          <?php echo e(__('adminstaticword.Paid')); ?>

                        <?php else: ?>
                          <?php echo e(__('adminstaticword.Unpaid')); ?>

                        <?php endif; ?>
                      </span>

                  </td>



                  <td>


                    <span  type="Submit" class="btn btn-xs <?php echo e($order_detail->coach_status ==1 ? 'btn-success' : 'btn-danger'); ?>">
                      <?php if($order_detail->coach_status ==1): ?>
                        <?php echo e(__('adminstaticword.Accepted')); ?>

                      <?php else: ?>
                        <?php echo e(__('adminstaticword.Pending by Coach')); ?>

                      <?php endif; ?>
                    </span>

                </td>



                  

                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<script>
    $(document).ready(function(){

        $('#example1').dataTable( {
        "ordering": false
        } );

        // $(document).on('click','.btn-coach',function(e){
        //     e.preventDefault();
        //     var order_num = $(this).val();
        //     console.log(order_num);
        //     $("#Coach_DateTime").modal('show');
        //     $(".order_id").val(order_num);

        // });

        // $(document).on('click','.btn_save',function(){
        //     var date = $(".update-date ").val();
        //     var order_num = $(".order_id").val();

        //     console.log(date);
        //     console.log(order_num);

        //     $.ajaxSetup({
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         }
        //     });

        //     $.ajax({
        //         type:'PUT',
        //         url:'updatedate/'+order_num,
        //         data:{up_date:date},
        //         dataType:'json',
        //         success:function(response){
        //             console.log(response);
        //             if(response.status == 200){
        //                 $("#message-box").html("");
        //                 $("#message-box").addClass('alert alert-success');
        //                 $("#message-box").html(response.message);
        //                 $("#message-box").fadeIn("slow");
        //                 setTimeout(function(){
        //                     $("#message-box").fadeOut("slow")
        //                 },3000);
        //                 $("#Coach_DateTime").modal("hide");
        //                 $("#Coach_DateTime").find("input").val("");
        //             }
        //         }
        //     });
        // });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('gamer/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/gamer/order/index.blade.php ENDPATH**/ ?>