<?php $__env->startSection('title', 'Register'); ?>

<?php echo $__env->make('theme.Gamingportal-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- end head -->
<!-- body start-->
<body>
<?php echo $__env->make('theme.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <hr>


<section class="register-sec">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <form id="register-form" class="register-form" method="POST" action="<?php echo e(route('apply.instructor')); ?>">
              <?php echo csrf_field(); ?>
            <div class="tab">
              <p href="javascript:void(0)" class="tablinks active" onclick="openCity(event, 'Personal_Information')">Personal Information</p>
              <p href="javascript:void(0)" class="tablinks" onclick="openCity(event, 'Coaching_Information')">Coaching Information</p>
            </div>

              <div id="Personal_Information" class="tabcontent " style="display: block;">
                <p class="form-row form-group">
                    <label for="name">Full Name </label>
                    <input placeholder="Name" type="text" class="input-text form-control" name="name" id="name" value="" >
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="dob">Date of Birth <span class="required">*</span></label>
                    <input type="date" class="input-text form-control" name="dob" id="dob" value="" >
                    <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="reg_email">Email Address <span class="required">*</span></label>
                    <input placeholder="Email" type="email" class="input-text form-control" name="email" id="reg_email" value="" >
                    <label generated="true" class="reg_email_error"></label>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                  <label for="password">Password <span class="required">*</span></label>
                  <input placeholder="Password" type="password" class="input-text form-control" name="password" id="password" value="" >
                  <label generated="true" class="reg_email_error"></label>
                  <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span style="color:black"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="languages">Whats Language do you speak?</label>
                    <input placeholder="Languages" type="text" class="input-text form-control" name="languages" id="languages" value="" >
                    
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="gamer-tag">Whats Your Gamer Tag? <span class="required">*</span></label>
                    <input placeholder="Tag" type="text" class="input-text form-control" name="gamer_tag" id="gamer-tag" value="" >
                    <?php $__errorArgs = ['gamer_tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="discord-tag">Whats Your Discord Tag? <span class="required">*</span></label>
                    <input placeholder="Tag" type="text" class="input-text form-control" name="discord_tag" id="discord-tag" value="" >
                    <?php $__errorArgs = ['discord_tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <div class="next-previous"> <span class="next-previous-btn active" onclick="openCity(event, 'Coaching_Information')"> Next </span> </div>

             </div>

            <!-- Spam Trap -->
            

           <div id="Coaching_Information" class="tabcontent" style="display: none;">

                <p class="form-row form-group form-row-wide">
                    <label for="want-to-coach">Select game you want to coach <span class="required">*</span></label>
                    <select name="want_to_coach" id="want-to-coach" value="" >
                        <option value="" selected="true" disabled="disabled">Select Game</option>
                        <option value="1">Call of Duty</option>
                        <option value="2">Apex Legends</option>
                        <option value="3">Fortnite</option>
                        <option value="4">Valorant</option>
                    </select>
                    <?php $__errorArgs = ['want_to_coach'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="rank">What’s your highest rank?  </label>
                    
                    <select name="rank" id="rank" value="" >
                        <option value="" selected="true" disabled="disabled">Select Rank</option>
                        <option value="1">Rank 1</option>
                        <option value="2">Rank 2</option>
                        <option value="3">Rank 3</option>
                        <option value="4">Rank 4</option>
                    </select>
                    
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="signed-with-any-organization">Are you signed with any organization? <span class="required">*</span></label>
                    <select name="signed_with_any_organization" id="signed_with_any_organization" value="" >
                        <option value="" selected="true" disabled="disabled">Select</option>
                        <option value="1">Yes</option>
                        <option value="2">No</option>
                    </select>
                    <?php $__errorArgs = ['signed_with_any_organization'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="death">What’s your Kill to Death Ratio?   </label>
                    <input type="text" class="input-text form-control" placeholder="Rank" name="death" id="death" value="">
                    
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="win_rate">What’s your Win Rate? <span class="required">*</span></label>
                    <input placeholder="K/D" type="text" class="input-text form-control" name="win_rate" id="win_rate" value="" >
                    <?php $__errorArgs = ['win_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="good_coach">Describe why you think you will be a good coach? <span class="required">*</span></label>
                   <textarea placeholder="Describe..." type="text" class="input-text form-control" name="good_coach" id="good-coach" value="" > </textarea>
                   <?php $__errorArgs = ['good_coach'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <span style="color:black"><?php echo e($message); ?></span>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="linkss">Provide links to twitch, facebook, or youtube page: </label>
                    <textarea type="text" class="input-text form-control" name="linkss" id="linkss" value=""></textarea>
                    
                </p>

                <p class="form-row submitt-btn">
                    
                    <input type="submit" class="dokan-btn dokan-btn-theme" name="register" value="Submit Application">
                </p>

            </div>

          </form>
        </div>
      </div>
    </div>
  </section>


<?php echo $__env->make('theme.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('theme.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end jquery -->
</body>
<!-- body end -->
</html>
<?php /**PATH /home/centauruscrm/fps.centauruscrm.com/resources/views/coach-registration.blade.php ENDPATH**/ ?>