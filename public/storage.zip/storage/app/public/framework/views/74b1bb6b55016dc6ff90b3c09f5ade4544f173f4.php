<?php
    $srcurl = "includes/";
    $basesurl = "assets/";
    $urhere = "register";

  if ($_SERVER['HTTP_HOST'] == "localhost") {
      $folder_name = ""; $path = 'https://localhost/gaming/'.$folder_name;
  } else {
    $folder_name = ""; $path = 'https://'.$_SERVER['HTTP_HOST'].''.$folder_name.'/';
  }

?>
<section class="cont">
<header>
  <div class="header-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('gaming-assets/images/OPMfg.png')); ?>" alt="">
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto">
                            <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item login-btn <?php if ($urhere=="") {echo "active"; }?>">

                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                            </li>
                            <li class="nav-item dropdown <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="javascript:;">START YOUR SESSION</a>

                            <ul class="dropdown-list">
                                <li><a href="<?php echo e(url('/call-of-duty')); ?>" class="">Call of Duty</a></li>
                                <li><a href="<?php echo e(url('/apex-legends')); ?>" class="">Apex Legends</a></li>
                                <li><a href="<?php echo e(url('/fortnite')); ?>" class="">Fortnite</a></li>
                                <li><a href="<?php echo e(url('/valorant')); ?>" class="">Valorant</a></li>
                            </ul>
                            </li>

                            <li class="nav-item <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="<?php echo e(url('/pricing')); ?>">Pricing</a>
                            </li>
                            <li class="nav-item <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="<?php echo e(url('/become-a-coach')); ?>">Become a Coach</a>
                            </li>
                            <li class="nav-item <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="<?php echo e(url('/about-us')); ?>">About Us</a>
                            </li>
                            <li class="nav-item register-btn <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="<?php echo e(url('/coach-registration')); ?>">Register</a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                        
                        <?php if(auth()->guard()->check()): ?>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item login-btn <?php if ($urhere=="") {echo "active"; }?>">
                                
                            <!--<a class="nav-link" href="">Dashboard</a>-->
                            
                            
                                 <!-- Osama Code for Dashboard Navigation -->        

                            <li class="nav-item login-btn <?php if ($urhere=="") {echo "active"; }?>">
                        
                        <?php if(Auth::User()->user_type == 1): ?>
                        <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">Dashboard</a>
                          <?php elseif(Auth::User()->user_type == 2): ?>
                        <a class="nav-link" href="<?php echo e(route('userenroll.index')); ?>">Dashboard</a>
                        <?php elseif(Auth::User()->user_type == 3): ?>
                        <a class="nav-link" href="<?php echo e(route('gamer.index')); ?>">Dashboard</a> 
                        <?php endif; ?>
                            
                            
                            
                            </li>
                            <li class="nav-item login-btn <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="">Add Funds</a>
                            </li>
                            <li class="nav-item dropdown <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="javascript:;">Start YOUR SESSION</a>

                            <ul class="dropdown-list">
                                <li><a href="<?php echo e(url('/call-of-duty')); ?>" class="">Call of Duty</a></li>
                                <li><a href="<?php echo e(url('/apex-legends')); ?>" class="">Apex Legends</a></li>
                                <li><a href="<?php echo e(url('/fortnite')); ?>" class="">Fortnite</a></li>
                                <li><a href="<?php echo e(url('/valorant')); ?>" class="">Valorant</a></li>
                            </ul>
                            </li>

                            <li class="nav-item <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="<?php echo e(url('/pricing')); ?>">Pricing</a>
                            </li>
                            <li class="nav-item <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="<?php echo e(url('/become-a-coach')); ?>">Become a Coach</a>
                            </li>
                            <li class="nav-item <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="<?php echo e(url('/about-us')); ?>">About Us</a>
                            </li>
                            <?php

                            $wallet = DB::table('fps_wallets')
                            ->select("*")->where("userid", Auth::User()->id)
                            ->first();

                            // $wallet = fps_wallet::select("*")->where("userid", Auth::User()->id)->first();

                            $current_bal = DB::table('fps_wallet_records')
                            ->select("*")
                            ->where("wallet_id", $wallet->id)
                            ->orderByDesc('id')
                            ->first();
                            //  dd($current_bal);
                            //  exit;
                            
                            ?>
                            <li class="nav-item dropdown register-btn <?php if ($urhere=="") {echo "active"; }?>">
                            <a class="nav-link" href="javascript:;">$<?php echo $current_bal->total ?></a>
                            <ul class="dropdown-list">
                              

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="display-none">
                                <?php echo csrf_field(); ?>
                                    <li><input type="submit" class="dokan-btn dokan-btn-theme" name="register" value="Logout"></li>
                                </form>
                            </ul>
                            <div>Your balance</div>
                            </li>

                            
                        </ul>
                        </div>
                        <?php endif; ?>
                        
                </nav>

            </div>


        </div>
    </div>
</header>


<div class="custom-live-user">
    <ul>
        <li><a href="#"><img src="<?php echo e(asset('gaming-assets/images/c5.jpg')); ?>" ></a></li>
        <li><a href="#"><img src="<?php echo e(asset('gaming-assets/images/c5.jpg')); ?>"></a></li>
        <li><a href="#"><img src="<?php echo e(asset('gaming-assets/images/c5.jpg')); ?>"></a></li>
    </ul>
</div>





<?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/theme/nav.blade.php ENDPATH**/ ?>