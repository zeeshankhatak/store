<div class="col-md-3">
    <section class="">
        <section class="">

            <ul class="sidebar-menu" data-widget="tree">

                <?php if(auth()->user()->role->permission['capabilities']['gamer']['wallet']['view'] == 1): ?>
                <li class=""><a href="<?php echo e(route('gamer.tab.wallet', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Wallet')); ?></span></a></li>
                <?php endif; ?>
                <?php if(auth()->user()->role->permission['capabilities']['gamer']['order']['view'] == 1): ?>
                <li class=""><a href="<?php echo e(route('gamer.tab.order', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Order')); ?></span></a></li>
                <?php endif; ?>
                <?php if(auth()->user()->role->permission['capabilities']['gamer']['tips']['view'] == 1): ?>            
                <li class=""><a href="<?php echo e(route('gamer.tab.tips', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span>Tips</span></a></li>
                <?php endif; ?>
                <?php if(auth()->user()->role->permission['capabilities']['gamer']['edit'] == 1): ?>
                <li class=""><a href="<?php echo e(route('gamer.tab.profile', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span>Gamer Profile</span></a></li>
                <?php endif; ?>
                <?php if(auth()->user()->role->permission['capabilities']['gamer']['payment_history']['view'] == 1): ?>
                <li class=""><a href="<?php echo e(route('gamer.tab.payment', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span>Payments History</span></a></li>
                <?php endif; ?>
                <?php if(auth()->user()->role->permission['capabilities']['gamer']['add_booking']['view'] == 1): ?>
                <li class=""><a href="<?php echo e(route('gamer.tab.booking', $id)); ?>"><i class="fa fa-tachometer"
                            aria-hidden="true"></i><span>Add Booking</span></a></li>
                <?php endif; ?>

            </ul>


        </section>
    </section>

</div>
<?php /**PATH /home/fpsaquaclients/public_html/resources/views/admin/user/tabs/index.blade.php ENDPATH**/ ?>