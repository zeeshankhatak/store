
<?php $__env->startSection('title', 'All Order - Admin'); ?>
<?php $__env->startSection('body'); ?>

    <section class="content">
        <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"> <?php echo e(__('adminstaticword.Order')); ?></h3>
                    </div>

                 
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>

                                    <br>
                                    <br>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(__('adminstaticword.Coach Names')); ?></th>
                                        <th><?php echo e(__('adminstaticword.GamerName')); ?></th>
                                        
                                        <th><?php echo e(__('adminstaticword.Package')); ?></th>
                                        <th><?php echo e(__('adminstaticword.Game')); ?></th>
                                        
                                        
                                        
                                      
                                        
                                        <?php if(isset(auth()->user()->role->permission['capabilities']['gamer']['delete'])): ?>
                                       
                                        <?php endif; ?>
                                        
                                          <th><?php echo e(__('adminstaticword.sub_total')); ?></th>
                                          <th><?php echo e(__('adminstaticword.total')); ?></th>
                                          <th><?php echo e(__('adminstaticword.discount_amount')); ?></th>
                                          <th><?php echo e(__('adminstaticword.total_coaches')); ?></th>
                                          <th><?php echo e(__('adminstaticword.date')); ?></th>
                                          <th><?php echo e(__('adminstaticword.status')); ?></th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 0; ?>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <?php $i++; ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td>   <?php echo e($order->coach['fname']); ?> <?php echo e($order->coach['lname']); ?> </td>
                                            <td>  <?php echo e($order->user['fname']); ?> <?php echo e($order->user['lname']); ?>  </td>

                                            

                                            <td><?php echo e($order->pacakage_id); ?></td>
                                            <td><?php echo e($order->game_id); ?></td>
                                            <td><?php echo e($order->sub_total); ?></td>
                                            <td><?php echo e($order->total); ?></td>
                                            <td><?php echo e($order->discount_amount); ?></td>
                                            <td><?php echo e($order->total_coaches); ?></td>
                                            <td><?php echo e($order->date); ?></td>
                                            <td><?php echo e($order->status); ?></td>
                                            
                                            
                                            


                                            

                                          

                                      
                                            <?php if(isset(auth()->user()->role->permission['capabilities']['gamer']['delete'])): ?>
                                       
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/admin/order/index.blade.php ENDPATH**/ ?>