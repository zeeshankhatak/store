<?php $__env->startSection('title', 'Booking Manually - Admin'); ?>
<?php $__env->startSection('body'); ?>

    <section class="content">
        <?php echo $__env->make('gamer.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




        <div class="row">

            <?php echo $__env->make('admin.user.tabs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"> Booking Manually
                        </h3>


                    </div>
                    <br>
                    <div class="panel-body">
                        <form action="<?php echo e(route('gamer.tab.booking.post', $id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


                            <div class="row">
                                <div class="col-md-6">
                                    <label for="fname">
                                        Order Type:
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="order_type" class="form-control js-example-basic-single" name="order_type">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <?php $__currentLoopData = $order_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ot->id); ?>">
                                                <?php echo e($ot->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label for="fname">
                                        Order Type:
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="game_type" class="form-control js-example-basic-single" name="game_type">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($game->id); ?>">
                                                <?php echo e($game->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                            </div>
                            <br>

                            <div class="row">
                                <div class="col-md-6">
                                    <label for="fname">
                                        CHOOSE YOUR GAMING EXPERIENCE :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="experience" class="form-control js-example-basic-single" name="experience">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>

                                        <option value="FOCUS ON COACHING">FOCUS ON COACHING</option>
                                        <option value="CASUAL GAMES">CASUAL GAMES</option>
                                        <option value="VIDEO REVIEWS">VIDEO REVIEWS</option>

                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label for="fname">
                                        HOW MANY HOURS DO YOU WANT TO PLAY? :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="duration" class="form-control js-example-basic-single" name="duration">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <option value="1">1 HOUR</option>
                                        <option value="2">2 HOUR</option>
                                        <option value="3">3 HOUR</option>

                                    </select>
                                </div>
                            </div>

                            <br>

                            <div class="row">
                                <div class="col-md-6">
                                    <label for="">
                                        CHOOSE YOUR COACH(ES) :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <br>
                                    <input type="radio" name="coach_no" id="ch1" value="1" checked> 1 COACH
                                    <input type="radio" name="coach_no" id="ch2" value="2"> 2 COACHES
                                </div>

                                <div class="col-md-6">
                                    <label for="">
                                        CHOOSE A COACH :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="coach_id" class="form-control js-example-basic-single" name="coach_id[]">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($coach->coach_id); ?>">Name : <?php echo e($coach->fname); ?> <?php echo e($coach->lname); ?> | Hourly Rate : $<?php echo e($coach->rate); ?> | Rank : <?php echo e($coach->coach_rank_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" id="cr" name="coach_rate[]" value="<?php echo e($coach->rate); ?>">
                                    </select>
                                </div>
                            </div>



                            <div class="box-footer">
                                <button type="submit" class="btn btn-md btn-primary">
                                    <i class="fa fa-save"></i> <?php echo e(__('adminstaticword.Save')); ?>

                                </button>
                        </form>
                        <a href="<?php echo e(route('user.index')); ?>" title="Cancel and go back"
                            class="btn btn-md btn-default btn-flat">
                            <i class="fa fa-reply"></i> <?php echo e(__('adminstaticword.Back')); ?>

                        </a>
                    </div>
                    <br>

                    </form>
                </div>
                <!-- /.panel body -->
            </div>
            <!-- /.box -->
        </div>

    <?php $__env->stopSection(); ?>



    <?php $__env->startSection('scripts'); ?>

        <script>
            (function($) {
                "use strict";

                $(function() {
                    $("#dob,#doa").datepicker({
                        changeYear: true,
                        yearRange: "-100:+0",
                        dateFormat: 'yy/mm/dd',
                    });
                });


                $('#married_status').change(function() {

                    if ($(this).val() == 'Married') {
                        $('#doaboxxx').show();
                    } else {
                        $('#doaboxxx').hide();
                    }
                });

                tinymce.init({
                    selector: 'textarea#detail'
                });

                $(function() {
                    var urlLike = '<?php echo e(url('country/dropdown')); ?>';
                    $('#country_id').change(function() {
                        var up = $('#upload_id').empty();
                        var cat_id = $(this).val();
                        if (cat_id) {
                            $.ajax({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                type: "GET",
                                url: urlLike,
                                data: {
                                    catId: cat_id
                                },
                                success: function(data) {
                                    console.log(data);
                                    up.append('<option value="0">Please Choose</option>');
                                    $.each(data, function(id, title) {
                                        up.append($('<option>', {
                                            value: id,
                                            text: title
                                        }));
                                    });
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest);
                                }
                            });
                        }
                    });
                });

                $(function() {
                    var urlLike = '<?php echo e(url('country/gcity')); ?>';
                    $('#upload_id').change(function() {
                        var up = $('#grand').empty();
                        var cat_id = $(this).val();
                        if (cat_id) {
                            $.ajax({
                                headers: {
                                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                },
                                type: "GET",
                                url: urlLike,
                                data: {
                                    catId: cat_id
                                },
                                success: function(data) {
                                    console.log(data);
                                    up.append('<option value="0">Please Choose</option>');
                                    $.each(data, function(id, title) {
                                        up.append($('<option>', {
                                            value: id,
                                            text: title
                                        }));
                                    });
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest);
                                }
                            });
                        }
                    });
                });

            })(jQuery);
        </script>

        <script>
            function myFunction() {
                var checkBox = document.getElementById("myCheck");
                var text = document.getElementById("update-password");
                if (checkBox.checked == true) {
                    text.style.display = "block";
                } else {
                    text.style.display = "none";
                }
            }
        </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/admin/user/tabs/booking/index.blade.php ENDPATH**/ ?>