<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .invoice {
    position: relative;
    background: #fff;
    border: 1px solid #f4f4f4;
    padding: 20px;
    margin: 10px 25px;
}
.page-header {
    margin: 200px 0 20px 0;
    font-size: 22px;
}
</style>
<section class="content content_content" style="width: 70%; margin: auto;">
    <section class="invoice">
        <!-- title row -->
        <div class="row">
            <div class="col-xs-12">
                <h2 class="page-header">
                    <i class="fa fa-globe"></i> FPS. <BR>
                        <?php if(session('status')): ?>
                    <h6 class="alert alert-success">$<?php echo e(session('status')); ?> is added in your wallet!</h6>
                    <?php endif; ?>
                    <br>
                    <small class="pull-right">Date: <?php echo e($order->date); ?></small>
                </h2>
            </div><!-- /.col -->
        </div>
        <!-- info row -->
        <div class="row invoice-info">
            <div class="col-sm-4 invoice-col">
                Coach Details
                <address>
                    <strong>
                        <?php echo e($coachdetails->fname); ?> <?php echo e($coachdetails->lname); ?>

                                                            </strong>
                <br>
                Rank:
                <?php echo e($coach->coach_rank_id); ?>                                    <br>
                K\D Ratio:
                <?php echo e($coach->k_d_ratio); ?>     <br>
                Win Rate:
                <?php echo e($coach->win_rate); ?>                                   <br>
                Email: <?php echo e($coachdetails->email); ?>

                </address>
            </div><!-- /.col -->
            <div class="col-sm-4 invoice-col">
                Gamer Details <br>
                    <strong>
                        <?php echo e($gamer->fname); ?> <?php echo e($gamer->lname); ?>                                    </strong>
                    <br>
                    Address:
                    <?php echo e($gamer->address); ?>                                    <br>
                    Phone:
                    <?php echo e($gamer->mobile); ?>                                   <br>
                    Email: <?php echo e($gamer->email); ?>                                </address>
            </div><!-- /.col -->
            <div class="col-sm-4 invoice-col">
                Package Details
                <address>
                    <strong>
                        Package Name
                                                            </strong>
                <br>
                Game: Call of Duty
                <?php echo e($gamer->address); ?>                                    <br>
                Gamming hours:
                1                                   <br>
                Total Coaches: <?php echo e($order->total_coaches); ?>

                </address>
            </div><!-- /.col -->
        </div><!-- /.row -->

        <!-- Table row -->
        <div class="row">
            <div class="col-xs-12 table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>order_id</th>
                            <th>Package</th>
                             <th>Total</th>
                            <th>Sub Total</th>
                        </tr>
                    </thead>
                    <tbody>


                                                                <tr>
                            <td><?php echo e($order->id); ?></td>
                            <td>Pacakge Name</td>
                            <td><?php echo e($order->total); ?></td>
                            <td><?php echo e($order->sub_total); ?></td>
                        </tr>
                                                            </tbody>
                </table>
            </div><!-- /.col -->
        </div><!-- /.row -->

        

        <!-- this row will not appear when printing -->
        <div class="row no-print">
            <div class="col-xs-12">
                
                <button class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment</button><br>
                
                



                    <div class="checkout-btn">
                        <form id="cart-form" method="post" action="<?php echo e(url('gotocheckout2')); ?>"
                            data-parsley-validate class="form-horizontal form-label-left">
                            <?php echo e(csrf_field()); ?>


                            <input type="hidden" name="user_id"  value="<?php echo e(Auth::User()->id); ?>" />
                            <input type="hidden" name="price_total"  value="<?php echo e($order->total); ?>" />
                            <input type="hidden" name="offer_total"  value="<?php echo e($order->sub_total); ?>" />
                            <input type="hidden" name="offer_percent"  value="<?php echo e(round($order->sub_total, 2)); ?>" />
                            <input type="hidden" name="cart_total"  value="<?php echo e($order->sub_total); ?>" />
                            <input type="hidden" name="wallet_amount"  value="<?php echo e(session('status')); ?>" />


                          <button class="btn btn-primary" title="checkout" type="submit">ADD FUNDS</button>
                        </form>


                </div>
            </div>
        </div>
    </section>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/centauruscrm/fps.centauruscrm.com/Osama/resources/views/front/invoice.blade.php ENDPATH**/ ?>