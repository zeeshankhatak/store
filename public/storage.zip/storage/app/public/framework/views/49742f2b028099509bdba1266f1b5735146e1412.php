<?php $__env->startSection('title', 'All Order - Admin'); ?>
<?php $__env->startSection('body'); ?>

<section class="content">
  <?php echo $__env->make('gamer.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="row">
    <div class="col-xs-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"> <?php echo e(__('adminstaticword.Order')); ?></h3>
        </div>
        <?php if(Auth::User()->role == "admin"): ?>
        <div class="box-header with-border">

          <a class="btn btn-info btn-md" href="<?php echo e(route('order.create')); ?>">
          <i class="glyphicon glyphicon-th-l">+</i> Enroll&nbsp;User</a>

        </div>
        <?php endif; ?>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">
              <thead>

                <br>
                <br>
                <tr>
                  <th>#</th>
                  <th><?php echo e(__('adminstaticword.User')); ?></th>
                  
                  <th><?php echo e(__('adminstaticword.Package')); ?></th>
                  <th><?php echo e(__('adminstaticword.Game')); ?></th>
                  <th><?php echo e(__('adminstaticword.No.of Coaches')); ?></th>
                  <th><?php echo e(__('adminstaticword.Coache Names')); ?></th>
                  <th><?php echo e(__('adminstaticword.PaymentMethod')); ?></th>
                  <th><?php echo e(__('adminstaticword.TotalAmount')); ?></th>
                  <th><?php echo e(__('adminstaticword.Status')); ?></th>
                  <th><?php echo e(__('adminstaticword.View')); ?></th>
                  <th><?php echo e(__('adminstaticword.Delete')); ?></th>
                </tr>
              </thead>
              <tbody>
              <?php $i=0;?>
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            

                <?php $i++;?>
                <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo e($order->user['fname']); ?> <?php echo e($order->user['lname']); ?></td>

                  

                  <td><?php echo e($order->pacakage_id); ?></td>
                  <td><?php echo e($order->game_id); ?></td>
                  <td><?php echo e($order->total_coaches); ?></td>
                  <td><?php echo e($order->coach['fname']); ?> <?php echo e($order->coach['lname']); ?></td>
                  <td></td>
                  <td>$<?php echo e($order->total); ?></td>


                  

                  <td>
                    
                  </td>

                  <td>
                    
                  </td>

                  <td>
                    
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('gamer/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/centauruscrm/fps.centauruscrm.com/Osama/resources/views/gamer/order/index.blade.php ENDPATH**/ ?>