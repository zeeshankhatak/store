<?php $__env->startSection('title', 'Gamer Wallet - Admin'); ?>
<?php $__env->startSection('body'); ?>

<section class="content">
  <?php echo $__env->make('gamer.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




  <div class="row">

    <?php echo $__env->make('admin.user.tabs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-9">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"> Payment History </h3>
        </div>

        <!-- /.box-header -->
        <div class="box-body">

          <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">
              <thead>

                <br>
                <br>
                <tr>
                  <th>#</th>
                  <th>Payment Method</th>
                  <th><?php echo e(__('adminstaticword.Deposite')); ?></th>
                  <th><?php echo e(__('adminstaticword.Date')); ?></th>

                </tr>
              </thead>
              <tbody>
              <?php $i=0;?>
              <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <?php $i++;?>
                <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo e($payment->payment_method); ?></td>
                  <td><?php echo e($payment->amount); ?></td>

                  <td><?php echo e($payment->date); ?></td>

                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/admin/user/tabs/payment/index.blade.php ENDPATH**/ ?>