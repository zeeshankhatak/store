<?php $__env->startSection('body'); ?>
<?php $__env->startSection('title', 'ADD User - Admin'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo e(__('adminstaticword.Add')); ?> <?php echo e(__('adminstaticword.Users')); ?>

                    </h3>
                </div>
                <div class="panel-body">
                    <form action="<?php echo e(route('roles.update', $role->role_id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <div class="row">
                            <div class="col-md-6 col-6">
                                <label for="fname">
                                    <?php echo e(__('adminstaticword.FirstName')); ?>:<sup class="redstar">*</sup>
                                </label>
                                <input value="<?php echo e($role->name); ?>" autofocus required name="name" type="text"
                                    class="form-control" placeholder="Enter your role name" />
                            </div>

                        </div>
                        <br>

                        <div class="row">
                            <div class="col-md-6">
                                <label for="mobile">Features: <sup class="redstar">*</sup></label>
                                <table class="table table-bordered roles no-margin">
                                    <thead>
                                        <tr>
                                            <th>Feature</th>
                                            <th>Capabilities</th>
                                        </tr>
                                    </thead>
                                    <?php $per = json_decode($role->capabilities, true); ?>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <b>Gamer</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                          <input type="hidden" class="capability"
                                                        name="permission[gamer][view]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-view"
                                                        name="permission[gamer][view]" value="1" <?php echo e($per['gamer']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                            <input type="hidden" class="capability" 
                                                        name="permission[gamer][create]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-create"
                                                        name="permission[gamer][create]" value="1" <?php echo e($per['gamer']['create'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox">
                                                            <input type="hidden" class="capability"
                                                        name="permission[gamer][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-edit"
                                                        name="permission[gamer][edit]" value="1" <?php echo e($per['gamer']['edit'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability" 
                                                        name="permission[gamer][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-delete"
                                                        name="permission[gamer][delete]" value="1" <?php echo e($per['gamer']['delete'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                        
                                         <tr>
                                            <td>
                                                <b>Gamer Wallet</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                          <input type="hidden" class="capability"
                                                        name="permission[gamer][wallet][view]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-wallet-view"
                                                        name="permission[gamer][wallet][view]" value="1" <?php echo e($per['gamer']['wallet']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-wallet-view">
                                                        View </label>
                                                </div>
                                             

                                            </td>

                                        </tr>
                                        
                                         <tr>
                                            <td>
                                                <b>Gamer Order</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                          <input type="hidden" class="capability"
                                                        name="permission[gamer][order][view]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-order-view"
                                                        name="permission[gamer][order][view]" value="1" <?php echo e($per['gamer']['order']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-order-view">
                                                        View </label>
                                                </div>
                                            

                                            </td>

                                        </tr>
                                        
                                         <tr>
                                            <td>
                                                <b>Gamer Tips</b>
                                            </td>
                                            <td>
                                               <div class="checkbox">
                                                          <input type="hidden" class="capability"
                                                        name="permission[gamer][tips][view]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-tips-view"
                                                        name="permission[gamer][tips][view]" value="1" <?php echo e($per['gamer']['tips']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-tips-view">
                                                        View </label>
                                                </div>
                                              

                                            </td>

                                        </tr>
                                        
                                          <tr>
                                            <td>
                                                <b>Gamer Payment History</b>
                                            </td>
                                            <td>
                                              <div class="checkbox">
                                                          <input type="hidden" class="capability"
                                                        name="permission[gamer][payment_history][view]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-payment_history-view"
                                                        name="permission[gamer][payment_history][view]" value="1" <?php echo e($per['gamer']['payment_history']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-payment_history-view">
                                                        View </label>
                                                </div>
                                            

                                            </td>

                                        </tr>
                                        
                                         <tr>
                                            <td>
                                                <b>Gamer Add Booking</b>
                                            </td>
                                            <td>
                                              <div class="checkbox">
                                                          <input type="hidden" class="capability"
                                                        name="permission[gamer][add_booking][view]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-add_booking-view"
                                                        name="permission[gamer][add_booking][view]" value="1" <?php echo e($per['gamer']['add_booking']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-add_booking-view">
                                                        View </label>
                                                </div>
                                             <div class="checkbox">
                                                            <input type="hidden" class="capability" 
                                                        name="permission[gamer][add_booking][create]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-add_booking-create"
                                                        name="permission[gamer][add_booking][create]" value="1" <?php echo e($per['gamer']['add_booking']['create'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="gamer-add_booking-create">
                                                        Create </label>
                                                </div>
                                             

                                            </td>

                                        </tr>
                                        
                                        
                                        <tr>
                                            <td>
                                                <b>Coach</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                         <input type="hidden" class="capability"
                                                        name="permission[coach][view]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-view"
                                                        name="permission[coach][view]" value="1" <?php echo e($per['coach']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="coach-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                      <input type="hidden" class="capability"
                                                        name="permission[coach][create]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-create"
                                                        name="permission[coach][create]" value="1" <?php echo e($per['coach']['create'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="coach-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox">
                                                    <input type="hidden" class="capability"
                                                        name="permission[coach][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-edit"
                                                        name="permission[coach][edit]" value="1" <?php echo e($per['coach']['edit'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="coach-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">
                                                      <input type="hidden" class="capability"
                                                        name="permission[coach][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-delete"
                                                        name="permission[coach][delete]" value="1" <?php echo e($per['coach']['delete'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="coach-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                        
                                        
                                         <tr>
                                            <td>
                                                <b>Coach Wallet</b>
                                            </td>
                                            <td>
                                               <div class="checkbox">
                                                          <input type="hidden" class="capability"
                                                        name="permission[coach][wallet][view]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-wallet-view"
                                                        name="permission[coach][wallet][view]" value="1" <?php echo e($per['coach']['wallet']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="coach-wallet-view">
                                                        View </label>
                                                </div>
                                              

                                            </td>

                                        </tr>
                                        
                                         <tr>
                                            <td>
                                                <b>Coach Order</b>
                                            </td>
                                            <td>
                                               <div class="checkbox">
                                                          <input type="hidden" class="capability"
                                                        name="permission[coach][order][view]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-order-view"
                                                        name="permission[coach][order][view]" value="1" <?php echo e($per['coach']['order']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="coach-order-view">
                                                        View </label>
                                                </div>
                                              

                                            </td>

                                        </tr>
                                        
                                        
                                        <tr>
                                            <td>
                                                <b>Order</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[order][view]" value="0">
                                                    <input type="checkbox" class="capability" id="order-view"
                                                        name="permission[order][view]" value="1" <?php echo e($per['order']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="order-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[order][create]" value="0">
                                                    <input type="checkbox" class="capability" id="order-create"
                                                        name="permission[order][create]" value="1" <?php echo e($per['order']['create'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="order-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox">
                                                    <input type="hidden" class="capability"
                                                        name="permission[order][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="order-edit"
                                                        name="permission[order][edit]" value="1" <?php echo e($per['order']['edit'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="order-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[order][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="order-delete"
                                                        name="permission[order][delete]" value="1" <?php echo e($per['order']['delete'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="order-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                        
                                         <tr>
                                            <td>
                                                <b>Tips</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[tips][view]" value="0">
                                                    <input type="checkbox" class="capability" id="tips-view"
                                                        name="permission[tips][view]" value="1" <?php echo e($per['tips']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="tips-view">
                                                        View </label>
                                                </div>
                                            

                                            </td>

                                        </tr>
                                        
                                        
                                        <tr>
                                            <td>
                                                <b>Role</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                          <input type="hidden" class="capability"
                                                        name="permission[role][view]" value="0">
                                                    <input type="checkbox" class="capability" id="role-view"
                                                        name="permission[role][view]" value="1" <?php echo e($per['role']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="role-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                      <input type="hidden" class="capability"
                                                        name="permission[role][create]" value="0">
                                                    <input type="checkbox" class="capability" id="role-create"
                                                        name="permission[role][create]" value="1" <?php echo e($per['role']['create'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="role-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox">
                                                      <input type="hidden" class="capability"
                                                        name="permission[role][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="role-edit"
                                                        name="permission[role][edit]" value="1" <?php echo e($per['role']['edit'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="role-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">
                                                     <input type="hidden" class="capability"
                                                        name="permission[role][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="role-delete"
                                                        name="permission[role][delete]" value="1" <?php echo e($per['role']['delete'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="role-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <b>Staff</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[staff][view]" value="0">
                                                    <input type="checkbox" class="capability" id="staff-view"
                                                        name="permission[staff][view]" value="1" <?php echo e($per['staff']['view'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="staff-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                     <input type="hidden" class="capability"
                                                        name="permission[staff][create]" value="0">
                                                    <input type="checkbox" class="capability" id="staff-create"
                                                        name="permission[staff][create]" value="1" <?php echo e($per['staff']['create'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="staff-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox">
                                                    <input type="hidden" class="capability"
                                                        name="permission[staff][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="staff-edit"
                                                        name="permission[staff][edit]" value="1" <?php echo e($per['staff']['edit'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="staff-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">
                                                     <input type="hidden" class="capability"
                                                        name="permission[staff][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="staff-delete"
                                                        name="permission[staff][delete]" value="1" <?php echo e($per['staff']['delete'] == 1 ? 'checked' : ''); ?>>
                                                    <label for="staff-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <br>
                        <br>


                        <div class="box-footer">
                            <button type="submit" class="btn btn-md btn-primary">
                                <i class="fa fa-plus-circle"></i> <?php echo e(__('adminstaticword.AddUser')); ?>

                            </button>
                    </form>
                    <a href="<?php echo e(route('roles.index')); ?>" title="Cancel and go back"
                        class="btn btn-md btn-default btn-flat">
                        <i class="fa fa-reply"></i> <?php echo e(__('adminstaticword.Back')); ?>

                    </a>
                </div>
                <br>


            </div>
            <!-- /.panel body -->
        </div>
        <!-- /.box -->
    </div>
    <!-- /.col -->
    </div>
    <!-- /.row -->
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
    (function($) {
        "use strict";

        $('#married_status').change(function() {

            if ($(this).val() == 'Married') {
                $('#doaboxxx').show();
            } else {
                $('#doaboxxx').hide();
            }
        });

        $(function() {
            $("#dob,#doa").datepicker({
                changeYear: true,
                yearRange: "-100:+0",
                dateFormat: 'yy/mm/dd',
            });
        });

        tinymce.init({
            selector: 'textarea#detail'
        });

        $(function() {
            var urlLike = '<?php echo e(url('country/dropdown')); ?>';
            $('#country_id').change(function() {
                var up = $('#upload_id').empty();
                var cat_id = $(this).val();
                if (cat_id) {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: "GET",
                        url: urlLike,
                        data: {
                            catId: cat_id
                        },
                        success: function(data) {
                            console.log(data);
                            up.append('<option value="0">Please Choose</option>');
                            $.each(data, function(id, title) {
                                up.append($('<option>', {
                                    value: id,
                                    text: title
                                }));
                            });
                        },
                        error: function(XMLHttpRequest, textStatus, errorThrown) {
                            console.log(XMLHttpRequest);
                        }
                    });
                }
            });
        });

        $(function() {
            var urlLike = '<?php echo e(url('country/gcity')); ?>';
            $('#upload_id').change(function() {
                var up = $('#grand').empty();
                var cat_id = $(this).val();
                if (cat_id) {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: "GET",
                        url: urlLike,
                        data: {
                            catId: cat_id
                        },
                        success: function(data) {
                            console.log(data);
                            up.append('<option value="0">Please Choose</option>');
                            $.each(data, function(id, title) {
                                up.append($('<option>', {
                                    value: id,
                                    text: title
                                }));
                            });
                        },
                        error: function(XMLHttpRequest, textStatus, errorThrown) {
                            console.log(XMLHttpRequest);
                        }
                    });
                }
            });
        });
    })(jQuery);
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/admin/roles/edit.blade.php ENDPATH**/ ?>