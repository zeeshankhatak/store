
<?php $__env->startSection('title', 'Booking Manually - Admin'); ?>
<?php $__env->startSection('body'); ?>

    <section class="content">
        <?php echo $__env->make('gamer.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




        <div class="row">

            <?php echo $__env->make('admin.user.tabs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"> Booking Manually
                        </h3>


                    </div>
                    <br>
                    <div class="panel-body">

                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                <ul class="p-0 m-0" style="list-style: none;">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('gamer.tab.booking.post', $id)); ?>" method="POST" id="my_radio_box"
                            enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


                            <div class="row">
                                <div class="col-md-6">
                                    <label for="fname">
                                        Order Type:
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="order_type" class="form-control js-example-basic-single" name="order_type">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <?php $__currentLoopData = $order_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ot->id); ?>">
                                                <?php echo e($ot->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>


                                <div class="col-md-6">
                                    <label for="fname">
                                        Game Type:
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="game_type" class="form-control js-example-basic-single" name="game_type">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($game->id); ?>">
                                                <?php echo e($game->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>

                            </div>
                            <br>

                            

                            <div class="row" id="group1">
                                <div class="col-md-6">
                                    <label for="fname">
                                        CHOOSE YOUR GAMING EXPERIENCE :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="experience" class="form-control js-example-basic-single" name="experience">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>

                                        <option value="FOCUS ON COACHING">FOCUS ON COACHING</option>
                                        <option value="CASUAL GAMES">CASUAL GAMES</option>
                                        <option value="VIDEO REVIEWS">VIDEO REVIEWS</option>

                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label for="fname">
                                        HOW MANY HOURS DO YOU WANT TO PLAY? :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="duration" class="form-control js-example-basic-single" name="duration">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <option value="1">1 HOUR</option>
                                        <option value="2">2 HOUR</option>
                                        <option value="3">3 HOUR</option>

                                    </select>
                                </div>
                            </div>

                            

                            

                            <div class="row" id="group2">
                                <div class="col-md-6">
                                    <label for="fname">
                                        CHOOSE YOUR COACHING EXPERIENCE
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="co_experience" class="form-control js-example-basic-single" name="co_experience">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>

                                        <option value="HOURLY GAMING">HOURLY GAMING</option>
                                        <option value="GAMING PACKAGES">GAMING PACKAGES</option>

                                    </select>
                                </div>
                                
                                <!-- if hourly package select then show this -->
                                <div class="col-md-6" id="co_dur">
                                    <label for="fname">
                                        HOW MANY HOURS DO YOU WANT TO PLAY?
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="co_duration" class="form-control js-example-basic-single" name="co_duration">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <option value="1">1 HOUR</option>
                                        <option value="2">2 HOUR</option>
                                        <option value="3">3 HOUR</option>

                                    </select>
                                </div>
                                <!-- if gaming package select then show this -->
                                 <div class="col-md-6" id="co_gme_pkg">
                                    <label for="fname">
                                        CHOOSE YOUR GAMING PACKAGE
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="co_game_package" class="form-control js-example-basic-single" name="co_game_package">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>

                                        <option value="14">1 GAME - $14</option>
                                        <option value="40">3 GAMES - $40</option>
                                        <option value="65">5 GAMES- $65</option>
                                        <option value="128">10 GAMES - $128</option>

                                    </select>
                                </div>
                                

                                <div class="col-md-6">
                                    <label for="fname">
                                        CHOOSE YOUR GAMING EXPERIENCE
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="co_game_exp" class="form-control js-example-basic-single" name="co_game_exp">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <option value="RANKED GAMES">RANKED GAMES</option>
                                        <option value="CASUAL GAMES">CASUAL GAMES</option>
                                        <option value="VIDEO REVIEWS">VIDEO REVIEWS</option>

                                    </select>
                                </div>

                                <div class="col-md-6" id="co_rnk">
                                    <label for="fname">
                                        CHOOSE YOUR RANK
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="co_rank" class="form-control js-example-basic-single" name="co_rank">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <option value="BRONZE">BRONZE</option>
                                        <option value="SILVER">SILVER</option>
                                        <option value="GOLD">GOLD</option>
                                        <option value="PLATINUM">PLATINUM</option>
                                        <option value="DIAMOND">DIAMOND</option>

                                    </select>
                                </div>
                            </div>

                            

                            

                            <div class="row" id="group3">
                                <div class="col-md-6">
                                    <label for="fname">
                                        CHOOSE YOUR GAMING EXPERIENCE :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="experience" class="form-control js-example-basic-single" name="experience">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>

                                        <option value="FOCUS ON COACHING">FOCUS ON COACHING</option>
                                        <option value="CASUAL GAMES">CASUAL GAMES</option>
                                        <option value="VIDEO REVIEWS">VIDEO REVIEWS</option>

                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label for="fname">
                                        HOW MANY HOURS DO YOU WANT TO PLAY? :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="duration" class="form-control js-example-basic-single" name="duration">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <option value="1">1 HOUR</option>
                                        <option value="2">2 HOUR</option>
                                        <option value="3">3 HOUR</option>

                                    </select>
                                </div>
                            </div>

                            

                            

                            <div class="row" id="group4">
                                <div class="col-md-6">
                                    <label for="fname">
                                        CHOOSE YOUR GAMING PACKAGE
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="experience" class="form-control js-example-basic-single" name="experience">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>

                                        <option value="14">1 GAME - $14</option>
                                        <option value="40">3 GAMES - $40</option>
                                        <option value="65">5 GAMES- $65</option>
                                        <option value="128">10 GAMES - $128</option>

                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label for="fname">
                                        CHOOSE YOUR GAMING EXPERIENCE
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="game_exp" class="form-control js-example-basic-single" name="game_exp">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <option value="RANKED GAMES">RANKED GAMES</option>
                                        <option value="CASUAL GAMES">CASUAL GAMES</option>

                                    </select>
                                </div>

                                <div class="col-md-6">
                                    <label for="fname">
                                        CHOOSE YOUR RANK
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="rank" class="form-control js-example-basic-single" name="rank">
                                        <option value="none" selected disabled hidden>
                                            <?php echo e(__('adminstaticword.SelectanOption')); ?>

                                        </option>
                                        <option value="BRONZE">BRONZE</option>
                                        <option value="SILVER">SILVER</option>
                                        <option value="GOLD">GOLD</option>
                                        <option value="PLATINUM">PLATINUM</option>
                                        <option value="DIAMOND">DIAMOND</option>

                                    </select>
                                </div>
                            </div>

                            

                            <br>

                            <div class="row">
                                <div class="col-md-6">
                                    <label for="">
                                        CHOOSE YOUR COACH(ES) :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <br>
                                    <!--<fieldset id="coach_no">-->
                                    <input type="radio" name="coach_no" value="1" checked> 1 COACH
                                    <input type="radio" name="coach_no" value="2"> 2 COACHES
                                    <!--</fieldset>-->
                                </div>

                                <div class="col-md-6">
                                    <label for="">
                                        CHOOSE A COACH :
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <select id="coach_id" class="form-control multiselect" multiple="multiple"
                                        data-placeholder="<?php echo e(__('adminstaticword.SelectanOption')); ?>" name="coach_id[]">
                                        <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($coach->coach_id); ?>" data-rates="<?php echo e($coach->rate); ?>">Name : <?php echo e($coach->fname); ?>

                                                <?php echo e($coach->lname); ?> | Hourly Rate : $<?php echo e($coach->rate); ?> | Rank :
                                                <?php echo e($coach->coach_rank_id); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>
                                    <input type="hidden" id="coach_rate" name="coach_rate" value="">
                                </div>

                                <div class="col-md-6" id="dt1">
                                    <label for="">
                                        COACH 1 DATE & TIME
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <br>
                                    <input type="datetime-local" class="form-control" name="coach_datetime1"
                                        id="coach_datetime1" value="">
                                </div>

                                <div class="col-md-6" id="dt2">
                                    <label for="">
                                        COACH 2 DATE & TIME
                                        <sup class="redstar">*</sup>
                                    </label>
                                    <br>
                                    <input type="datetime-local" class="form-control" name="coach_datetime2"
                                        id="coach_datetime2" value="">
                                </div>
                            </div>


   <?php if(auth()->user()->role->permission['capabilities']['gamer']['add_booking']['create'] == 1): ?>
                            <div class="box-footer">
                                <button type="submit" class="btn btn-md btn-primary">
                                    <i class="fa fa-save"></i> <?php echo e(__('adminstaticword.Save')); ?>

                                </button>
                        </form>
                        <a href="<?php echo e(route('user.index')); ?>" title="Cancel and go back"
                            class="btn btn-md btn-default btn-flat">
                            <i class="fa fa-reply"></i> <?php echo e(__('adminstaticword.Back')); ?>

                        </a>
                    </div>
                    <?php endif; ?>
                    <br>

                    </form>
                </div>
                <!-- /.panel body -->
            </div>
            <!-- /.box -->
        </div>

    <?php $__env->stopSection(); ?>



    <?php $__env->startSection('scripts'); ?>

        <script>


            $(document).ready(function() {

                $('.multiselect').select2();

                $('#group2').css('display', 'none');
                $('#group3').css('display', 'none');
                $('#group4').css('display', 'none');
                
                // game 2
                $('#co_gme_pkg').hide();
                $('#co_rnk').hide();
                // game 2 end

                $('#dt1').hide();
                $('#dt2').hide();


                $("#my_radio_box").change(function() {
                    
                    // var total = '';
                    // var select = $('.multiselect').find(':selected');
                    // total += parseInt(select.attr('data-rates')) + ",";
                    // $("#coach_rate").val(total);
                    
                    
                            var str = "";
                            $( ".multiselect option:selected" ).each(function() {
                              str += $( this ).attr('data-rates') + ",";
                            });
                            $("#coach_rate").val(str);
                            console.log(str);
                        
                    

                    selected_value = $("input[name='coach_no']:checked").val();
                 
                    

                    //   console.log(selected_value);

                    if ($("#order_type").val() == 2) {

                        if (selected_value == 1) {

                            $('.multiselect').select2({
                                maximumSelectionLength: 1
                            });

                            $('#dt1').show();
                            $('#dt2').hide();

                        } else if (selected_value == 2) {

                            $('.multiselect').select2({
                                maximumSelectionLength: 2
                            });

                            $('#dt1').show();
                            $('#dt2').show();
                        }

                    } else {
                        $('#dt1').hide();
                        $('#dt2').hide();
                    }


                    if (selected_value == 1) {
                        $('.multiselect').select2({
                            maximumSelectionLength: 1
                        });


                    } else if (selected_value == 2) {

                        $('.multiselect').select2({
                            maximumSelectionLength: 2
                        });

                    }
                });




                $("#game_type").change(function() {
                    var str = $(this).val();


                    if (str == 1) {

                        $('#group1').css('display', 'block');
                        $('#group2').css('display', 'none');
                        $('#group3').css('display', 'none');
                        $('#group4').css('display', 'none');

                    } else if (str == 2) {

                        $('#group1').css('display', 'none');
                        $('#group2').css('display', 'block');
                        $('#group3').css('display', 'none');
                        $('#group4').css('display', 'none');
                        
                        
                        
                        $("#co_experience").change(function() {
                        
                        // console.log('change');
                        
                        if($(this).val() == "GAMING PACKAGES"){
                            $('#co_gme_pkg').show();
                            $('#co_dur').hide();
                        }else{
                            $('#co_gme_pkg').hide();
                            $('#co_dur').show();
                        }
                        
                        });
                        
                        
                         $("#co_game_exp").change(function() {
                        
                        
                        if($(this).val() == "RANKED GAMES"){
                            $('#co_rnk').show();
                        }else{
                           $('#co_rnk').hide();
                        }
                        
                        });
                        
                        
                        
                        
                        
                        

                    } else if (str == 3) {

                        $('#group1').css('display', 'none');
                        $('#group2').css('display', 'none');
                        $('#group3').css('display', 'block');
                        $('#group4').css('display', 'none');

                    } else if (str == 4) {

                        $('#group1').css('display', 'none');
                        $('#group2').css('display', 'none');
                        $('#group3').css('display', 'none');
                        $('#group4').css('display', 'block');

                    } else {
                        $('#group1').css('display', 'block');
                        $('#group2').css('display', 'none');
                        $('#group3').css('display', 'none');
                        $('#group4').css('display', 'none');

                    }



                });


                    

                $("input[name=coachingExp]").click(function() {
                    $('.coachingExpid').html($(this).val());

                    if ($("#ce1").prop("checked")) {
                        $('.hours, .gamingExp').css('display', 'block')
                    } else if ($("#ce2").prop("checked")) {
                        $('.packageGamingExp').css('display', 'block')
                        $('.hours, .gamingExp, .your-rank').css('display', 'none')
                    } else {
                        $('.hours, .gamingExp, .packageGamingExp, .your-rank').css('display', 'none')
                    }

                });

                $("input[name=packageGaming]").click(function() {
                    $('.packageGamingid').html($(this).val());
                })

                $("input[name=experience]").click(function() {
                    $('.experienceid').html($(this).val());

                    if ($("#e1").prop("checked")) {
                        $('.your-rank').css('display', 'block')
                    } else {
                        $('.your-rank').css('display', 'none')
                    }

                });


                $("input[name=experience]").click(function() {
                    if ($("#ge1").prop("checked", true)) {

                        $('.gamingrank').css('display', 'block')
                    } else {
                        $('.gamingrank').css('display', 'none')
                    }
                });



            });



            function myFunction() {
                var checkBox = document.getElementById("myCheck");
                var text = document.getElementById("update-password");
                if (checkBox.checked == true) {
                    text.style.display = "block";
                } else {
                    text.style.display = "none";
                }
            }
        </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/admin/user/tabs/booking/index.blade.php ENDPATH**/ ?>