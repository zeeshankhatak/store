<section>

<footer>
  <div class="ftr-overlay"></div>
   <div class="ftr-top">
    <div class="container">
      <div class="row">
        <div class="col-md-12 m-auto">
          <h2>Games</h2>
          <ul class="ftr-menu">
            <li><a href="<?php echo e(url('/apex-legends')); ?>">Apex Legends</a></li>
            <li><a href="<?php echo e(url('/call-of-duty')); ?>">Call of Duty</a></li>
            <li><a href="<?php echo e(url('/fortnite')); ?>">Fortnite</a></li>
            <li><a href="<?php echo e(url('/valorant')); ?>">Valorant</a></li>
          </ul>
          <h2 class="contact"><a href="javascript:;" class="popup-open">CONTACT US</a></h2>
        </div>
      </div>
    </div>
  </div>
  <div class="ftr-bottom">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <a href="" class="ftr-logo"><img src="<?php echo e(asset('gaming-assets/images/OPMfg.png')); ?>"></a>
          <ul class="copyright">
            <li><a href="javascript:;">Privacy Policy</a></li>
            <li><a href="javascript:;">Terms & Conditions</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <a href="#top" class="bottomtotop"><i class="icon-arrow-up"></i></a>
</footer>

</section>

<div class="popup">
  <div class="popup-container">
      <h2>CUSTOMER SUPPORT</h2>
      <p>Have a question or need help?</p>

      <form action="" method="post" class="popup-form" novalidate="novalidate">
        <div class="form-group">
            <input type="text" class="" name="name" id="name" value="" placeholder="Name" required="required">
        </div>
        <div class="form-group">
            <select class="" name="SelectionCategory" id="SelectionCategory" value="" required="required">
                <option value="Selection Category">Selection Category</option>
                <option value="Membership/Payment">Membership/Payment</option>
                <option value="Coaching">Coaching</option>
                <option value="Report an Issue">Report an Issue</option>
                <option value="Suggestions">Suggestions</option>
                <option value="Other">Other</option>
            </select>
        </div>
        <div class="form-group">
            <input type="email" class="" name="email" id="email" value="" placeholder="Email" required="required">
        </div>
        <div class="form-group">
            <textarea type="text" class="" name="message" id="message" value="" placeholder="Message"></textarea>
        </div>
        <div class="form-group">
          <input type="submit" class="submit" value="Submit">
        </div>
      </form>
      <a href="javascript:;" class="popup-close">×</a>
  </div>
</div>
  <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
 

   <!-- Gaming Portal js start -->

<!-- test -->
<script src="<?php echo e(asset('gaming-assets/js/mlib.js')); ?>"></script>
<script src="<?php echo e(asset('gaming-assets/js/function.js')); ?>"></script>



<!-- Gaming Portal js start -->

  <script type="text/javascript">

   $(function () {
  $('.popup-open').click(function () {
    $('.popup').addClass('active');

    if ($('.popup').hasClass('active')) {
      $('.cont').addClass('blur');
    }
  });

  $('.popup-close').click(function () {
    $('.popup').removeClass('active');
    $('.cont').removeClass('blur');
  });
});

   $(document).ready(function(){

    $('.venobox').venobox(
      { frameheight: "400px" });
});

  </script>

<script type="text/javascript">

</script>

<!-- Gaming Portal footer end -->
<?php echo $__env->make('instructormodel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/fpsaquaclients/public_html/resources/views/theme/footer.blade.php ENDPATH**/ ?>