<?php $__env->startSection('title', 'Change Password'); ?>

<?php echo $__env->make('theme.Gamingportal-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- end head -->
<!-- body start-->
<body>

<body class="login" id="">


    <section class="login-sec">
      <div class="logo ">
        <a class="" href="javascript:;"><img src="<?php echo e(asset('gaming-assets/images/OPMfg.png')); ?>" alt=""></a>
      </div>
        <h1 class="formHeading">Change password</h1>
        <form class="loginForm" id="" action="<?php echo e(route('confirm')); ?>" method="post">
            <?php echo csrf_field(); ?>

         <div class="form-group">
            <label for="pass">New Password</label>
            <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="pass" required/>
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
         <div class="form-group">
            <label for="pass">Confirm Password</label>
            <input type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" id="pass" required/>
            <input type="hidden" class="form-control" value="<?php echo e($data->email); ?>" name="email"  required/>
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <input type="submit" name="submit" class="button" value="Change Password">
          </div>
        </form>

    </section>


    </body>
<!--  Signup end-->
<!-- jquery -->
<?php echo $__env->make('theme.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end jquery -->
</body>
<!-- body end -->
</html>






<?php /**PATH /home/fpsaquaclients/public_html/resources/views/auth/passwords/new/reset.blade.php ENDPATH**/ ?>