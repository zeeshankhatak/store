<section class="join-community">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="text" data-aos="fade-right" data-aos-delay="300" data-aos-duration="600">
          <h2 class="sub-title">Teamwork and communication.</h2>
          <h1 class="">JOin Our <span class="redColor">Community</span></h1>
          <p>Share your experience, progress and clips with the rest of our community.</p>
        </div>
        <ul>
          <li><a href=""><i class=""><img src="<?php echo e(asset('gaming-assets/images/discord-logo.svg')); ?>"></i></a></li>
          <li><a href=""><i class="icon-tiktok"></i></a></li>
          <li><a href=""><i class="icon-facebook"></i></a></li>  
          <li><a href=""><i class="icon-twitter"></i></a></li>
          <li><a href=""><i class="icon-insta"></i></a></li>
        </ul>
    </div>
  </div>
</section><?php /**PATH /home/centauruscrm/fps.centauruscrm.com/resources/views/theme/join-community.blade.php ENDPATH**/ ?>