<?php $__env->startSection('title', 'Reset Password'); ?>

<?php echo $__env->make('theme.Gamingportal-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- end head -->
<!-- body start-->
<body>

<body class="login" id="">

    <?php if(session('status')): ?>
    <div class="alert alert-danger"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    
    <section class="login-sec">
      <div class="logo ">
        <a class="" href="javascript:;"><img src="<?php echo e(asset('gaming-assets/images/OPMfg.png')); ?>" alt=""></a>
      </div>
        <h1 class="formHeading mb-0">Forgot password?</h1>
        <p class="formtxt">Reset password in two quick steps</p>
        <form class="loginForm" id="" action="<?php echo e(route('send.email')); ?>" method="get">
            <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="user">Email Address</label>
            <input type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" id="user" required/>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($errors->first('email')); ?></strong>
                 </span>
            <?php endif; ?>
          </div>
      
          <div class="form-group">
            <input type="submit" name="submit" class="button" value="Reset Password">
          </div>
        </form>
      
    </section>


    </body>
<!--  Signup end-->
<!-- jquery -->
<?php echo $__env->make('theme.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end jquery -->
</body>
<!-- body end -->
</html>






<?php /**PATH /home/fpsaquaclients/public_html/resources/views/auth/passwords/new/email.blade.php ENDPATH**/ ?>