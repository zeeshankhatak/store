

<?php $__env->startSection('title', 'Gamer-Register'); ?>
<?php $__env->startSection('content'); ?>


<!-- body start gaming portal -->
<section class="register-sec pb-150">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <form id="register-form" class="register-form" method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="upload-profile">
                  <img src="https://www.centauruscrm.com/uploads/staff_profile_images/10/thumb_pp.jpg" class="img img-responsive staff-profile-image-thumb">
                  <div class="upload-btn-wrapper">
                     <button class="btn">Upload a file</button>
                     <input type="file" name="image" />
                  </div>
              </div>
              <div id="Personal_Information" class="tabcontent " style="display: block;">
                <p class="form-row form-group">
                    <label for="name">First Name </label>
                    <input placeholder="First Name" type="text" class="input-text form-control" name="fname" id="fname" value="" >
                    <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group">
                    <label for="name">Last Name </label>
                    <input placeholder="Last Name" type="text" class="input-text form-control" name="lname" id="lname" value="" >
                    <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>

                <p class="form-row form-group form-row-wide">
                    <label for="reg_email">Email Address <span class="required">*</span></label>
                    <input placeholder="Email" type="email" class="input-text form-control" name="email" id="reg_email" value="" >
                    <label generated="true" class="reg_email_error"></label>
                     <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    
                </p>

                <p class="form-row form-group form-row-wide">
                  <label for="password">Password <span class="required">*</span></label>
                  <input placeholder="Password" type="password" class="input-text form-control" name="password" id="password" value="" >
                  <label generated="true" class="reg_email_error"></label>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color:black"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </p>


                <p>Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our <a href="javascript:;" class="privacy-policy-link" target="_blank">privacy policy</a>.</p>
                <p class="form-row submitt-btn">
                    
                    <input type="submit" class="dokan-btn dokan-btn-theme" name="register" value="Register">
                </p>
             </div>

            <!-- Spam Trap -->
            

          </form>
        </div>
      </div>
    </div>
  </section>

<?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- body end gaming portal -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/auth/register.blade.php ENDPATH**/ ?>