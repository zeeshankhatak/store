<?php $__env->startSection('title', 'Gaming - Find Pro Squad'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- categories-tab start-->

<!-- categories-tab end-->





<!-- home end -->
<!-- learning-work start -->


<!-- learning-work end -->
<!-- learning-courses start -->

<!-- learning-courses end -->
<!-- Student start -->

<!-- Students end -->

<!-- Zoom start -->

<!-- Zoom end -->

<!-- Bundle start -->

<!-- Bundle end -->
<!-- Bundle start -->

<!-- Bundle end -->
<!-- recommendations start -->

<!-- recommendations end -->
<!-- categories start -->


<!-- categories end -->
<!-- testimonial start -->
 

<!-- testimonial start End-->

    <!-- body start gaming portal -->
 <body id="bottomtotop">

<section class="home-video">
    <video width="100" autoplay muted loop>
      <source src="<?php echo e(asset('gaming-assets/videos/Logo-FPSLoungeANIM01-1.mp4')); ?>" type="video/mp4">
      <source src="movie.ogg" type="video/ogg">
    Your browser does not support the video tag.
    </video>
    <div class="video-overlay"></div>
    <div class="arrow" data-aos="fade-left" data-aos-delay="300" data-aos-duration="600">
      <a href="#our-coaches"></a>
    </div>
</section>


<section class="our-coaches" id="our-coaches">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="">Our <span class="redColor">Coaches</span></h1>
           <div class="coach-slider">
              <div class="coach">
                <div class="image">
                  <img src="<?php echo e(asset('gaming-assets/images/cropped-IMG_0139.jpg')); ?>">
                </div>
                <div class="content">
                  <h2>John Doe</h2>
                  <p>Apex Legend</p>
                </div>
              </div>
              <div class="coach">
                <div class="image">
                  <img src="<?php echo e(asset('gaming-assets/images/cropped-69495847_l.jpg')); ?>">
                </div>
                <div class="content">
                  <h2>John Doe</h2>
                  <p>Apex Legend</p>
                </div>
              </div>
              <div class="coach">
                <div class="image">
                  <img src="<?php echo e(asset('gaming-assets/images/cropped-CsABWARWEAESRup.jpg')); ?>">
                </div>
                <div class="content">
                  <h2>John Doe</h2>
                  <p>Apex Legend</p>
                </div>
              </div>
              <div class="coach">
                <div class="image">
                  <img src="<?php echo e(asset('gaming-assets/images/c5.jpg')); ?>">
                </div>
                <div class="content">
                  <h2>John Doe</h2>
                  <p>Apex Legend</p>
                </div>
              </div>
              <div class="coach">
                <div class="image">
                  <img src="<?php echo e(asset('gaming-assets/images/cropped-gaming-channel.jpeg')); ?>">
                </div>
                <div class="content">
                  <h2>John Doe</h2>
                  <p>Apex Legend</p>
                </div>
              </div>
          </div>
      </div>
    </div>
  </div>
</section>


<section class="join-lounge">
  <div class="container">
    <div class="row">
      <div class="col-md-6 my-auto">
        <div class="text" data-aos="fade-right" data-aos-delay="300" data-aos-duration="600">
          <h1 class="">JOIN  <span class="redColor">FPS LOUNGE</span></h1>
          <p>Get ready to catch some dubs and improve your stats! Don’t spend your time trying to find skilled teammates. Our coaches are in the top 1% of their respective games.</p>
          <a href="<?php echo e(route('register')); ?>" class="btn" role="button">Register now</a>
        </div>
      </div>
      <div class="col-md-6" data-aos="fade-left" data-aos-delay="300" data-aos-duration="600">
        <figure>
          <img src="<?php echo e(asset('gaming-assets/images/Layer-17.png')); ?>">
        </figure>
      </div>
    </div>
  </div>
</section>

<section class="video-sec">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="video-bx">

          <a data-gall="gall-video" data-autoplay="true" data-vbtype="video" class="venobox vbox-item" href="<?php echo e(asset('gaming-assets/videos/Logo-FPSLoungeANIM01-1.mp4')); ?>">
            <i class="icon-play"></i>
          </a>
        </div>
        </div>
    </div>
  </div>
</section>

<section class="be-coach">
  <div class="container">
    <div class="row">
      <div class="col-md-6" data-aos="fade-right" data-aos-delay="300" data-aos-duration="600">
        <figure>
          <img src="<?php echo e(asset('gaming-assets/images/section-home-01.png')); ?>">
        </figure>
      </div>
      <div class="col-md-6">
        <div class="text">
          <h1 class="heading-stroke" data-aos="fade-left" data-aos-delay="300" data-aos-duration="600"> <span>BECOME</span> A  <br>COACH</h1>
          <p data-aos="fade-left" data-aos-delay="300" data-aos-duration="600">Make your passion your profession. Sharpen your skills by dropping some knowledge to up-and-coming gamers.</p>
         <a href="<?php echo e(url('/coach-registration')); ?>" class="btn" role="button" data-aos="fade-left" data-aos-delay="300" data-aos-duration="600">Apply now</a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<!-- body end gaming portal -->





 <?php $__env->stopSection(); ?>











<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/centauruscrm/fps.centauruscrm.com/resources/views/home.blade.php ENDPATH**/ ?>