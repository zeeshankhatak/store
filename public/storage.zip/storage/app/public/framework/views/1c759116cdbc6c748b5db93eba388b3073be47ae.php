<?php $__env->startSection('title', 'View staff - Admin'); ?>
<?php $__env->startSection('body'); ?>

    <section class="content">
        <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="box box-primary">
                    <div class="box-header with-border">

                            <h3 class="box-title">Add Staff</h3>

                    </div>
                    <div class="box-header">

 <?php if(auth()->user()->role->permission['capabilities']['staff']['create']==1): ?>
                        <a class="btn btn-info btn-sm" href="<?php echo e(route('staff.create')); ?>">+
                            <?php echo e(__('adminstaticword.Add')); ?>

                            Staff</a>
<?php endif; ?>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped table-responsive">
                                <thead>
                                    <th>#</th>
                                    <th><?php echo e(__('adminstaticword.Image')); ?></th>
                                    <th><?php echo e(__('adminstaticword.FirstName')); ?></th>
                                    <th><?php echo e(__('adminstaticword.LastName')); ?></th>
                                    <th><?php echo e(__('adminstaticword.Email')); ?></th>
                                    <th>Role</th>

                                    <?php if(auth()->user()->role->permission['capabilities']['staff']['edit']==1): ?>

                                        <th><?php echo e(__('adminstaticword.Edit')); ?></th>
                                    <?php endif; ?>
                                    <?php if(auth()->user()->role->permission['capabilities']['staff']['delete']==1): ?>
                                        <th><?php echo e(__('adminstaticword.Delete')); ?></th>
                                    <?php endif; ?>
                                </thead>

                                <tbody>
                                    <?php $i = 0; ?>
                                    <!-- <?php if(isset($staffs)): ?>  -->
                                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php $i++; ?>

                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td>
                                                <?php if($staff->staff_img != null || $staff->staff_img != ''): ?>
                                                    <img src="<?php echo e(url('/images/user_img/' . $staff->user_img)); ?>"
                                                        class="img-responsive">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('images/default/user.jpg')); ?>"
                                                        class="img-responsive" alt="User Image">
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($staff->fname); ?></td>
                                            <td><?php echo e($staff->lname); ?></td>
                                            <td><?php echo e($staff->email); ?></td>
                                            <td>
                                                <?php echo e($staff->name); ?>

                                            </td>
                                            <?php if(auth()->user()->role->permission['capabilities']['staff']['edit']==1): ?>
                                                <td>
                                                    <a class="btn btn-success btn-sm"
                                                        href="<?php echo e(route('staff.edit', $staff->id)); ?>">
                                                        <i class="glyphicon glyphicon-pencil"></i></a>
                                                </td>
                                            <?php endif; ?>
                                            <?php if(auth()->user()->role->permission['capabilities']['staff']['delete']==1): ?>
                                                <td>
                                                    <form method="post" action="<?php echo e(route('staff.destroy', $staff->id)); ?>

                                                " data-parsley-validate class="form-horizontal form-label-left">
                                                        <?php echo e(csrf_field()); ?>

                                                        <?php echo e(method_field('DELETE')); ?>


                                                        <button onclick="return confirm('Are you sure you want to delete?')"
                                                            type="submit" class="btn btn-danger btn-sm"><i
                                                                class="fa fa-fw fa-trash-o"></i></button>
                                                    </form>
                                                </td>
                                            <?php endif; ?>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- <?php endif; ?> -->

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/admin/staff/index.blade.php ENDPATH**/ ?>