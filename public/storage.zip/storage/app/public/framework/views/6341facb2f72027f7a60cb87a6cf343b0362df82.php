<?php $__env->startSection('body'); ?>
<?php $__env->startSection('title', 'Staff User - Admin'); ?>

<?php if($errors->any()): ?>
<div class="alert alert-danger">
  <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php endif; ?>

<section class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"> <?php echo e(__('adminstaticword.Add')); ?> <?php echo e(__('adminstaticword.Users')); ?></h3>
        </div>
        <div class="panel-body">
          <form action="<?php echo e(route('staff.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>


            <div class="row">
              <div class="col-md-6 col-6">
                 <label for="fname">
                <?php echo e(__('adminstaticword.FirstName')); ?>:<sup class="redstar">*</sup>
                </label>
                <input value="" autofocus required name="fname" type="text" class="form-control" placeholder="Enter your first name"/>
              </div>
              <div class="col-md-6 col-6">
                <label for="lname">
                  <?php echo e(__('adminstaticword.LastName')); ?>:<sup class="redstar">*</sup>
                </label>
                <input value="" required name="lname" type="text" class="form-control" placeholder="Enter your last name"/>
              </div>
            </div>
            <br>

            <div class="row">
              <div class="col-md-6">
                 <label for="mobile"><?php echo e(__('adminstaticword.Email')); ?>: <sup class="redstar">*</sup></label>
                  <input value="" required type="email" name="email" placeholder="Enter your email" class="form-control">
              </div>
              <div class="col-md-6">
                <label for="mobile"><?php echo e(__('adminstaticword.Mobile')); ?>: <sup class="redstar">*</sup></label>
                <input value="" required type="text" name="mobile" placeholder="Enter your mobile number" class="form-control">
              </div>
            </div>
            <br>

            <div class="row">
              <div class="col-md-6">
                <label for="exampleInputDetails"><?php echo e(__('adminstaticword.Address')); ?>:<sup class="redstar">*</sup></label>
                <textarea name="address" rows="1"  class="form-control" placeholder="Enter your address"></textarea>
              </div>
              <div class="col-md-6">
                <label for="dob"><?php echo e(__('adminstaticword.DateofBirth')); ?>:<sup class="redstar">*</sup></label>
                <div class="input-group date">
                  <div class="input-group-addon">
                    <i class="fa fa-calendar"></i>
                  </div>
                  <input type="text" value="" name="dob" required class="form-control pull-right" id="dob" placeholder="Enter your date of birth">
                </div>

              </div>
            </div>
            <br>

            <div class="row">
              <div class="col-md-6">
                <label for="gender"><?php echo e(__('adminstaticword.Gender')); ?>: <sup class="redstar">*</sup></label>

                <br>
                <input type="radio" name="gender" id="ch1" value="m" required> <?php echo e(__('adminstaticword.Male')); ?>

                <input type="radio" name="gender" id="ch2" value="f"> <?php echo e(__('adminstaticword.Female')); ?>

                <input type="radio" name="gender" id="ch3" value="o"> <?php echo e(__('adminstaticword.Other')); ?>

              </div>
              <div class="col-md-6">
                <label for="mobile"><?php echo e(__('adminstaticword.Password')); ?>: <sup class="redstar">*</sup> </label>
                <input required type="password" name="password" placeholder="Enter your password" class="form-control">
              </div>
            </div>
            <br>

            <div class="row">
              <div class="col-md-3">
                <label for="city_id">Assign Role: </label>
                <select id="country_id" class="form-control js-example-basic-single" name="role_id">
                  <option value="none" selected disabled hidden>
                    Select Role
                  </option>
                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" ><?php echo e($role->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>

            </div>
            <br>

            


            <div class="row">
              
                <input type="hidden" name="verified" value="1" id="jeet11">

              <div class="col-md-3">
                <label for="exampleInputDetails"><?php echo e(__('adminstaticword.Status')); ?>:</label>
                <li class="tg-list-item">
                <input class="tgl tgl-skewed" id="jeet120"  type="checkbox"/>
                <label class="tgl-btn" data-tg-off="Deactive" data-tg-on="Active" for="jeet120"></label>
                </li>
                <input type="hidden" name="status" value="0" id="jeet121">
              </div>
            </div>
            <br>

            


            

            


            <div class="box-footer">
              <button type="submit" class="btn btn-md btn-primary">
                <i class="fa fa-plus-circle"></i> <?php echo e(__('adminstaticword.AddUser')); ?>

              </button>
            </form>
              <a href="<?php echo e(route('staff.index')); ?>" title="Cancel and go back" class="btn btn-md btn-default btn-flat">
                <i class="fa fa-reply"></i> <?php echo e(__('adminstaticword.Back')); ?>

              </a>
            </div>
            <br>


        </div>
        <!-- /.panel body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
(function($) {
  "use strict";

  $('#married_status').change(function() {

    if($(this).val() == 'Married')
    {
      $('#doaboxxx').show();
    }
    else
    {
      $('#doaboxxx').hide();
    }
  });

  $(function() {
    $( "#dob,#doa" ).datepicker({
      changeYear: true,
      yearRange: "-100:+0",
      dateFormat: 'yy/mm/dd',
    });
  });

  tinymce.init({selector:'textarea#detail'});

  $(function() {
    var urlLike = '<?php echo e(url('country/dropdown')); ?>';
    $('#country_id').change(function() {
      var up = $('#upload_id').empty();
      var cat_id = $(this).val();
      if(cat_id){
        $.ajax({
          headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          type:"GET",
          url: urlLike,
          data: {catId: cat_id},
          success:function(data){
            console.log(data);
            up.append('<option value="0">Please Choose</option>');
            $.each(data, function(id, title) {
              up.append($('<option>', {value:id, text:title}));
            });
          },
          error: function(XMLHttpRequest, textStatus, errorThrown) {
            console.log(XMLHttpRequest);
          }
        });
      }
    });
  });

  $(function() {
    var urlLike = '<?php echo e(url('country/gcity')); ?>';
    $('#upload_id').change(function() {
      var up = $('#grand').empty();
      var cat_id = $(this).val();
      if(cat_id){
        $.ajax({
          headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          type:"GET",
          url: urlLike,
          data: {catId: cat_id},
          success:function(data){
            console.log(data);
            up.append('<option value="0">Please Choose</option>');
            $.each(data, function(id, title) {
              up.append($('<option>', {value:id, text:title}));
            });
          },
          error: function(XMLHttpRequest, textStatus, errorThrown) {
            console.log(XMLHttpRequest);
          }
        });
      }
    });
  });
})(jQuery);
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/centauruscrm/fps.centauruscrm.com/resources/views/admin/staff/adduser.blade.php ENDPATH**/ ?>