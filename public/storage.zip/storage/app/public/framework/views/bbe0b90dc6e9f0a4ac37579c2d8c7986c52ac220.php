
<?php $__env->startSection('title', 'All Order - Admin'); ?>
<?php $__env->startSection('body'); ?>

<section class="content">
  <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="row">
    <div class="col-xs-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"> <?php echo e(__('adminstaticword.Orders')); ?></h3>
        </div>
        <?php if(Auth::User()->role == "admin"): ?>
        <div class="box-header with-border">

          <a class="btn btn-info btn-md" href="<?php echo e(route('order.create')); ?>">
          <i class="glyphicon glyphicon-th-l">+</i> Enroll&nbsp;User</a>

        </div>
        <?php endif; ?>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">
              <thead>

                <br>
                <br>
                <tr>
                  
                  <th><?php echo e(__('adminstaticword.Order #')); ?></th>
                  
                  
                  
                  <th><?php echo e(__('adminstaticword.Game')); ?></th>
                  
                  <th><?php echo e(__('adminstaticword.Gamer Name')); ?></th>
                  <th><?php echo e(__('adminstaticword.PackageAmount')); ?></th>
                  <th><?php echo e(__('adminstaticword.Game Date | Time')); ?></th>
                  <th><?php echo e(__('adminstaticword.Payment Status')); ?></th>
                  <th><?php echo e(__('adminstaticword.Status')); ?></th>

                </tr>
              </thead>
              <tbody>
              <?php $i=0;?>
              <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            

                
                <tr>
                  

                  <td><?php echo e($order->order_num); ?></td>
                  
                  <td><?php echo e($order->game_name); ?></td>

                  

                  <td><?php echo e($order->user_fname); ?> <?php echo e($order->user_lname); ?></td>
                  <td>$<?php echo e($order->total); ?></td>
                  

                  <td><?php echo e($order->assign_date); ?></td>

                  <td>
                    <span  type="Submit" class="btn btn-xs <?php echo e($order->order_status ==1 ? 'btn-success' : 'btn-danger'); ?>">
                      <?php if($order->order_status ==1): ?>
                        <?php echo e(__('adminstaticword.Paid')); ?>

                      <?php else: ?>
                        <?php echo e(__('adminstaticword.Unpaid')); ?>

                      <?php endif; ?>
                    </span>
                </td>



                  <td>
                    <span  type="Submit" class="btn btn-xs <?php echo e($order->coach_status ==1 ? 'btn-success' : 'btn-danger'); ?>">
                      <?php if($order->coach_status ==1): ?>
                        <?php echo e(__('adminstaticword.Accepted')); ?>

                      <?php else: ?>
                        <?php echo e(__('adminstaticword.Pending')); ?>

                      <?php endif; ?>
                    </span>
                </td>


                  

                  




                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<script>
    $(document).ready(function(){

        $('#example1').dataTable( {
        "ordering": false
        } );

        // $(document).on('click','.btn-coach',function(e){
        //     e.preventDefault();
        //     var order_num = $(this).val();
        //     console.log(order_num);
        //     $("#Coach_DateTime").modal('show');
        //     $(".order_id").val(order_num);

        // });

        // $(document).on('click','.btn_save',function(){
        //     var date = $(".update-date ").val();
        //     var order_num = $(".order_id").val();

        //     console.log(date);
        //     console.log(order_num);

        //     $.ajaxSetup({
        //         headers: {
        //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        //         }
        //     });

        //     $.ajax({
        //         type:'PUT',
        //         url:'updatedate/'+order_num,
        //         data:{up_date:date},
        //         dataType:'json',
        //         success:function(response){
        //             console.log(response);
        //             if(response.status == 200){
        //                 $("#message-box").html("");
        //                 $("#message-box").addClass('alert alert-success');
        //                 $("#message-box").html(response.message);
        //                 $("#message-box").fadeIn("slow");
        //                 setTimeout(function(){
        //                     $("#message-box").fadeOut("slow")
        //                 },3000);
        //                 $("#Coach_DateTime").modal("hide");
        //                 $("#Coach_DateTime").find("input").val("");
        //             }
        //         }
        //     });
        // });

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/instructor/order/index.blade.php ENDPATH**/ ?>