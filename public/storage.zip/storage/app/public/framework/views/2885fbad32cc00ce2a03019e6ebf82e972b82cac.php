<!-- Gaming Portal js start -->

<!-- Gaming Portal js start -->






	


    




<?php echo $__env->yieldContent('custom-script'); ?>
<?php /**PATH /home/centauruscrm/fps.centauruscrm.com/resources/views/theme/scripts.blade.php ENDPATH**/ ?>