<?php $__env->startSection('title', 'Fortnite'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- body start gaming portal -->
<body class="gamePg">
    <div class="coachBanner" style="background: url(<?php echo e(asset('gaming-assets/images/fortnite-banner.png')); ?>) no-repeat top center;"></div>

<section class="gaming-sec">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <p class="main">Coaches work closely with the players to identify their strengths and weaknesses, motivate them, and make sure they are playing at their best. </p>
          <form method="post" class="codForm" action="">
            <ul class="game-selection tabs">

              <li class="current" data-tab="tab1"><span>1. CHOOSE YOUR GAMING EXPERIENCE<i class="icon-keyboard_arrow_down"></i>
                <span class="experienceid selectedValue"></span></span>
                <div class="drop-down gaming-exp tab-content current" id="tab1">
                    <div class="item">
                      <input type="radio" id="e1" value="FOCUS ON COACHING" name="experience"/>
                        <label for="e1">
                          <h2>FOCUS ON COACHING</h2>
                          <p>- Improve stats</p>
                          <p>- Learn the best tips and tricks</p>
                          <p>- Teach you the best loadouts and weapon mods</p>
                        </label>
                    </div>
                    <div class="item">
                      <input type="radio" id="e2" value="CASUAL GAMES" name="experience"/>
                        <label for="e2">
                          <h2>CASUAL GAMES</h2>
                          <p>- Looking for a good time</p>
                          <p>- Enjoy skilled teammates</p>
                          <p>- Great vibes</p>
                        </label>
                    </div>
                     <div class="item">
                      <input type="radio" id="e3" value="VIDEO REVIEWS" name="experience"/>
                        <label for="e3">
                          <h2>VIDEO REVIEWS</h2>
                          <p>Allow our coaches to rewatch film of your gameplay and analyze how to make better decisions.</p>
                        </label>
                    </div>
                </div>
              </li>

                <li data-tab="tab2"><span>2. HOW MANY HOURS DO YOU WANT TO PLAY?<i class="icon-keyboard_arrow_down"></i>
                 <span class="durationid selectedValue"></span></span>
                  <div class="drop-down gaming-duration  tab-content" id="tab2">
                      <div class="item">
                        <input type="radio" id="d1" value="1 HOUR" name="duration"/>
                        <label for="d1">1 HOUR</label>
                      </div>
                      <div class="item">
                        <input type="radio" id="d2" value="2 HOUR" name="duration">
                        <label for="d2">2 HOUR</label>
                      </div>
                       <div class="item">
                        <input type="radio" id="d3" value="3 HOUR" name="duration">
                        <label for="d3">3 HOUR</label>
                      </div>
                  </div>
                </li>

                <li><span>3. CHOOSE YOUR COACH(ES) </span>
                  <div class="drop-down choose-coach">
                      <div class="radio-buttons">
                        <input type="radio" name="chooseCoach" value="Coach" id="btn1"/>
                        <label for="btn1"><span class="number">1</span> Coach</label>
                        <input type="radio" name="chooseCoach" value="Coaches" id="btn2" checked />
                        <label for="btn2"><span class="number">2</span> Coaches</label>
                      </div>
                      <div class="buttons-grp">
                        <input type="button" name="coachbtn" class="coachbtn btn1" placeholder="CHOOSE A COACH" value="CHOOSE A COACH" />
                        <input type="button" name="coachbtn" class="coachbtn btn2" placeholder="CHOOSE A COACH" value="CHOOSE A COACH" />
                        <input type="submit" name="submit" value="SUBMIT MY SESSION" />
                      </div>
                  </div>
                </li>

            </ul>

            <div class="coach-list-wrapper">
              <div class="coach-list">
                <div class="img"><img src="<?php echo e(asset('gaming-assets/images/cropped-69495847_l.jpg')); ?>"></div>
                <div class="text"><h2>John Doe</h2></div>
                <ul class="profile">
                  <li><div class="left"><h2>Languages</h2></div>
                   <div class="right"> <p>English - Spanish</p></div>
                 </li>
                  <li><div class="left"><h2>Play on</h2></div>
                    <div class="right"><p>Controller</p>
                    </li>
                  <li><div class="left"><h2>K/D</h2></div>
                    <div class="right"><p>3.6</p></div>
                  </li>
                  <li><div class="left"><h2>Total Wins</h2></div>
                    <div class="right"><p>1097</p></div>
                  </li>
                  <li><div class="left"><h2 class="charges"><sup>$</sup>14 /<span>per hour</br> for this Pro</span></h2></div>
                    <div class="right"><div class="chat"><a href="">CHAT WITH THIS PRO</a></div></div>
                    </li>
                </ul>
                <div class="btn play-btn"><a href="">PLAY WITH THIS COACH</a></div>
              </div>
              <div class="coach-list">
                <div class="img"><img src="<?php echo e(asset('gaming-assets/images/c5.jpg')); ?>"></div>
                <div class="text"><h2>John Doe</h2></div>
                <ul class="profile">
                  <li><div class="left"><h2>Languages</h2></div>
                   <div class="right"> <p>English - Spanish</p></div>
                 </li>
                  <li><div class="left"><h2>Play on</h2></div>
                    <div class="right"><p>Controller</p>
                    </li>
                  <li><div class="left"><h2>K/D</h2></div>
                    <div class="right"><p>3.6</p></div>
                  </li>
                  <li><div class="left"><h2>Total Wins</h2></div>
                    <div class="right"><p>1097</p></div>
                  </li>
                  <li><div class="left"><h2 class="charges"><sup>$</sup>14 /<span>per hour</br> for this Pro</span></h2></div>
                    <div class="right"><div class="chat"><a href="">CHAT WITH THIS PRO</a></div></div>
                    </li>
                </ul>
                <div class="btn play-btn"><a href="">PLAY WITH THIS COACH</a></div>
              </div>
              <div class="coach-list">
                <div class="img"><img src="<?php echo e(asset('gaming-assets/images/cropped-fotoezh-2-2811.1200x1200.jpg')); ?>"></div>
                <div class="text"><h2>John Doe</h2></div>
                <ul class="profile">
                  <li><div class="left"><h2>Languages</h2></div>
                   <div class="right"> <p>English - Spanish</p></div>
                 </li>
                  <li><div class="left"><h2>Play on</h2></div>
                    <div class="right"><p>Controller</p>
                    </li>
                  <li><div class="left"><h2>K/D</h2></div>
                    <div class="right"><p>3.6</p></div>
                  </li>
                  <li><div class="left"><h2>Total Wins</h2></div>
                    <div class="right"><p>1097</p></div>
                  </li>
                  <li><div class="left"><h2 class="charges"><sup>$</sup>14 /<span>per hour</br> for this Pro</span></h2></div>
                    <div class="right"><div class="chat"><a href="">CHAT WITH THIS PRO</a></div></div>
                    </li>
                </ul>
                <div class="btn play-btn"><a href="">PLAY WITH THIS COACH</a></div>
              </div>
              <div class="coach-list">
                <div class="img"><img src="<?php echo e(asset('gaming-assets/images/cropped-gaming-channel.jpeg')); ?>"></div>
                <div class="text"><h2>John Doe</h2></div>
                <ul class="profile">
                  <li><div class="left"><h2>Languages</h2></div>
                   <div class="right"> <p>English - Spanish</p></div>
                 </li>
                  <li><div class="left"><h2>Play on</h2></div>
                    <div class="right"><p>Controller</p>
                    </li>
                  <li><div class="left"><h2>K/D</h2></div>
                    <div class="right"><p>3.6</p></div>
                  </li>
                  <li><div class="left"><h2>Total Wins</h2></div>
                    <div class="right"><p>1097</p></div>
                  </li>
                  <li><div class="left"><h2 class="charges"><sup>$</sup>14 /<span>per hour</br> for this Pro</span></h2></div>
                    <div class="right"><div class="chat"><a href="">CHAT WITH THIS PRO</a></div></div>
                    </li>
                </ul>
                <div class="btn play-btn"><a href="">PLAY WITH THIS COACH</a></div>
              </div>
              <div class="coach-list">
                <div class="img"><img src="<?php echo e(asset('gaming-assets/images/cropped-CsABWARWEAESRup.jpg')); ?>"></div>
                <div class="text"><h2>John Doe</h2></div>
                <ul class="profile">
                  <li><div class="left"><h2>Languages</h2></div>
                   <div class="right"> <p>English - Spanish</p></div>
                 </li>
                  <li><div class="left"><h2>Play on</h2></div>
                    <div class="right"><p>Controller</p>
                    </li>
                  <li><div class="left"><h2>K/D</h2></div>
                    <div class="right"><p>3.6</p></div>
                  </li>
                  <li><div class="left"><h2>Total Wins</h2></div>
                    <div class="right"><p>1097</p></div>
                  </li>
                  <li><div class="left"><h2 class="charges"><sup>$</sup>14 /<span>per hour</br> for this Pro</span></h2></div>
                    <div class="right"><div class="chat"><a href="">CHAT WITH THIS PRO</a></div></div>
                    </li>
                </ul>
                <div class="btn play-btn"><a href="">PLAY WITH THIS COACH</a></div>
              </div>
              <div class="coach-list">
                <div class="img"><img src="<?php echo e(asset('gaming-assets/images/cropped-IMG_0139.jpg')); ?>"></div>
                <div class="text"><h2>John Doe</h2></div>
                <ul class="profile">
                  <li><div class="left"><h2>Languages</h2></div>
                   <div class="right"> <p>English - Spanish</p></div>
                 </li>
                  <li><div class="left"><h2>Play on</h2></div>
                    <div class="right"><p>Controller</p>
                    </li>
                  <li><div class="left"><h2>K/D</h2></div>
                    <div class="right"><p>3.6</p></div>
                  </li>
                  <li><div class="left"><h2>Total Wins</h2></div>
                    <div class="right"><p>1097</p></div>
                  </li>
                  <li><div class="left"><h2 class="charges"><sup>$</sup>14 /<span>per hour</br> for this Pro</span></h2></div>
                    <div class="right"><div class="chat"><a href="">CHAT WITH THIS PRO</a></div></div>
                    </li>
                </ul>
                <div class="btn play-btn"><a href="">PLAY WITH THIS COACH</a></div>
              </div>
            </div>
          </form>
      </div>
    </div>
  </div>
</section>

<?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>


<!-- body end gaming portal -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/centauruscrm/fps.centauruscrm.com/Osama/resources/views/fortnite.blade.php ENDPATH**/ ?>