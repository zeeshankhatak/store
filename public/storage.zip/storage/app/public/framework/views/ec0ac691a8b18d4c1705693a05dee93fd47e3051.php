
<?php $__env->startSection('title', 'All Order - Admin'); ?>
<?php $__env->startSection('body'); ?>

<section class="content">
  <?php echo $__env->make('gamer.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="row">
    <div class="col-xs-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"> <?php echo e(__('adminstaticword.Wallet')); ?></h3>
           <label for="">Current Balance</label>&nbsp;&nbsp;&nbsp;
            <span>$ <?php echo e($current_bal->total); ?></span>
        </div>

        <!-- /.box-header -->
        <div class="box-body">
            <label for="">Current Balance</label>&nbsp;&nbsp;&nbsp;
            <span>$ <?php echo e($current_bal->total); ?></span>
          <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">
              <thead>

                <br>
                <br>
                <tr>
                  <th>#</th>
                  

                  <th><?php echo e(__('adminstaticword.Deposite')); ?></th>
                  <th><?php echo e(__('adminstaticword.Withdrawal')); ?></th>
                  <th><?php echo e(__('adminstaticword.Total')); ?></th>
                  <th><?php echo e(__('adminstaticword.Date')); ?></th>
                  

                </tr>
              </thead>
              <tbody>
              <?php $i=0;?>
              <?php $__currentLoopData = $wallet_infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wallet_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            

                <?php $i++;?>
                <tr>
                  <td><?php echo $i;?></td>
                  <td><?php echo e($wallet_info->credit_amount); ?></td>

                  <td>

                    <?php if($wallet_info->debit_amount == NULL): ?>
                      <?php echo e($wallet_info->debit_amount = '-'); ?>

                    <?php else: ?>
                      <?php echo e($wallet_info->debit_amount); ?>

                    <?php endif; ?>
                  </td>

                  
                  <td><?php echo e($wallet_info->total); ?></td>
                  <td><?php echo e($wallet_info->date); ?></td>



                  

                  

                  

                  

                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<script>
    $(document).ready(function(){

        $('#example1').dataTable( {
        "ordering": false
        } );

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('gamer/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/gamer/wallet/index.blade.php ENDPATH**/ ?>