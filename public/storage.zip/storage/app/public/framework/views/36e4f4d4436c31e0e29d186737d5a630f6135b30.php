
<?php $__env->startSection('title', 'Dashboard - Instructor'); ?>
<?php $__env->startSection('body'); ?>



 
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
 
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" />
 
<script src="https://cdn.jsdelivr.net/npm/moment@2.27.0/moment.min.js"></script>
 
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.js"></script>

<section class="content-header">
  <h1>
    <?php echo e(__('adminstaticword.Dashboard')); ?>

    <small><?php echo e(__('adminstaticword.Instructor')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo e(__('adminstaticword.Home')); ?></a></li>
    <li class="active"><?php echo e(__('adminstaticword.Dashboard')); ?></li>
  </ol>
</section>
<section class="content">
	<!-- Main row -->
  <body>
 
    <div class="container">
        <div class="response"></div>
        <div id='calendar'></div>  
    </div>
   
   
  </body>
  <!-- /.row -->


</section>


<script>
  
  var j = $.noConflict(true);

  j(document).ready(function () {
   var SITEURL = "<?php echo e(url('/')); ?>";
  j.ajaxSetup({
  headers: {
  'X-CSRF-TOKEN': j('meta[name="csrf-token"]').attr('content')
  }
  });
  var calendar = j('#calendar').fullCalendar({
  editable: false,
  events: '<?php echo e(route("fullcalendar.index")); ?>',
  displayEventTime: true,
  editable: false,
  eventRender: function (event, element, view) {
  if (event.allDay === 'true') {
  event.allDay = true;
  } else {
  event.allDay = true;
  }
  },
  selectable: false,
  selectHelper: true,
  
  });
  });
  function displayMessage(message) {
  j(".response").html("<div class='success'>"+message+"</div>");
  setInterval(function() { j(".success").fadeOut(); }, 1000);
  }
  </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('instructor.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/instructor/calendar/fullcalender.blade.php ENDPATH**/ ?>