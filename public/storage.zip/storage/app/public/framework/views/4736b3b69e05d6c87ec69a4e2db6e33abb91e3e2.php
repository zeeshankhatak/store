
<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('content'); ?>



<style>
 .invoice {
    max-width: 1920px;
    width: 100%;
    padding: 90px 115px;
    margin: 0 auto;
    position: relative;
}
/*.page-header {*/
/*    margin: 200px 0 20px 0;*/
/*    font-size: 22px;*/
/*}*/
header {
    position: relative;
    z-index:1;
}
.page-header small {
    color: #fff;
    font-size: 20px;
}
.page-header {
    margin-bottom: 20px;
}
.invoice .heading {
    color: #fff;
    font-weight: 700;
    font-size: 22px;
    margin-bottom: 20px;
}
.invoice .title {
    color: #fff;
    margin-top: 20px;
    font-size: 16px;
}
.invoice .invoice-info {
    background: #151E27;
    padding: 20px;
    border-radius: 10px;
    height: 100%;
}
.select-price {
    font-size: 16px;
    font-weight: 700;
    text-transform: uppercase;
    border: 1px solid #ffffff;
    color: #EE2737;
    background-color: #02010100;
    border-radius: 10px;
    display: inline-block;
    text-align: center;
    width: fit-content;
    margin-bottom: 20px;
}
.select-price select {
    background: #10161e;
    border: none;
    color: #ffffff;
    padding: 10px 0;
    width: 230px;
    font-weight: 700;
    border-radius: 10px;
    text-align: center;
}
.select-price select:focus {
    outline:0;
}
.invoice .invoice-info .invoice-col {
    border-right: 1px solid #ffffff29;
      
}
.invoice .invoice-info .invoice-col:first-child {
    padding-left:15px;
}
.invoice .invoice-info .invoice-col:last-child {
    border-right: 0;
}
@media (max-width: 991px) {
    .invoice .heading {
        margin-top: 20px;
    }
}
@media (max-width: 1500px) {
    .invoice .invoice-info .invoice-col {
        border-right: 1px solid #ffffff29;
        padding: 0 15px 0 15px;
    }
    .invoice .title {
        font-size: 14px;
    }
     .invoice {
        padding: 60px;
    }
}
@media (max-width: 600px) {
     .invoice {
        padding: 20px;
    }
}
</style>
<section class="content content_content">
    <section class="invoice">
        <!-- title row -->
        <div class="row mb-5">
            <div class="col-md-6">
                <h2 class="page-header">
                         <?php if(\Session::has('error')): ?>
                        <h6 class="alert alert-danger"><?php echo e(\Session::get('error')); ?></h6>
                        <?php echo e(\Session::forget('error')); ?>

                    <?php endif; ?>
                    <?php if(\Session::has('success')): ?>
                        <h6 class="alert alert-success"><?php echo e(\Session::get('success')); ?></h6>
                        <?php echo e(\Session::forget('success')); ?>

                    <?php endif; ?>
                    <h6 id="message-box"></h6>
                    <br>
                    <form class="form-inline">
                      <div class="form-group mb-2 mb-lg-0">
                         <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
                        <label for="" class="text-white">Enter Coupon Code</label>
                      </div>
                      <div class="form-group mx-sm-3 mb-2 mb-lg-0">
                        <input type="text" class="coupan form-control">
                      </div>
                      <button type="button" class="btn_apply btn btn-primary">Apply</button>
                    </form>
                  
                    <br>


                   
                    <small class="pull-right text-white">Date: <?php echo e($order->date); ?></small>
                </h2>
            </div><!-- /.col -->
            <div class="col-md-6 text-right">
                <button class="btn btn-primary" style="margin-right: 5px;"><i class="fa fa-download"></i><a href="<?php echo e(route('invoice.show')); ?>">Generate PDF</a></button>
            </div>
        </div>
        <!-- info row -->
        <h1 class="text-center mb-4">INVOICE  <span class="redColor">PREVIEW</span></h1>
        <div class="row">
            <div class="col-lg-8">
                <div class="invoice-info">
                    <div class="row">
                        <div class="col-lg-4 invoice-col">
                            <h2 class="heading mt-0 border-bottom pb-3 border-light">Coach Details</h2>
                            <?php $i=0;?>
                            <?php $__currentLoopData = $coach_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++;?>
                            <div>
                                <h4 class="heading mt-0">Coach <?php echo $i;?>:</h4>
                                <h4 class="title"><b>Name:</b> <?php echo e($coach->fname); ?> <?php echo e($coach->lname); ?></h4>
                                <h4 class="title"><b>Rank:</b>  <?php echo e($coach->coach_rank_id); ?></h4>
                                <h4 class="title"><b>K\D Ratio:</b> <?php echo e($coach->k_d_ratio); ?></h4>
                                <h4 class="title"><b>Win Rate:</b> <?php echo e($coach->win_rate); ?></h4>
                                <h4 class="title"><b>Email:</b> <?php echo e($coach->email); ?></h4><br>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><!-- /.col -->
                        <div class="col-lg-4 invoice-col">
                            <h2 class="heading mt-0 border-bottom pb-3 border-light">Gamer Details</h2>
                           <div>
                                <h4 class="title"><b>Name:</b> <?php echo e($gamer->fname); ?> <?php echo e($gamer->lname); ?></h4>
                                <h4 class="title"><b>Address:</b> <?php echo e($gamer->address); ?></h4>
                                <h4 class="title"><b>Phone:</b> <?php echo e($gamer->mobile); ?>  </h4>
                                <h4 class="title"><b>Email:</b> <?php echo e($gamer->email); ?></h4>
                            </div>
                        </div><!-- /.col -->
                        <div class="col-lg-4 invoice-col">
                           <h2 class="heading mt-0 border-bottom pb-3 border-light">Package Details</h2>
                           <div>
                               <?php if(session('game_id') == 1): ?>

                                <h4 class="title"><b>Game Name:</b> <?php echo e($game_name->name); ?></h4>
                                <h4 class="title"><b>Name:</b> <?php echo e(session('experience')); ?></h4>
                                <h4 class="title"><b>Gaming Hours:</b> <?php echo e(session('duration')); ?></h4>
                                <h4 class="title"><b>Total Coaches:</b> <?php echo e(session('total_coaches')); ?></h4>
                                <?php elseif(session('game_id') == 2): ?>

                                <h4 class="title"><b>Game Name:</b> <?php echo e($game_name->name); ?></h4>
                                <h4 class="title"><b>Coaching Experience:</b> <?php echo e(session('coachingExp')); ?></h4>
                                <h4 class="title"><b>Gaming Hours:</b> <?php echo e(session('duration') ? session('duration') : '-'); ?></h4>

                                   <h4 class="title"><b>Gaming Experience:</b> <?php echo e(session('experience') ? session('experience') : (session('packageGaming') ? session('packageGaming') : "-")); ?></h4>
                                       <h4 class="title"><b>Gaming Rank:</b> <?php echo e(session('rank') ? session('rank') : '-'); ?></h4>

                                <h4 class="title"><b>Total Coaches:</b> <?php echo e(session('total_coaches')); ?></h4>

                                  <?php elseif(session('game_id') == 3): ?>

                                <h4 class="title"><b>Game Name:</b> <?php echo e($game_name->name); ?></h4>
                                <h4 class="title"><b>Name:</b> <?php echo e(session('experience')); ?></h4>
                                <h4 class="title"><b>Gaming Hours:</b> <?php echo e(session('duration')); ?></h4>
                                <h4 class="title"><b>Total Coaches:</b> <?php echo e(session('total_coaches')); ?></h4>

                                <?php elseif(session('game_id') == 4): ?>

                                   <h4 class="title"><b>Game Name:</b> <?php echo e($game_name->name); ?></h4>
                                <h4 class="title"><b>Gaming Package:</b> <?php if(session('package') == 14): ?> 1 Game <?php elseif(session('package') == 40): ?> 3 Games <?php elseif(session('package') == 65): ?> 5 Games <?php elseif(session('package') == 128): ?> 10 Games <?php else: ?> error <?php endif; ?> </h4>
                                   <h4 class="title"><b>Gaming Experience:</b> <?php echo e(session('gexperience')); ?></h4>
                                       <h4 class="title"><b>Gaming Rank:</b> <?php echo e(session('rank') ? session('rank') : '-'); ?></h4>
                                <h4 class="title"><b>Total Coaches:</b> <?php echo e(session('total_coaches')); ?></h4>


                              <?php endif; ?>
                            </div>
                        </div><!-- /.col -->
                    </div>
                </div>
            </div>
             <div class="col-lg-4 mt-lg-0 mt-4">
                 <div class="invoice-info">
                     <h2 class="heading mb-2 mt-0 border-bottom pb-3 border-light">Order Recap</h2>
                     <div class="row">
                         <div class="col-6">
                             <h4 class="title">Order #</h4>
                             <?php if($order->pacakage_id != null): ?>
                             <h4 class="title">Package</h4>
                             <?php endif; ?>
                             <h4 class="title">Sub Total</h4>
                             <h4 class="title">Discount</h4>
                             <h4 class="title">Total</h4>
                         </div>
                         <div class="col-6 text-right">
                             <h4 class="title"><?php echo e($order->id); ?></h4>
                              <?php if($order->pacakage_id != null): ?>
                             <h4 class="title"><?php echo e($order->pacakage_id); ?></h4>
                             <?php endif; ?>
                             <h4 class="title">$<?php echo e($order->sub_total); ?></h4>
                             <h4 class="discount title">$0.00</h4>
                             <h4 class="total title">$<?php echo e($order->total); ?></h4>
                         </div>

                     </div>
                 </div>
            </div><!-- /.col -->
        </div><!-- /.row -->

        <!-- this row will not appear when printing -->
        <div class="row no-print">
            <div class="col-12 mt-4">
                
                <div class="d-inline-block">
                    <form action="<?php echo e(route('order.post')); ?>" method="get">

             <?php echo csrf_field(); ?>

                   <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>" />
                      <input type="hidden" name="package_id" value="<?php echo e($order->pacakage_id); ?>" />
                         <input type="hidden" id="order_total" name="order_total" value="<?php echo e($order->total); ?>" />
                         <input type="hidden" id="discount" name="discount" value="" />
                         <input type="hidden" id="coupan_id" name="coupan_id" value="" />

                            <button class="btn btn-success mr-2"><i class="fa fa-credit-card"></i> Submit Payment</button>

                </form>
                </div>

                
                



                <div class="checkout-btn d-inline-block mr-2">
                    <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#payment-modal">
                   ADD FUNDS
                </button>



                </div>

                  

            </div>
        </div>
    </section>
</section>



<!-- Modal -->
<div class="modal fade payment-modal" id="payment-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
     
      <div class="modal-body text-center">
          <div class="select-price">
            <select name="want_to_coach" id="amnt">
                <option value="" selected="true" disabled="disabled">Select Package</option>
                <option value="100">$100</option>
                <option value="300">$300</option>
                <option value="500">$500</option>
                <option value="1000">$1000</option>
            </select>
          </div>
          <div class="row">
              <div class="col-lg-6">
                  <div class="method-box">
                      <img src="<?php echo e(asset('gaming-assets/images/stripe.png')); ?>">
                       <p>Pay by using stripe</p>
                       
                      <form id="cart-form" method="post" action="<?php echo e(route('stripe.index')); ?>"
                        data-parsley-validate class="form-horizontal form-label-left">
                        <?php echo e(csrf_field()); ?>


                        <input type="hidden" name="order_id"  value="<?php echo e($order->id); ?>" />
                        <input type="hidden" name="user_id"  value="<?php echo e(Auth::User()->id); ?>" />
                        <input type="hidden" name="price_total"  value="<?php echo e($order->total); ?>" />
                        <input type="hidden" name="offer_total"  value="<?php echo e($order->sub_total); ?>" />
                        <input type="hidden" name="offer_percent"  value="<?php echo e(round($order->sub_total, 2)); ?>" />
                        <input type="hidden" name="cart_total"  value="" />
                        <input type="hidden" name="wallet_amount"  value="<?php echo e(session('status')); ?>" />

                        <button class="btn btn-primary" title="checkout" type="submit">Purchase with Stripe</button>
                    </form>

                  </div>

              </div>
              <div class="col-lg-6">
                  <div class="method-box">
                     <img src="<?php echo e(asset('gaming-assets/images/paypal.png')); ?>">
                     <p>Pay by using PayPal</p>
                     <form id="cart-form" method="get" action="<?php echo e(route('processTransaction')); ?>"
                        data-parsley-validate class="form-horizontal form-label-left">
                        <?php echo e(csrf_field()); ?>


                        <input type="hidden" name="order_id"  value="<?php echo e($order->id); ?>" />
                        <input type="hidden" name="user_id"  value="<?php echo e(Auth::User()->id); ?>" />
                        <input type="hidden" name="price_total"  value="<?php echo e($order->total); ?>" />
                        <input type="hidden" name="offer_total"  value="<?php echo e($order->sub_total); ?>" />
                        <input type="hidden" name="offer_percent"  value="<?php echo e(round($order->sub_total, 2)); ?>" />
                        <input type="hidden" name="cart_total"  value="" />
                        <input type="hidden" name="wallet_amount"  value="<?php echo e(session('status')); ?>" />

                       <button class="btn btn-primary" title="checkout" type="submit">Purchase with Paypal</button>
                    </form>
                </div>

              </div>
          </div>
      </div>

    </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script>

    var j = $.noConflict(true);
    
    

        j(document).ready(function(){
            
            j(".payment-modal #amnt").on("change",function(){ 
            j("input[name='cart_total']").val(j(this).val());
             });



            j(document).on('click','.btn_apply',function(){
            var cou = j(".coupan ").val();
            // var order_num = $(".order_id").val();

            console.log(cou);
            // console.log(order_num);

            j.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });



            j.ajax({
                type:'PUT',
                url:'<?php echo e(route("c.put")); ?>',
                data:{coupan:cou},
                dataType:'json',
                success:function(response){
                    console.log(response);
                    if(response.status == 200){
                        j("#message-box").html("");
                        j("#message-box").removeClass("alert alert-danger");
                        j("#message-box").addClass('alert alert-success');
                        j("#message-box").html("Coupan applied successfully!");
                        j("#message-box").fadeIn("slow");
                        setTimeout(function(){
                            j("#message-box").fadeOut("slow")
                        },3000);
                        j(".discount").html('$'+response.discount);
                        j(".total").html('$'+response.total+'.00');
                        j("#order_total").val(response.total+'.00');
                        j("#discount").val(response.discount);
                        j("#coupan_id").val(response.data.id);

                    }else{
                        j("#message-box").html("");
                        j("#message-box").removeClass('alert alert-success');
                        j("#message-box").addClass('alert alert-danger');
                        j("#message-box").html(response.message);
                        j("#message-box").fadeIn("slow");
                        setTimeout(function(){
                            j("#message-box").fadeOut("slow")
                        },3000);

                    }
                }
            });
        });

    });
    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/front/invoice.blade.php ENDPATH**/ ?>