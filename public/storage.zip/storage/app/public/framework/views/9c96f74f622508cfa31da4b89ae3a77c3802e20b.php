
<?php $__env->startSection('title', 'Call Of Duty'); ?>
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- body start gaming portal -->
<body class="gamePg cod">
    
     <?php if(session('status')): ?>
    <div class="alert alert-danger"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    
    <div class="coachBanner" style="background: url(<?php echo e(asset('gaming-assets/images/COD-banner.jpg')); ?>) no-repeat top center;"></div>

<section class="gaming-sec">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
          <p class="main">Coaches work closely with the players to identify their strengths and weaknesses, motivate them, and make sure they are playing at their best. </p>

          
          <form method="get" class="codForm" id="call-of-duty">
              <?php echo csrf_field(); ?>
             <ul class="game-selection tabs cod-tab">

                <input type="hidden" name="pkg_id" value="" >
                <input type="hidden" name="game_id" value="1" >
                <input type="hidden" name="currency" value="2" >

                <?php if($errors->has('experience')): ?>
                <?php echo e($errors->first('experience')); ?>

                <?php endif; ?>

               


              <li class="current" data-tab="tab1"><span>1. CHOOSE YOUR GAMING EXPERIENCE<i class="icon-keyboard_arrow_down"></i> <span class="experienceid selectedValue"></span></span>

                <div class="drop-down gaming-exp tab-content" id="tab1">
                    <div class="item">
                      <input type="radio" id="e1" value="FOCUS ON COACHING" name="experience" />
                        <label for="e1">
                          <h2>FOCUS ON COACHING</h2>
                          <p>- Improve stats</p>
                          <p>- Learn the best tips and tricks</p>
                          <p>- Teach you the best loadouts and weapon mods</p>
                        </label>
                    </div>
                    <div class="item">
                      <input type="radio" id="e2" value="CASUAL GAMES" name="experience"/>
                        <label for="e2">
                          <h2>CASUAL GAMES</h2>
                          <p>- Looking for a good time</p>
                          <p>- Enjoy skilled teammates</p>
                          <p>- Great vibes</p>
                        </label>
                    </div>
                     <div class="item">
                      <input type="radio" id="e3" value="VIDEO REVIEWS" name="experience"/>
                        <label for="e3">
                          <h2>VIDEO REVIEWS</h2>
                          <p>Allow our coaches to rewatch film of your gameplay and analyze how to make better decisions.</p>
                        </label>
                    </div>
                </div>
              </li>

                <li data-tab="tab2"><span>2. HOW MANY HOURS DO YOU WANT TO PLAY?<i class="icon-keyboard_arrow_down"></i>  <span class="durationid selectedValue"></span></span>
                  <div class="drop-down gaming-duration  tab-content" id="tab2">
                      <div class="item">
                        <input type="radio" id="d1" value="1" name="duration"/>
                        <label for="d1">1 HOUR</label>
                      </div>
                      <div class="item">
                        <input type="radio" id="d2" value="2" name="duration">
                        <label for="d2">2 HOURS</label>
                      </div>
                       <div class="item">
                        <input type="radio" id="d3" value="3" name="duration">
                        <label for="d3">3 HOURS</label>
                      </div>
                  </div>
                </li>

                <li><span>3. CHOOSE YOUR COACH(ES) </span>
                  <div class="drop-down choose-coach">
                      <div class="radio-buttons">
                        <input type="radio" name="chooseCoach" value="1" id="btn1"/>
                        <label for="btn1"><span class="number">1</span> Coach</label>
                        <input type="radio" name="chooseCoach" value="2" id="btn2" checked class="checked" />
                        <label for="btn2"><span class="number">2</span> Coaches</label>
                      </div>
                      <div class="buttons-grp">
                        <input type="button" name="coachbtn" class="coachbtn btn1" placeholder="CHOOSE A COACH" value="CHOOSE A COACH"/>
                        <input type="button" name="coachbtn" class="coachbtn btn2" placeholder="CHOOSE A COACH" value="CHOOSE A COACH" />
                        <input type="submit" id="btn_submit" value="SUBMIT MY SESSION" />
                      </div>
                  </div>
                </li>
                <h6 id="message-box"></h6>
             </ul>

             <div id="listOfChoach" class="coach-list-wrapper">
                <?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="coach-list">
                <div class="img"><img src="<?php echo e(asset('gaming-assets/images/cropped-69495847_l.jpg')); ?>"></div>

                <div class="text"><h2><?php echo e($instructor->fname); ?> <?php echo e($instructor->lname); ?></h2></div>

                <ul class="profile">
                  <li><div class="left"><h2>Languages</h2></div>
                   <div class="right"> <p><?php echo e($instructor->language); ?></p></div>
                 </li>
                  <li><div class="left"><h2>Play on</h2></div>
                    <div class="right"><p>Controller</p>
                    </li>
                  <li><div class="left"><h2>K/D</h2></div>
                    <div class="right"><p><?php echo e($instructor->k_d_ratio); ?></p></div>
                  </li>
                  <li><div class="left"><h2>Total Wins</h2></div>
                    <div class="right"><p><?php echo e($instructor->win_rate); ?></p></div>
                  </li>
                  <li><div class="left"><h2 class="charges"><sup>$</sup><?php echo e($instructor->rate); ?> /<span>per hour</br> for this Pro</span></h2></div>
                    <div class="right"><div class="chat"><a href="">CHAT WITH THIS PRO</a></div></div>
                    </li>
                </ul>
                <!--<div class="form-check">-->
                    

                <!--  </div>-->
                <div class="btn play-btn"><a href=""><input class="form-check-input" type="checkbox" name="coach_id[]" data-coach-rate="<?php echo e($instructor->rate); ?>" value="<?php echo e($instructor->coach_id); ?>" id="flexCheckDefault">PLAY WITH THIS COACH</a></div>
              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
                                  <input type="hidden" name="coach_rate" id="hidden_rate" value="" />
              
              
             </div>
           </form>

      </div>
    </div>
  </div>
</section>
<?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>


<!-- body end gaming portal -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-script'); ?>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>



<script>

var j = $.noConflict(true);

console.log(j().jquery);


j(document).ready(function(){

    // console.log('check');
    
    
    $('input:checkbox').change(function ()
{

      var total = '';
      $('input:checkbox:checked').each(function(){
       total += parseInt($(this).attr('data-coach-rate')) + ",";
      });   
  
      $("#hidden_rate").val(total);

});

//return false;
    
     j(":checkbox").each(function () {
    
        var ischecked = j(this).is(":checked");
        var israte  = j(this).attr('data-coach-rate');
    
        if (ischecked) {
        
        j('#rate').val(j(this).attr('data-coach-rate'));
        
            checkbox_value += j(this).val();
            
          //    console.log(checkbox_value);
             
           //    console.log(israte);
        
            
        }

    });


    j('#call-of-duty').submit(function(e){

        e.preventDefault();


       // console.log('check');

         var checkbox_value = "";
        
   

                let formData = j('#call-of-duty').serialize();
                console.log(formData);
                
                
                //return false;

                j.ajax({
                    type:'GET',
                    url:'<?php echo e(route('callofduty.post')); ?>',
                    data:formData,
                    dataType: 'json',
                    success:function(response){
                        console.log(response);
                        if(response.status == 200){

                            window.open("<?php echo e(route('callofduty.insert')); ?>", "_self");
                            console.log(response.message);
                        }
                         else{
                            j("#message-box").html("");
                            j("#message-box").removeClass('alert alert-success');
                            j("#message-box").addClass('alert alert-danger');
                            j("#message-box").html(response.message);
                            j("#message-box").fadeIn("slow");
                            setTimeout(function(){
                                j("#message-box").fadeOut("slow")
                            },3000);
                        }

                    },
                    error: function(response){
                            console.log(response.responseJSON['errors']);
                             j.each(response.responseJSON['errors'], function(i, user){
                            //do something
                            //console.log(i);
                            alert(user[0]);
                            });
                                            }
                });
            });


 });



</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/call-of-duty.blade.php ENDPATH**/ ?>