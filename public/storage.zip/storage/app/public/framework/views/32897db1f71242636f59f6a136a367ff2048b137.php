<?php $__env->startSection('title', 'Call Of Duty'); ?>
<?php $__env->startSection('content'); ?>
<!-- body start gaming portal -->
<body class="thankyouPg">
    <?php if(session()->has('success')): ?>
        <div class="thankyou">
            <div class="container">
                <h1 class="">THANK <br><span class="redColor">YOU</span></h1>
                <p><?php echo e(session()->get('success')); ?></p>
            </div>
        </div>
    <?php endif; ?>
<?php echo $__env->make('theme.join-community', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>



<!-- body end gaming portal -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('theme.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/thankyou.blade.php ENDPATH**/ ?>