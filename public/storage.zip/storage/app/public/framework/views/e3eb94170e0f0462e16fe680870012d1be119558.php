
<?php $__env->startSection('title', 'All Order - Admin'); ?>
<?php $__env->startSection('body'); ?>

<section class="content">
  <?php echo $__env->make('gamer.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <!-- Order Details Modal -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<div class="modal fade" id="Order_Details" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
           <button type="button" class="d_close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        <div class="modal-body">
            <input type="text" class="order_id form-control">
          <table id="details" class="table table-bodered table-striped">
            <thead>
                <tr>
                    <th>Coach Name</th>
                    <th>Assign Date | Time</th>
                    <th>Coach Status</th>
                    <th>Tip a Coach</th>
                </tr>
            </thead>
            <tbody>

            </tbody>
        </table>
        </div>
      
      </div>
    </div>
  </div>
  <!-- End Order Details Modal -->


   <!-- Coach Profile Modal -->
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <div class="modal fade" id="Coach_Profile" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
       <div class="modal-dialog modal-sm">
         <div class="modal-content">
              <button type="button" class="cp_close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
         
           <div class="modal-body">
              <div class="coach-image">
                <img class="coach_img img-circle" alt="User Image">
              </div>
               <input type="text" class="coach_id form-control">
               <div class="coach-detail">
                   <p class="c_name"></p>
                   <p class="c_email"></p>
                   <p class="k_d_ratio"></p>
                   <p class="win_rate"></p>
               </div>

             <!--<div class="form group-mb3">-->
             <!--    <label for="">Coach Name</label>-->
             <!--    -->
             <!--    <p class="c_name form-control"></p>-->
             <!--</div>-->
             <!--<div class="form group-mb3">-->
             <!--    <label for="">Email</label>-->
             <!--    -->
             <!--    <p class="c_email form-control"></p>-->
             <!--</div>-->
             <!--<div class="form group-mb3">-->
             <!--    <label for="">Kill to Death Ratio</label>-->
             <!--    -->
             <!--    <p class="k_d_ratio form-control"></p>-->
             <!--</div>-->
             <!--<div class="form group-mb3">-->
             <!--    <label for="">Win Rate</label>-->
             <!--    -->
             <!--    <p class="win_rate form-control"></p>-->
             <!--</div>-->
           </div>
         </div>
       </div>
     </div>
     <!-- Coach Profile Modal -->
     
      <!-- Tip a Coach Modal -->
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <div class="modal fade" id="Tip_a_coach" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tip a Coach</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">

            <input type="text" class="coach_id form-control">

            <div class="form group-mb3">
                <label for="">Amount</label>
                <input type="number" class="amount form-control" required>
            </div>

            <div class="form group-mb3">
                <label for="">Discription</label>
                <textarea class="discription form-control" required></textarea>
                
            </div>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn_submit btn btn-primary">Submit</button>
          </div>
        </div>
      </div>
    </div>
    <!-- Tip a Coach Modal End -->
    
     
  <div class="row">
      <div id="message-box"></div>
    <div class="col-xs-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"> <?php echo e(__('adminstaticword.Order')); ?></h3>
        </div>

        <!-- /.box-header -->
        <div class="box-body">
          <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">
              <thead>

                <br>
                <br>
                <tr>

                  <th><?php echo e(__('adminstaticword.Order #')); ?></th>
                  
                  
                  <th><?php echo e(__('adminstaticword.Game')); ?></th>
                  <th><?php echo e(__('adminstaticword.No.of Coaches')); ?></th>
                  
                  <th><?php echo e(__('adminstaticword.PackageAmount')); ?></th>
                  
                  <th><?php echo e(__('adminstaticword.Payment Status')); ?></th>
                  <th><?php echo e(__('adminstaticword.Order Status')); ?></th>
                  <th><?php echo e(__('adminstaticword.Details')); ?></th>

                </tr>
              </thead>
              <tbody>
              <?php $i=0;?>
              <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            

                
                <tr>
                  
                  <td><?php echo e($order_detail->order_id); ?></td>
                  

                  

                  
                  <td><?php echo e($order_detail->game_name); ?></td>
                  <td><?php echo e($order_detail->coaches); ?></td>

                  

                  

                  
                  <td>$<?php echo e($order_detail->total_amount); ?></td>


                  

                  

                  <td>


                      <span  class=" <?php echo e($order_detail->order_status ==1 ? 'badge badge-success' : 'badge badge-danger'); ?>">
                        <?php if($order_detail->order_status ==1): ?>
                          <?php echo e(__('adminstaticword.Paid')); ?>

                        <?php else: ?>
                          <?php echo e(__('adminstaticword.Unpaid')); ?>

                        <?php endif; ?>
                      </span>

                  </td>



                  <td>


                    <span  type="Submit" class="btn btn-xs <?php echo e($order_detail->coach_status ==1 ? 'btn-success' : 'btn-danger'); ?>">
                      <?php if($order_detail->coaching_status ==1): ?>
                        <?php echo e(__('adminstaticword.Accepted')); ?>

                      <?php else: ?>
                        <?php echo e(__('adminstaticword.Pending by Coach')); ?>

                      <?php endif; ?>
                    </span>

                </td>
                
                 <td>

                    <button value="<?php echo e($order_detail->order_id); ?>" class="details btn btn-xs btn-primary">
                     Show
                    </button>
                
                </td>



                  

                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<script>
    $(document).ready(function(){

        $('#example1').dataTable( {
        "ordering": false
        } );

       $(document).on('click','.details',function(e){
            e.preventDefault();
            var order_num = $(this).val();
            // console.log(order_num);
            $("#Order_Details").modal('show');
            $(".order_id").val(order_num);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type:'GET',
                url:'gamer/gamerdatafetch/'+order_num,
                dataType:'json',
                success:function(response){
                    // console.log(response);

                    $("#details tbody").html("");
                    $.each(response.data,function(key,value){
                        var orderStatus='';
                        if(value.coach_status==1){
                            coachStatusClass='badge badge-success';
                            coachStatus = "Accepted";
                            }
                            else{
                                coachStatusClass='badge badge-danger';
                                coachStatus = "Pending";
                            }

                        if(value.assign_date == null){
                            assignDate = "-";
                            }
                            else{
                                assignDate = value.assign_date;
                            }
                        $('#details tbody').append(
                            '<tr>\
                                <td><button value="'+value.coach_id+'" class="coach_profile  btn btn-link">'+value.fname+' '+value.lname+'</button></td>\
                                <td>'+assignDate+'</td>\
                                <td><span value="'+value.coach_status+'" class=" '+ coachStatusClass +' ">'+coachStatus+'</span></td>\
                                <td><button value="'+value.coach_id+'" class="btn btn-primary tip-coach">Tip a Coach</button></td>\
                            </tr>'
                        );
                    });

                }
            });

        });
        
        // ----------- 2nd Modal (Coach Profile) --------------
        $(document).on('click','.coach_profile',function(e){
            e.preventDefault();
            var coachId = $(this).val();
            // console.log(coachId);
            $("#Coach_Profile").modal('show');
            $(".coach_id").val(coachId);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type:'GET',
                url:'gamer/coachd_details_fetch/'+coachId,
                dataType:'json',
                success:function(response){
                    // console.log(response);
                    $(".c_name").html(response.data.fname+" "+response.data.lname);
                    $(".c_email").html(response.data.email);
                    $(".k_d_ratio").html(response.data.k_d_ratio);
                    $(".win_rate").html(response.data.win_rate);
                    $(".pp").html(response.data.win_rate);
                    
                    var image = response.data.user_img;
                    var source = "<?php echo e(asset('/images/coach')); ?>"+"/"+image;
                    $('.coach_img').attr('src', source);

                }
            });

        });
        
          // ----------- Tip a Coach Modal --------------
         $(document).on('click','.tip-coach',function(e){
            e.preventDefault();
            var coachId = $(this).val();

            $("#Tip_a_coach").modal('show');
            $(".coach_id").val(coachId);

        });

        $(document).on('click','.btn_submit',function(e){
            e.preventDefault();
            var data = {
                'coach_id':$('.coach_id').val(),
                'amount':$('.amount').val(),
                'description':$('.discription').val(),
            }
            console.log(data);

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type:"POST",
                url:"gamer/tip_a_coach",
                data:data,
                dataType:"json",
                success:function(response){
                    console.log(response);
                    if(response.status == 200){
                        $("#Tip_a_coach").modal('hide');
                        $("#Order_Details").modal('hide');
                        $("#message-box").html("");
                        $("#message-box").removeClass('alert alert-danger');
                        $("#message-box").addClass('alert alert-success');
                        $("#message-box").html(response.message);
                        $("#message-box").fadeIn("slow");
                        setTimeout(function(){
                            $("#message-box").fadeOut("slow")
                        },3000);
                        $("#Tip_a_coach").find("input").val("");
                        $("#Tip_a_coach").find("textarea").val("");
                    }
                    else{
                        $("#Tip_a_coach").modal('hide');
                        $("#Order_Details").modal('hide');
                        $("#message-box").html("");
                        $("#message-box").removeClass('alert alert-success');
                        $("#message-box").addClass('alert alert-danger');
                        $("#message-box").html(response.message);
                        $("#message-box").fadeIn("slow");
                        setTimeout(function(){
                            $("#message-box").fadeOut("slow")
                        },3000);
                        $("#Tip_a_coach").find("input").val("");
                        $("#Tip_a_coach").find("textarea").val("");
                    }

                }
            });

        });
        
         $(".cp_close").click(function(){
            $("#Coach_Profile").modal('hide');
        });
        
         $(".d_close").click(function(){
            $("#Order_Details").modal('hide');
        });

    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('gamer/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/gamer/order/index.blade.php ENDPATH**/ ?>