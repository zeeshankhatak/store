<title><?php echo $__env->yieldContent('title'); ?> - Gaming</title>


<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- CSS -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">



<!-- Gaming portal css Start-->
<link rel="stylesheet" href="<?php echo e(asset('gaming-assets/css/m-style.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('gaming-assets/css/style.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('gaming-assets/css/fonts/style.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('gaming-assets/css/responsive.css')); ?>"/>
 <!-- Gaming portal css End-->

<?php /**PATH /home/centauruscrm/fps.centauruscrm.com/resources/views/theme/Gamingportal-head.blade.php ENDPATH**/ ?>