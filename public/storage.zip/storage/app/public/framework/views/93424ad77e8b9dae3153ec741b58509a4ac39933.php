<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
          <a href="<?php echo e(url('/')); ?>" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini">
            <img class="biglogo" src="<?php echo e(asset('gaming-assets/images/OPMfg.png')); ?>" alt=""/>
            <img class="smalllogo" src="<?php echo e(asset('gaming-assets/images/iconlogo.png')); ?>" alt=""/>
          </span>
          <!-- logo for regular state and mobile devices -->
          
        </a>
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <?php if(Auth::User()->user_img != null || Auth::User()->user_img != ''): ?>
                    <img src="<?php echo e(asset('images/admin/' . Auth::User()->user_img)); ?>" class="img-circle"
                        alt="User Image">

                <?php else: ?>
                    <img src="<?php echo e(asset('images/default/user.jpg')); ?>" class="img-circle" alt="User Image">

                <?php endif; ?>
            </div>
            <div class="pull-left info">
                <p><?php echo e(Auth::User()->fname); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e(__('adminstaticword.Online')); ?></a>
            </div>
        </div>


        <ul class="sidebar-menu" data-widget="tree">
            <li class="header"><?php echo e(__('adminstaticword.Navigation')); ?></li>

            <li class="<?php echo e(Route::is('admin.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('admin.index')); ?>"><i
                        class="fa fa-tachometer"
                        aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Dashboard')); ?></span></a></li>
    
            <?php if(auth()->user()->role->permission['capabilities']['gamer']['view'] == 1): ?>
                <li
                    class="<?php echo e(Route::is('user.index') ? 'active' : ''); ?> <?php echo e(Route::is('user.add') ? 'active' : ''); ?> <?php echo e(Route::is('user.edit') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('user.index')); ?>"><i class="fa fa-user-o"
                            aria-hidden="true"></i><span>Gamers</span></a>
                </li>
            <?php endif; ?>



            <?php if(auth()->user()->role->permission['capabilities']['coach']['view'] == 1): ?>
            
             <li class="<?php echo e(Route::is('all.instructor') ? 'active' : ''); ?>"><a
                                href="<?php echo e(route('all.instructor')); ?>"><i
                                    class="fa fa-circle-o"></i>Coaches</a></li>
              
            <?php endif; ?>


        

     
            <?php if(auth()->user()->role->permission['capabilities']['order']['view'] == 1): ?>
                <li class="<?php echo e(Route::is('order.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('order.index')); ?>"><i
                            class="fa fa-history"
                            aria-hidden="true"></i><span>Orders</span></a></li>
            <?php endif; ?>
          
     
          <li class="treeview">
            <a href="#">
              <i class="fa fa-cogs" aria-hidden="true"></i> <span>Settings</span>
              <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
     
            <?php if(auth()->user()->role->permission['capabilities']['role']['view'] == 1): ?>
            
              <li class="<?php echo e(Route::is('roles.index')); ?>"><a href="<?php echo e(route('roles.index')); ?>"><i
                                class="fa fa-circle-o"></i><span>Roles</span></a></li>
                                
           <?php endif; ?>

    <?php if(auth()->user()->role->permission['capabilities']['staff']['view'] == 1): ?>
                    <li class="<?php echo e(Route::is('staff.index')); ?>"><a href="<?php echo e(route('staff.index')); ?>"><i
                                class="fa fa-circle-o"></i><span>Staffs</span></a></li>
                                 <?php endif; ?>
            </ul>
          </li>
     
            
         


        </ul>
        


    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH /home/centauruscrm/fps.centauruscrm.com/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>