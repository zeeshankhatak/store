<?php $__env->startSection('body'); ?>
<?php $__env->startSection('title', 'ADD User - Admin'); ?>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<section class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"> <?php echo e(__('adminstaticword.Add')); ?> <?php echo e(__('adminstaticword.Users')); ?>

                    </h3>
                </div>
                <div class="panel-body">
                    <form action="<?php echo e(route('roles.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                        <div class="row">
                            <div class="col-md-6 col-6">
                                <label for="fname">
                                    <?php echo e(__('adminstaticword.FirstName')); ?>:<sup class="redstar">*</sup>
                                </label>
                                <input value="<?php echo e(old('name')); ?>" autofocus required name="name" type="text"
                                    class="form-control" placeholder="Enter your role name" />
                            </div>

                        </div>
                        <br>

                        <div class="row">
                            <div class="col-md-6">
                                <label for="mobile">Features: <sup class="redstar">*</sup></label>
                                <table class="table table-bordered roles no-margin">
                                    <thead>
                                        <tr>
                                            <th>Feature</th>
                                            <th>Capabilities</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                <b>Gamer</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                    <input type="hidden" class="capability"
                                                        name="permission[gamer][view]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-view"
                                                        name="permission[gamer][view]" value="1">
                                                                                                            
                                                    <label for="gamer-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                         <input type="hidden" class="capability" 
                                                        name="permission[gamer][create]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-create"
                                                        name="permission[gamer][create]" value="1">
                                                   
                                                    <label for="gamer-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox">
                                                    <input type="hidden" class="capability"
                                                        name="permission[gamer][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-edit"
                                                        name="permission[gamer][edit]" value="1">
                                                    <label for="gamer-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">
                                                    <input type="hidden" class="capability" 
                                                        name="permission[gamer][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="gamer-delete"
                                                        name="permission[gamer][delete]" value="1">
                                                    <label for="gamer-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <b>Coach</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                     <input type="hidden" class="capability"
                                                        name="permission[coach][view]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-view"
                                                        name="permission[coach][view]" value="1">
                                                    <label for="coach-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                      <input type="hidden" class="capability"
                                                        name="permission[coach][create]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-create"
                                                        name="permission[coach][create]" value="1">
                                                    <label for="coach-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox"><input type="hidden" class="capability"
                                                        name="permission[coach][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-edit"
                                                        name="permission[coach][edit]" value="1">
                                                    <label for="coach-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">
                                                    <input type="hidden" class="capability"
                                                        name="permission[coach][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="coach-delete"
                                                        name="permission[coach][delete]" value="1">
                                                    <label for="coach-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <b>Order</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                    <input type="hidden" class="capability"
                                                        name="permission[order][view]" value="0">
                                                    <input type="checkbox" class="capability" id="order-view"
                                                        name="permission[order][view]" value="1">
                                                    <label for="order-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[order][create]" value="0">
                                                    <input type="checkbox" class="capability" id="order-create"
                                                        name="permission[order][create]" value="1">
                                                    <label for="order-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[order][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="order-edit"
                                                        name="permission[order][edit]" value="1">
                                                    <label for="order-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">
                                                    <input type="hidden" class="capability"
                                                        name="permission[order][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="order-delete"
                                                        name="permission[order][delete]" value="1">
                                                    <label for="order-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <b>Role</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[role][view]" value="0">
                                                    <input type="checkbox" class="capability" id="role-view"
                                                        name="permission[role][view]" value="1">
                                                    <label for="role-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[role][create]" value="0">
                                                    <input type="checkbox" class="capability" id="role-create"
                                                        name="permission[role][create]" value="1">
                                                    <label for="role-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[role][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="role-edit"
                                                        name="permission[role][edit]" value="1">
                                                    <label for="role-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[role][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="role-delete"
                                                        name="permission[role][delete]" value="1">
                                                    <label for="role-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                        <tr>
                                            <td>
                                                <b>Staff</b>
                                            </td>
                                            <td>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[staff][view]" value="0">
                                                    <input type="checkbox" class="capability" id="staff-view"
                                                        name="permission[staff][view]" value="1">
                                                    <label for="staff-view">
                                                        View </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[staff][create]" value="0">
                                                    <input type="checkbox" class="capability" id="staff-create"
                                                        name="permission[staff][create]" value="1">
                                                    <label for="staff-create">
                                                        Create </label>
                                                </div>
                                                <div class="checkbox">
                                                       <input type="hidden" class="capability"
                                                        name="permission[staff][edit]" value="0">
                                                    <input type="checkbox" class="capability" id="staff-edit"
                                                        name="permission[staff][edit]" value="1">
                                                    <label for="staff-edit">
                                                        Edit </label>
                                                </div>
                                                <div class="checkbox">   <input type="hidden" class="capability"
                                                        name="permission[staff][delete]" value="0">
                                                    <input type="checkbox" class="capability" id="staff-delete"
                                                        name="permission[staff][delete]" value="1">
                                                    <label for="staff-delete">
                                                        Delete </label>
                                                </div>

                                            </td>

                                        </tr>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                        <br>
                        <br>


                        <div class="box-footer">
                            <button type="submit" class="btn btn-md btn-primary">
                                <i class="fa fa-plus-circle"></i> <?php echo e(__('adminstaticword.AddUser')); ?>

                            </button>
                    </form>
                    <a href="<?php echo e(route('roles.index')); ?>" title="Cancel and go back"
                        class="btn btn-md btn-default btn-flat">
                        <i class="fa fa-reply"></i> <?php echo e(__('adminstaticword.Back')); ?>

                    </a>
                </div>
                <br>


            </div>
            <!-- /.panel body -->
        </div>
        <!-- /.box -->
    </div>
    <!-- /.col -->
    </div>
    <!-- /.row -->
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<script>
    (function($) {
        "use strict";

        $('#married_status').change(function() {

            if ($(this).val() == 'Married') {
                $('#doaboxxx').show();
            } else {
                $('#doaboxxx').hide();
            }
        });

        $(function() {
            $("#dob,#doa").datepicker({
                changeYear: true,
                yearRange: "-100:+0",
                dateFormat: 'yy/mm/dd',
            });
        });

        tinymce.init({
            selector: 'textarea#detail'
        });

        $(function() {
            var urlLike = '<?php echo e(url('country/dropdown')); ?>';
            $('#country_id').change(function() {
                var up = $('#upload_id').empty();
                var cat_id = $(this).val();
                if (cat_id) {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: "GET",
                        url: urlLike,
                        data: {
                            catId: cat_id
                        },
                        success: function(data) {
                            console.log(data);
                            up.append('<option value="0">Please Choose</option>');
                            $.each(data, function(id, title) {
                                up.append($('<option>', {
                                    value: id,
                                    text: title
                                }));
                            });
                        },
                        error: function(XMLHttpRequest, textStatus, errorThrown) {
                            console.log(XMLHttpRequest);
                        }
                    });
                }
            });
        });

        $(function() {
            var urlLike = '<?php echo e(url('country/gcity')); ?>';
            $('#upload_id').change(function() {
                var up = $('#grand').empty();
                var cat_id = $(this).val();
                if (cat_id) {
                    $.ajax({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        type: "GET",
                        url: urlLike,
                        data: {
                            catId: cat_id
                        },
                        success: function(data) {
                            console.log(data);
                            up.append('<option value="0">Please Choose</option>');
                            $.each(data, function(id, title) {
                                up.append($('<option>', {
                                    value: id,
                                    text: title
                                }));
                            });
                        },
                        error: function(XMLHttpRequest, textStatus, errorThrown) {
                            console.log(XMLHttpRequest);
                        }
                    });
                }
            });
        });
    })(jQuery);
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/centauruscrm/fps.centauruscrm.com/resources/views/admin/roles/adduser.blade.php ENDPATH**/ ?>