<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
          <a href="<?php echo e(url('/')); ?>" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini">
            <img class="biglogo" src="<?php echo e(asset('gaming-assets/images/OPMfg.png')); ?>" alt=""/>
            <img class="smalllogo" src="<?php echo e(asset('gaming-assets/images/iconlogo.png')); ?>" alt=""/>
          </span>
          <!-- logo for regular state and mobile devices -->
          
        </a>
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <?php if(Auth::User()->user_img != null || Auth::User()->user_img !=''): ?>
          <img src="<?php echo e(asset('images/gamer/'.Auth::User()->user_img)); ?>" class="img-circle" alt="User Image">

          <?php else: ?>
          <img src="<?php echo e(asset('images/default/user.jpg')); ?>" class="img-circle" alt="User Image">

          <?php endif; ?>
        </div>
        <div class="pull-left info">
          <p><?php echo e(Auth::User()->fname); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> <?php echo e(__('adminstaticword.Online')); ?></a>
        </div>
      </div>
 

      
        <ul class="sidebar-menu" data-widget="tree">
       
         

         

          <li class="<?php echo e(Route::is('gamer.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('gamer.index')); ?>"><i class="fa  fa-history" aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Order')); ?></span></a></li>

         <li class="<?php echo e(Route::is('gamer.wallet') ? 'active' : ''); ?>"><a href="<?php echo e(route('gamer.wallet')); ?>"><i class="fa  fa-history" aria-hidden="true"></i><span><?php echo e(__('adminstaticword.Wallet')); ?></span></a></li>

          



        </ul>
      


    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH /home/aquaclients/smtp.aquaclients.com/resources/views/gamer/layouts/sidebar.blade.php ENDPATH**/ ?>