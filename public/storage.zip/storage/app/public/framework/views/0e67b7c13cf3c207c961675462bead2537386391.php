
<?php $__env->startSection('title', 'All Instructor - Admin'); ?>
<?php $__env->startSection('body'); ?>

<section class="content">
  <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="row">
    <div class="col-xs-12">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"><?php echo e(__('adminstaticword.AllInstructor')); ?></h3>
        </div>
          <div class="box-header">

                        <?php if(auth()->user()->role->permission['capabilities']['coach']['create']==1): ?>
                            <a class="btn btn-info btn-sm" href="<?php echo e(route('coach.add')); ?>">+ <?php echo e(__('adminstaticword.Add')); ?>

                                Coach</a>
                        <?php endif; ?>

                    </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">

              <thead>
                <br>
                <br>
                <tr>
                	<th><?php echo e(__('adminstaticword.Image')); ?></th>
                  <th><?php echo e(__('adminstaticword.Name')); ?></th>
                  <th><?php echo e(__('adminstaticword.Email')); ?></th>
                  <th><?php echo e(__('adminstaticword.Game')); ?></th>
                  <th><?php echo e(__('adminstaticword.Rank')); ?></th>
                  <th><?php echo e(__('adminstaticword.K\D Ratio')); ?></th>
                  <th><?php echo e(__('adminstaticword.Win-Rate')); ?></th>
                  <th><?php echo e(__('adminstaticword.mobile')); ?></th>
                  <?php if(auth()->user()->role->permission['capabilities']['coach']['edit']==1): ?>
                  <th><?php echo e(__('adminstaticword.Status')); ?></th>
                   <?php endif; ?>
                  <?php if(auth()->user()->role->permission['capabilities']['coach']['edit']==1): ?>
                  <th><?php echo e(__('adminstaticword.Edit')); ?></th>
                  <?php endif; ?>
                  <?php if(auth()->user()->role->permission['capabilities']['coach']['delete']==1): ?>
                  <th><?php echo e(__('adminstaticword.Delete')); ?></th>
                  <?php endif; ?>
                </tr>
              </thead>
              
              
              <tbody>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                  <td><img src="<?php echo e(asset('images/coach/'.$item->user_img)); ?>" class="img-responsive"></td>
                  <td><a href="<?php echo e(route('coach.tab.wallet', $item->user_tbl_id)); ?>"><?php echo e($item->fname); ?> <?php echo e($item->lname); ?></a></td>
                  <td><?php echo e($item->email); ?></td>
                  <td><?php echo e($item->game_id); ?></td>
                  <td><?php echo e($item->coach_rank_id); ?></td>
                  <td><?php echo e($item->k_d_ratio); ?></td>
                  <td><?php echo e($item->win_rate); ?></td>
                  <td><?php echo e($item->mobile); ?></td>
                  
                   <?php if(auth()->user()->role->permission['capabilities']['coach']['edit']==1): ?>
                  <td>
                    <form action="<?php echo e(route('coach.quick',$item->user_tbl_id)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <button type="Submit" class="btn btn-xs <?php echo e($item->status == 1 ? 'btn-success' : 'btn-danger'); ?>">
                          <?php if($item->status == 1): ?>
                          <?php echo e(__('adminstaticword.Active')); ?>

                          <?php else: ?>
                          <?php echo e(__('adminstaticword.Deactive')); ?>

                          <?php endif; ?>
                        </button>
                      </form>
                  </td>
                  <?php endif; ?>
                   <?php if(auth()->user()->role->permission['capabilities']['coach']['edit']==1): ?>
                                                    <td>
                                                        <a class="btn btn-success btn-sm"
                                                            href="<?php echo e(route('admincoach.update', $item->user_tbl_id)); ?>">
                                                            <i class="glyphicon glyphicon-pencil"></i></a>
                                                    </td>
                                                <?php endif; ?>
            
                  <?php if(auth()->user()->role->permission['capabilities']['coach']['delete']==1): ?>
                                                    <td>
                                                        <form method="post" action="<?php echo e(route('coach.delete', $item->user_tbl_id)); ?>" data-parsley-validate class="form-horizontal form-label-left">
                                                            <?php echo e(csrf_field()); ?>

                                                            <?php echo e(method_field('DELETE')); ?>


                                                            <button onclick="return confirm('Are you sure you want to delete?')"
                                                                type="submit" class="btn btn-danger btn-sm"><i
                                                                    class="fa fa-fw fa-trash-o"></i></button>
                                                        </form>
                                                    </td>
                                                <?php endif; ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tr>
              </tfoot>
            </table>
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/admin/instructor/all_instructor/index.blade.php ENDPATH**/ ?>