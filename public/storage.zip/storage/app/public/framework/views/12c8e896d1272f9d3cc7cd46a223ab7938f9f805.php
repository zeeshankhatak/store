<?php $__env->startSection('title', 'All Order - Admin'); ?>
<?php $__env->startSection('body'); ?>

    <section class="content">
        <?php echo $__env->make('gamer.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Add Student Modal -->
        <div class="modal fade" id="AddStudentModal" tabindex="-1" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add Student</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form group-mb3">
                            <label for="">Name</label>
                            <input type="text" class="name form-control">
                        </div>
                        <div class="form group-mb3">
                            <label for="">Email</label>
                            <input type="text" class="email form-control">
                        </div>
                        <div class="form group-mb3">
                            <label for="">Subject</label>
                            <input type="text" class="subject form-control">
                        </div>
                        <div class="form group-mb3">
                            <label for="">Start Time</label>
                            <input type="date" class="start_time form-control">
                        </div>
                        <div class="form group-mb3">
                            <label for="">Status</label>
                            <select class="status form-select" aria-label="Default select example">
                                <option value="Permanent">Permanent</option>
                                <option value="Visiting">Visiting</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="add_student btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Add Student Modal -->
        <div class="row">
            <?php echo $__env->make('admin.user.tabs.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-md-9">
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"> <?php echo e(__('adminstaticword.Order')); ?></h3>
                    </div>

                    <!-- /.box-header -->
                    <div class="box-body">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>

                                    <br>
                                    <br>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e(__('adminstaticword.Order #')); ?></th>
                                        
                                        <th><?php echo e(__('adminstaticword.Package')); ?></th>
                                        <th><?php echo e(__('adminstaticword.Game')); ?></th>
                                        <th><?php echo e(__('adminstaticword.No.of Coaches')); ?></th>
                                        <th><?php echo e(__('adminstaticword.Coach Names')); ?></th>
                                        <th><?php echo e(__('adminstaticword.PackageAmount')); ?></th>
                                        <th><?php echo e(__('adminstaticword.Status')); ?></th>
                                        <th><?php echo e(__('adminstaticword.Game Date | Time')); ?></th>
                                        <th><?php echo e(__('adminstaticword.Order Status')); ?></th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $i = 0; ?>
                                    <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        

                                        <?php $i++; ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo e($order_detail->order_id); ?></td>
                                            

                                            

                                            <td><?php echo e($order_detail->pkg_name); ?></td>
                                            <td><?php echo e($order_detail->game_name); ?></td>
                                            <td><?php echo e($order_detail->coaches); ?></td>

                                            <td><?php echo e($order_detail->coaches_name); ?></td>

                                            

                                            
                                            <td>$<?php echo e($order_detail->total_amount); ?></td>


                                            

                                            <td>


                                                <span type="Submit"
                                                    class="btn btn-xs <?php echo e($order_detail->order_status == 1 ? 'btn-success' : 'btn-danger'); ?>">
                                                    <?php if($order_detail->order_status == 1): ?>
                                                        <?php echo e(__('adminstaticword.Paid')); ?>

                                                    <?php else: ?>
                                                        <?php echo e(__('adminstaticword.Unpaid')); ?>

                                                    <?php endif; ?>
                                                </span>

                                            </td>

                                            <td><?php echo e($order_detail->assign_date); ?></td>

                                            <td>


                                                <span type="Submit"
                                                    class="btn btn-xs <?php echo e($order_detail->coach_status == 1 ? 'btn-success' : 'btn-danger'); ?>">
                                                    <?php if($order_detail->coach_status == 1): ?>
                                                        <?php echo e(__('adminstaticword.Accepted')); ?>

                                                    <?php else: ?>
                                                        <?php echo e(__('adminstaticword.Pending')); ?>

                                                    <?php endif; ?>
                                                </span>

                                            </td>



                                            

                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fpsaquaclients/public_html/resources/views/admin/user/tabs/order/index.blade.php ENDPATH**/ ?>