<?php $__env->startSection('title', 'View Instructor - Admin'); ?>
<?php $__env->startSection('body'); ?>

<section class="content">
  <?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="row">
    <div class="col-md-12">
    	<div class="box box-primary">
           	<div class="box-header with-border">
          	<h3 class="box-title"><?php echo e(__('adminstaticword.InstructorRequest')); ?></h3>
       		</div>
          	<div class="panel-body">

          		<div class="view-instructor">
                    <div class="instructor-detail">
                    	<ul>
                    		<li><img src="<?php echo e(asset('images/instructor/'.$show->user_img)); ?>" class="img-circle"/></li>
                    		<li><?php echo e(__('adminstaticword.Name')); ?>: <?php echo e($show->fname); ?> <?php echo e($show->lname); ?></li>
                    		
                    		<li><?php echo e(__('adminstaticword.Phone')); ?>: <?php echo e($show->mobile); ?></li>
                    		<li><?php echo e(__('adminstaticword.Email')); ?>: <?php echo e($show->email); ?></li>
                            <li><?php echo e(__('adminstaticword.Game')); ?>: <?php echo e($show->game_id); ?></li>
                            <li><?php echo e(__('adminstaticword.Rank')); ?>: <?php echo e($show->coach_rank_id); ?></li>
                            <li><?php echo e(__('adminstaticword.K\D Ratio')); ?>: <?php echo e($show->k_d_ratio); ?></li>
                            <li><?php echo e(__('adminstaticword.Win-Rate')); ?>: <?php echo e($show->win_rate); ?></li>
                    		<li><?php echo e(__('adminstaticword.DateofBirth')); ?>: <?php echo e($show->dob); ?></li>
                    		<li><?php echo e(__('adminstaticword.Gender')); ?>: <?php echo e($show->gender); ?></li>
                    		<li><?php echo e(__('adminstaticword.Detail')); ?>: <?php echo e($show->good_coach_desc); ?></li>
                    		

                    	</ul>
                    </div>
          		</div>


	            <form action="<?php echo e(route('requestinstructor.update',$show->coach_tbl_id)); ?>" method="POST" enctype="multipart/form-data">
	                <?php echo e(csrf_field()); ?>

	                <?php echo e(method_field('PUT')); ?>


	                <input type="hidden" value="<?php echo e($show->coach_tbl_id); ?>" name="coach_id" class="form-control">
					<input type="hidden" value="<?php echo e($show->user_type); ?>" name="user_type" class="form-control">
                    <input type="hidden" value="<?php echo e($show->mobile); ?>" name="mobile" class="form-control">
                    <input type="hidden" value="<?php echo e($show->good_coach_desc); ?>" name="detail" class="form-control">
                    <input type="hidden" value="<?php echo e($show->gender); ?>" name="gender" class="form-control">
                    <input type="hidden" value="<?php echo e($show->dob); ?>" name="dob" class="form-control">
                    <input type="hidden" value="<?php echo e($show->user_img); ?>" name="image" class="form-control">

	              	<div class="row">
	                  <div class="col-md-6">

	                    <label for="exampleInputTit1e"><?php echo e(__('adminstaticword.Status')); ?>:</label>
	                    <br>
	                    <li class="tg-list-item">
	                    <input class="tgl tgl-skewed" id="cb333" type="checkbox" <?php echo e($show->approval==1 ? 'checked' : ''); ?>>
	                    <label class="tgl-btn" data-tg-off="Pending" data-tg-on="Approved" for="cb333"></label>
	                    </li>
	                    <input type="hidden" name="approval" value="<?php echo e($show->approval); ?>" id="c33">
		              </div>

	              	</div>
	              	<br>
	              	<button value="" type="submit"  class="btn btn-lg col-md-4 btn-primary"><?php echo e(__('adminstaticword.Save')); ?></button>

	          	</form>
          	</div>
      	</div>
  	</div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/centauruscrm/fps.centauruscrm.com/resources/views/admin/instructor/instructor_request/view.blade.php ENDPATH**/ ?>